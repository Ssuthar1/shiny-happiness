 <div class="container pb-14">
        <h2 class="text-[28px] mb-6 text-secondary">CATEGORIES</h2>
        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 xl:grid-cols-6 gap-6">
            <!-- Fruits Category -->
           @foreach($fruitsCategories as $catInfo)
	            <div class="col-span-1 shadow-md rounded-[3px] overflow-hidden">
	                <a href="{{route('productCategory',['category' => $catInfo->slug])}}" class="w-full flex justify-center">
	                    <div class="p-4 group text-center">
	                        <div
	                            class="w-[90px] h-[90px] bg-[#F7F7F7] m-auto rounded-full flex items-center justify-center flex-shrink-0 overflow-hidden">
	                            <img src="{{ route('displayImage') }}?imagepath={{ $catInfo->image }}" class="w-14 h-14 object-contain" alt="">
	                        </div>
	                        <h5
	                            class="mt-4 text-lg leading-[21px] text-secondary group-hover:text-primary transition duration-300">
	                           {{$catInfo->name}}</h5>
	                    </div>
	                </a>
	            </div>
            @endforeach
           
            
        </div>
    </div>