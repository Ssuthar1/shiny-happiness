<x-front-app-layout> 


    <livewire:frontend.shop-component :categorySlug=$categorySlug />


</x-front-app-layout>
