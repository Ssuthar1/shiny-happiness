<x-front-app-layout> 


	    <!-- hero area -->
    <div class="w-full">
        <div class="w-full flex items-center">
            <!-- Slider main container -->
            <div class="swiper banner-swiper">
                <!-- Additional required wrapper -->
                <div class="swiper-wrapper">
                    <!-- Slides -->
                    <div class="swiper-slide flex items-center bg-no-repeat bg-cover bg-center min-h-[520px]"
                        style="background-image: url({{asset('frontend/assets/images/banner-1.jpg')}});">
                        <div class="container">
                            <div class="lg:flex flex-wrap">
                                <div class="w-full lg:w-1/2">
                                    <div>
                                        <h1
                                            class="text-[38px] md:text-[56px] lg:text-5xl xl:text-[56px] leading-[42px] md:leading-[64px] lg:leading-[48px] xl:leading-[64px] font-medium mb-2 sm:mb-4 text-secondary">
                                            Pure Perfection: Handpicked Fresh Fruits for Your Palate</h1>
                                        <p class="text-secondary text-base mb-2 sm:mb-4">Lorem ipsum dolor sit amet,
                                            consectetur adipiscing elit. Vulputate rhoncus pellentesque
                                            id
                                            integer neque, vel accumsan dolor diam.</p>
                                        <div class="mt-[30px] md:mt-[40px]">
                                            <a class="primary-btn py-2.5" href="{{route('shop')}}" tabindex="-1">SHOP NOW</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="swiper-slide flex items-center bg-no-repeat bg-cover bg-center min-h-[520px]"
                        style="background-image: url({{asset('frontend/assets/images/banner-2.jpg')}});">
                        <div class="container">
                            <div class="lg:flex flex-wrap">
                                <div class="lg:w-1/2">
                                    <div>
                                        <h1
                                            class="text-[38px] md:text-[56px] lg:text-5xl xl:text-[56px] leading-[42px] md:leading-[64px] lg:leading-[48px] xl:leading-[64px] font-medium mb-2 sm:mb-4 text-secondary">
                                            Fruitful Bites: Nature's Sweetest Selection</h1>
                                        <p class="text-secondary text-base mb-2 sm:mb-4">Lorem ipsum dolor sit amet,
                                            consectetur adipiscing elit. Vulputate rhoncus pellentesque
                                            id
                                            integer neque, vel accumsan dolor diam.</p>
                                        <div class="mt-[30px] md:mt-[40px]">
                                            <a class="primary-btn py-2.5" href="{{route('shop')}}" tabindex="-1">SHOP NOW</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="swiper-slide flex items-center bg-no-repeat bg-cover bg-center min-h-[520px]"
                        style="background-image: url({{asset('frontend/assets/images/banner-3.jpg')}});">
                        <div class="container">
                            <div class="lg:flex flex-wrap">
                                <div class="lg:w-1/2">
                                    <div>
                                        <h1
                                            class="text-[38px] md:text-[56px] lg:text-5xl xl:text-[56px] leading-[42px] md:leading-[64px] lg:leading-[48px] xl:leading-[64px] font-medium mb-2 sm:mb-4 text-secondary">
                                            Nature's Sweet Symphony: Fresh Fruits at Their Finest</h1>
                                        <p class="text-secondary text-base mb-2 sm:mb-4">Lorem ipsum dolor sit amet,
                                            consectetur adipiscing elit. Vulputate rhoncus pellentesque
                                            id
                                            integer neque, vel accumsan dolor diam.</p>
                                        <div class="mt-[30px] md:mt-[40px]">
                                            <a class="primary-btn py-2.5" href="{{route('shop')}}" tabindex="-1">SHOP NOW</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- If we need navigation buttons -->
                <div class="swiper-button-prev hidden xl:block collection-banner"></div>
                <div class="swiper-button-next hidden xl:block collection-banner"></div>

                <!-- If we need pagination -->
                <div class="swiper-pagination"></div>
            </div>
        </div>
    </div>
    <!-- hero area end-->

    <!-- feature area -->
    <section class="py-14">
        <div class="container">
            <div class="flex justify-center">
                <div class="w-full xl:w-5/6 max-w-full xl:px-3">
                    <div class="sm:flex justify-center">
                        <div class="w-[270px] sm:w-1/3 max-w-full sm:pr-3 mb-3 sm:mb-0 mx-auto">
                            <div class="min-h-[90px] border border-primary rounded-sm flex items-center justify-center">
                                <div class="mr-3 md:mr-6 flex-shrink-0">
                                    <img src="{{asset('frontend/assets/images/delivery-van.svg')}}" class="w-[40px] md:w-[50px] max-h-11"
                                        alt="icon">
                                </div>
                                <div>
                                    <h4 class="text-lg sm:text-base md:text-lg leading-6 mb-1">Free shipping</h4>
                                    <p class="sm:text-[10px] md:text-[13px] text-[#6B6B6B]">Orders over $200</p>
                                </div>
                            </div>
                        </div>

                        <div class="w-[270px] sm:w-1/3 max-w-full sm:px-3 mb-3 sm:mb-0 mx-auto">
                            <div class="min-h-[90px] border border-primary rounded-sm flex items-center justify-center">
                                <div class="mr-3 md:mr-6 flex-shrink-0">
                                    <img src="{{asset('frontend/assets/images/money-back.svg')}}" class="w-[40px] md:w-[50px] max-h-11"
                                        alt="icon">
                                </div>
                                <div>
                                    <h4 class="text-lg sm:text-base md:text-lg leading-6 mb-1">Money Returns</h4>
                                    <p class="sm:text-[10px] md:text-[13px] text-[#6B6B6B]">30 Days money return</p>
                                </div>
                            </div>
                        </div>

                        <div class="w-[270px] sm:w-1/3 max-w-full sm:pl-3 mx-auto">
                            <div class="min-h-[90px] border border-primary rounded-sm flex items-center justify-center">
                                <div class="mr-3 md:mr-6 flex-shrink-0">
                                    <img src="{{asset('frontend/assets/images/service-hours.svg')}}" class="w-[40px] md:w-[50px] max-h-11"
                                        alt="icon">
                                </div>
                                <div>
                                    <h4 class="text-lg sm:text-base md:text-lg leading-6 mb-1">24/7 Support</h4>
                                    <p class="sm:text-[10px] md:text-[13px] text-[#6B6B6B]">Customer support</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- feature area end -->

    <!-- FLASH SALE -->
    <div class="container pb-14">
        <div class="sm:flex flex-wrap">
            <div class="w-full sm:w-1/2 sm:pr-3 mb-8 sm:mb-0">
                <div class="flex flex-col-reverse lg:flex-row gap-4 lg:gap-0 lg:items-center justify-between px-8 py-6 bg-[#FBE3E4]">
                    <div>
                        <h3 class="text-lg leading-4 mb-2 text-[#FD3D57]">30% offer</h3>
                        <h4 class="text-[22px] leading-[26px] text-secondary mb-2">Free Shipping</h4>
                        <p class="text-[15px] leading-4 text-[#464545] mb-5">Fresh Fruits</p>
                        <a href="{{route('shop')}}" class="primary-btn min-w-[80px]">Shop Now</a>
                    </div>
                    <div class="flex justify-center">
                        <img src="{{asset('frontend/assets/images/mango4.png')}}" class="w-[200px] h-[150px] lg:h-[180px] object-contain flex-shrink-0 hover:scale-105 transition-all duration-300" alt="product">
                    </div>
                </div>
            </div>

            <div class="w-full sm:w-1/2 sm:pl-3">
                <div class="flex flex-col-reverse lg:flex-row gap-4 lg:gap-0 lg:items-center justify-between px-8 py-6 bg-[#EDECEC]">
                    <div>
                        <h3 class="text-lg leading-4 mb-2 text-[#FD3D57]">50% offer</h3>
                        <h4 class="text-[22px] leading-[26px] text-secondary mb-2">Flash Sale</h4>
                        <p class="text-[15px] leading-4 text-[#464545] mb-5">Natural Furniture</p>
                        <a href="{{route('shop')}}" class="primary-btn min-w-[80px]">Shop Now</a>
                    </div>
                    <div class="flex justify-center">
                        <img src="{{asset('frontend/assets/images/papap1.png')}}" class="w-[200px] h-[150px] lg:h-[180px] object-contain flex-shrink-0 hover:scale-105 transition-all duration-300" alt="product">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- FLASH SALE end-->

    
     <!-- Products Section --> 
    @php $title = "Top Products";
        $type = "top_rated";
        $key = "top_rated";
     @endphp
     <livewire:frontend.home-products :key=$key :type=$type :title=$title />
    <!-- Products Section end-->
 <!-- ad banner -->
    <div class="pb-14">
        <div class="container">
             <a href="{{route('shop')}}">
                <picture>
                    <img class="w-full flex-shrink-0" src="{{asset('frontend/assets/images/offer.jpg')}}" alt="ad">
                </picture>
            </a>
        </div>
    </div>
    <!-- ad banner end -->
    <!-- Products Section --> 
    @php $title = "New Arrivals";
        $type = "new_arrivals";
        $key = "new_arrivals";
     @endphp
     <livewire:frontend.home-products :key=$key :type=$type :title=$title />
    <!-- Products Section end-->
     <div class="pb-14">
        <div class="container">
            <a href="{{route('shop')}}">
                <picture>
                    <img class="w-full flex-shrink-0" src="{{asset('frontend/assets/images/offer.jpg')}}" alt="ad">
                </picture>
            </a>
        </div>
    </div>
    <!-- Products Section --> 
    @php $title = "Best Selling Products";
        $type = "best_selling";
        $key = "best_selling";
     @endphp
     <livewire:frontend.home-products :key=$key :type=$type :title=$title />
    <!-- Products Section end--> 

    <!-- download app -->
    <div class="container pb-14">
        <div class="bg-[#f3f3f3]">
            <div class="md:flex flex-wrap">
                <div class="md:w-1/2 md:pr-3">
                    <img loading="lazy" src="{{asset('frontend/assets/images/mobile-view.png')}}"
                        class="w-full max-h-[450px] h-full object-contain flex-shrink-0">
                </div>
                <div class="md:w-5/12 py-6 px-4 sm:px-12 md:px-0 md:py-0 md:pt-[90px] md:pb-[105px]">
                    <div>
                        <h2 class="text-2xl sm:text-[26px] md:text-[28px] mb-4 text-secondary">Download Fresh Fruit Express App
                            Now!</h2>
                        <p class="mb-6 text-secondary">Shopping fastly and easily more with our app. Get a link to
                            download
                            the app on your
                            phone</p>
                        <form action="#" class="flex">
                            <input type="text" placeholder="Email Address"
                                class="w-full bg-white rounded-l-[5px] border border-primary border-r-transparent focus:ring-0 focus:border-primary text-sm px-5 py-[14px] focus:outline-none">
                            <button type="submit" class="min-w-[120px] primary-btn rounded-l-none">Subscribe</button>
                        </form>
                        <div class="flex items-center mt-[35px]">
                            <a href="#" class="mr-4">
                                <img src="{{asset('frontend/assets/images/download-1.png')}}" class="w-[120px] rounded-[5px] flex-shrink-0"
                                    alt="download">
                            </a>
                            <a href="#">
                                <img src="{{asset('frontend/assets/images/download-2.png')}}" class="w-[120px] rounded-[5px] flex-shrink-0"
                                    alt="download">
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- download app end -->
<script>
    
 window.addEventListener('toast:cartSuccess', event => {

    Toastify({
  text: event.detail.text,
  className: "error",
  style: {
    background: "linear-gradient(to right, #00b09b, #96c93d)",
  }
}).showToast();

           

        });
  </script>
</x-front-app-layout>
