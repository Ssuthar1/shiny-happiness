  <x-front-app-layout> 

    <!-- breadcrumbs -->
    <div class="container">
        <div class="py-5 flex items-center">
            <a href="{{route('homePage')}}" class="flex  items-center">
                <span class="text-primary">
                    <svg width="17" height="17" viewBox="0 0 32 32">
                        <path fill="currentColor"
                            d="m16 2.594l-.719.687l-13 13L3.72 17.72L5 16.437V28h9V18h4v10h9V16.437l1.281 1.282l1.438-1.438l-13-13zm0 2.844l9 9V26h-5V16h-8v10H7V14.437z" />
                    </svg>
                </span>
                <span>
                    <svg width="22" height="22" viewBox="0 0 24 24">
                        <path fill="currentColor" d="M10 6L8.59 7.41L13.17 12l-4.58 4.59L10 18l6-6l-6-6z" /></svg>
                </span>

            </a>
            <a href="{{route('homePage')}}" class="text-secondary text-[13px] sm:text-base"> F.A.Q </a>
        </div>
    </div>
    <!-- breadcrumbs end-->

    <!-- faq page -->
    <div class="container pb-14">
        <h2 class="text-3xl mb-2">F.A.Q</h2>
        <p class="mb-4 pb-2">Can’t find the answer you’re looking for? We’ve shared some <br class="d-none d-md-block">
            of your
            most frequently asked questions to help you out!</p>

        <div class="w-[1000px]" x-data="accordianModules">
            <template x-for="(acc,accIndex) in accordians">
                <div>
                    <h4 class="text-2xl mt-4 mb-4" x-text="acc.section"></h4>
                    <div class="border rounded">
                        <template x-for="(faq, faqIndex) in acc.faqs">
                            <div class="accordion-item">
                                <div @click="toggleFaq(accIndex, faqIndex)"
                                    :class="faq.isOpen ? 'text-primary !font-normal' : ''"
                                    class="border-b px-5 py-4 cursor-pointer flex justify-between w-full">
                                    <h2 x-text="faq.question"></h2>
                                    <span :class="faq.isOpen ? 'text-primary rotate-180' : ''"
                                        class="transition duration-500">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                                            viewBox="0 0 24 24">
                                            <path fill="currentColor"
                                                d="M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6l-6-6l1.41-1.41z" /></svg>
                                    </span>
                                </div>
                                <div x-show="faq.isOpen" x-text="faq.answer" class="accordion-body border-b px-4 py-5">
                                    Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem
                                    Ipsum has been the industry's standard dummy text ever since
                                    the 1500s, when an unknown printer took a galley of type and scrambled it to
                                    make a type specimen book.
                                </div>
                            </div>
                        </template>
                    </div>
                </div>
            </template>
        </div>

    </div>

       <script>
        const accordianModules = {
            accordians: [{
                    section: 'Shipping Information',
                    faqs: [{
                            question: 'How will my parcel be deliverd?',
                            answer: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem   Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown  printer took a galley of type and scrambled it to make a type specimen book.',
                            isOpen: true
                        },
                        {
                            question: 'Do I pay for delivery?',
                            answer: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
                            isOpen: false
                        },
                        {
                            question: 'How will my parcel be deliverd?',
                            answer: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
                            isOpen: false
                        },
                        {
                            question: 'How will my parcel be deliverd?',
                            answer: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
                            isOpen: false
                        }
                    ]
                },
                {
                    section: 'Orders And Returns',
                    faqs: [{
                            question: 'Tracking my order?',
                            answer: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem   Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown  printer took a galley of type and scrambled it to make a type specimen book.',
                            isOpen: false
                        },
                        {
                            question: "I haven't recived my order",
                            answer: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
                            isOpen: false
                        },
                        {
                            question: 'How can I return on item?',
                            answer: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
                            isOpen: false
                        },
                        {
                            question: 'How will my parcel be deliverd?',
                            answer: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
                            isOpen: false
                        }
                    ]
                },
                {
                    section: 'Payments',
                    faqs: [{
                            question: 'What payment types can i use?',
                            answer: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem   Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown  printer took a galley of type and scrambled it to make a type specimen book.',
                            isOpen: false
                        },
                        {
                            question: 'Can I pay by gift Card?',
                            answer: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
                            isOpen: false
                        },
                        {
                            question: "I can't make a payment",
                            answer: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
                            isOpen: false
                        },
                        {
                            question: "Has my payment gone though",
                            answer: 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.',
                            isOpen: false
                        }
                    ]
                }
            ],
            toggleFaq(accIndex, faqIndex) {
                if (this.accordians[accIndex].faqs[faqIndex].isOpen) {
                    this.accordians[accIndex].faqs[faqIndex].isOpen = false
                } else {
                    this.accordians.forEach(acc => {
                        acc.faqs.forEach(faq => faq.isOpen = false)
                    })
                    this.accordians[accIndex].faqs[faqIndex].isOpen = true
                }
            }

        }
    </script>
   </x-front-app-layout> 
