  // mobile menu list
  const menuModules = {
    menuList: [{
            name: 'Home',
            isOpen: false,
            subMenus: [{
                    name: 'Home 1',
                    href: 'index-1.html'
                },
                {
                    name: 'Home 2',
                    href: 'index-2.html'
                },
                {
                    name: 'Home 3',
                    href: 'index-3.html'
                },
            ]
        },
        {
            name: 'Shop',
            isOpen: false,
            subMenus: [{
                    name: 'List view',
                    href: 'list-view.html'
                },
                {
                    name: 'Grid view',
                    href: 'grid-view.html'
                },
                {
                    name: 'Grid view 2',
                    href: 'grid-view-2.html'
                },
                {
                    name: 'Shopping Cart',
                    href: 'shopping-cart.html'
                },
                {
                    name: 'Product view',
                    href: 'product-view.html'
                },
            ]
        },
        {
            name: 'My Account',
            isOpen: false,
            subMenus: [{
                    name: 'My Account',
                    href: 'my-account.html'
                },
                {
                    name: 'Login',
                    href: 'login.html'
                },
                {
                    name: 'Register',
                    href: 'register.html'
                },
                {
                    name: 'Forgot Password',
                    href: 'forgot-password.html'
                },
            ]
        },
        {
            name: 'Other Pages',
            isOpen: false,
            subMenus: [{
                    name: 'About Us',
                    href: 'about.html'
                },
                {
                    name: 'Contact Us',
                    href: 'contact.html'
                },
                {
                    name: 'Track Order',
                    href: 'track-order.html'
                },
                {
                    name: 'FAQ',
                    href: 'faq.html'
                },
                {
                    name: '404',
                    href: '404.html'
                },
                {
                    name: 'Checkout',
                    href: 'checkout.html'
                },
                {
                    name: 'Payment',
                    href: 'payment.html'
                },
                {
                    name: 'Order Complete',
                    href: 'order-complete.html'
                },
            ]
        },
    ],
    toggleMenu(index) {
        if (this.menuList[index].isOpen) {
            this.menuList[index].isOpen = false
        } else {
            this.menuList.forEach(menu => menu.isOpen = false)
            this.menuList[index].isOpen = true
        }
    }
}

// category list
const categoryModules = {
    categoryList: [{
            icon: `<img src="assets/images/prod-6.png" width="20" height="20">`,
            name: 'Banana',
            href: '#',
        },
        {
         
          	icon: `<img src="assets/images/mango4.png" width="20" height="20">`,
            name: 'Mango',
        },
        {
            icon: `<img src="assets/images/graps.png" width="20" height="20">`,
            name: 'Grape',
        },
        {
           icon: `<img src="assets/images/pomegranate.png" width="20" height="20">`,
            name: 'Pomegranate',
        },
        {
           icon: `<img src="assets/images/orange.png" width="20" height="20">`,
            name: 'Orange',
        },
        {
            icon: `<img src="assets/images/watermelon.png" width="20" height="20">`,
            name: 'Watermelon'
         },
        {
            icon: `<img src="assets/images/prod-4.png" width="20" height="20">`,
            name: 'Guava'
         
         },
        {
            icon: `<img src="assets/images/jackfruits.png" width="20" height="20">`,
            name: 'Jackfruit'
         },
        {
            icon: `<img src="assets/images/apple1.png" width="20" height="20">`,
            name: 'Apple'
        },
        {
            icon: `<img src="assets/images/starb.png" width="20" height="20">`,
            name: 'Strawberry'
        },
        {
            icon: `<img src="assets/images/pear.png" width="20" height="20">`,
            name: 'Pear'
        },
        {
            icon: `<img src="assets/images/otherfruites.png" width="20" height="20">`,
            name: 'Other Fuurits'
        }
		
		
    ],
    openMainCat(catIndex) {
        if (this.categoryList[catIndex].isOpen) {
            this.categoryList[catIndex].isOpen = false
        } else {
            this.categoryList.forEach(cat => cat.isOpen = false)
            this.categoryList[catIndex].isOpen = true
        }
    },
    openSubCat(catIndex, subCatIndex) {
        if (this.categoryList[catIndex].subCategories[subCatIndex].isOpen) {
            this.categoryList[catIndex].subCategories[subCatIndex].isOpen = false
        } else {
            this.categoryList.forEach(cat => {
                if (cat.subCategories) {
                    cat.subCategories.forEach(subCat => subCat.isOpen = false)
                }
            })
            this.categoryList[catIndex].subCategories[subCatIndex].isOpen = true
        }
    }
}

// Alpine Store
document.addEventListener('alpine:init', () => {
    Alpine.store('mobileMenu', {
        isOpen: false,
    })

    Alpine.store('category', {
        isCategory: false,
    })

    Alpine.store('search', {
        isSearch: false,
    })

    Alpine.store('cart', {
        isCart: false,
    })
})

// Price Range slider
function rangeslide(value) {
    document.getElementById('rangeValue').innerHTML = value;
}

// nice selector

let niceSelects = document.querySelectorAll(".nice-select")
for (nice of niceSelects) {
  NiceSelect.bind(nice);
}





