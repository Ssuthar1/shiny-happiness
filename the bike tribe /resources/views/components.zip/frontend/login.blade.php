<x-front-app-layout> 


    <!-- breadcrumbs -->
    <div class="container py-5 flex items-center">
        <a href="{{route('homePage')}}" class="flex  items-center">
            <span class="text-primary">
                <svg width="17" height="17" viewBox="0 0 32 32">
                    <path fill="currentColor"
                        d="m16 2.594l-.719.687l-13 13L3.72 17.72L5 16.437V28h9V18h4v10h9V16.437l1.281 1.282l1.438-1.438l-13-13zm0 2.844l9 9V26h-5V16h-8v10H7V14.437z" />
                </svg>
            </span>
            <span>
                <svg width="22" height="22" viewBox="0 0 24 24">
                    <path fill="currentColor" d="M10 6L8.59 7.41L13.17 12l-4.58 4.59L10 18l6-6l-6-6z" /></svg>
            </span>

        </a>
        <a href="{{route('myAccount')}}?action=login" class="text-secondary text-[13px] sm:text-base"> Login </a>
    </div>
    <!-- breadcrumbs end-->

    <!--Login wrap-->
    <div class="w-full max-w-[500px] mx-auto box_shadow rounded px-[30px] py-[24px] mb-14">
        <h4 class="text-[28px] uppercase font-medium">Login</h4>
        <p class="mb-4 text_md">Login if you a a returing customer</p>
        <form>
            <div>
                <div>
                    <label class="block">Email Address <span class="text-primary">*</span></label>
                    <input class="w-full border border-[#E9E4E4] rounded focus:ring-0 focus:border-primary mt-1"
                        type="email" placeholder="example@mail.com">
                </div>
                <div class="mt-4">
                    <label class="block">Password <span class="text-primary">*</span></label>
                    <input class="w-full border border-[#E9E4E4] rounded focus:ring-0 focus:border-primary mt-1"
                        type="password" placeholder="type password">
                </div>

                <div class="flex justify-between items-center mt-6">
                    <div class="flex gap-3 items-center">
                        <input type="checkbox"
                            class="focus:ring-0 text-primary border border-primary focus:bg-primary focus:outline-none"
                            id="save-default">
                        <label for="save-default" class="text-sm sm:text-base">Remember Me</label>
                    </div>
                    <div>
                        <a href="forgot-password.html" class="text-primary text-sm sm:text-base">Forgot Password?</a>
                    </div>
                </div>



            </div>
            <div class="mt-4">
                <button type="submit" class="default_btn rounded w-full">Login</button>
            </div>
        </form>

        <div
            class="flex justify-center mt-4 relative after:absolute after:w-full after:h-[1px] after:bg-gray-300 after:top-3">
            <p class="px-2 bg-white z-10">Or login in with</p>
        </div>

        <div class="flex gap-5 mt-4">
            <button class="default_btn w-full rounded bg-facebook">
                <i class="fab fa-facebook-f me-2"></i> Facebook
            </button>
            <button class="default_btn w-full bg-google">
                <i class="fab fa-google me-2"></i> Google
            </button>
        </div>

        <p class="text-center mt-3 mb-0">Don't have an account.? <a href="register.html" class="text-primary">Register
                Now</a></p>
    </div>

 
</x-front-app-layout>
