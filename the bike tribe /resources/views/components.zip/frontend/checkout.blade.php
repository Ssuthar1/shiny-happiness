<x-front-app-layout> 


    <!-- breadcrumbs -->
    <div class="container">
        <div class="py-5 flex items-center">
            <a href="{{route('homePage')}}" class="flex  items-center">
                <span class="text-primary">
                    <svg width="17" height="17" viewBox="0 0 32 32">
                        <path fill="currentColor"
                            d="m16 2.594l-.719.687l-13 13L3.72 17.72L5 16.437V28h9V18h4v10h9V16.437l1.281 1.282l1.438-1.438l-13-13zm0 2.844l9 9V26h-5V16h-8v10H7V14.437z" />
                    </svg></span>
                <span>
                    <svg width="22" height="22" viewBox="0 0 24 24">
                        <path fill="currentColor" d="M10 6L8.59 7.41L13.17 12l-4.58 4.59L10 18l6-6l-6-6z" /></svg>
                </span>

            </a>
            <a href="{{route('shop')}}" class="text-primary text-[13px] sm:text-base">Shop</a>
            <span>
                <svg width="22" height="22" viewBox="0 0 24 24">
                    <path fill="currentColor" d="M10 6L8.59 7.41L13.17 12l-4.58 4.59L10 18l6-6l-6-6z" /></svg>
            </span>
            <a href="{{route('checkout')}}" class="text-secondary text-[13px] sm:text-base">Checkout</a>
        </div>
    </div>
    <!-- breadcrumbs end-->

    <!-- cart area -->
    <div class="container grid grid-cols-12 gap-6 pb-14">
        <div class="col-span-12 md:col-span-6 lg:col-span-8">
            <h4 class="bg-[#E9E4E4] px-3 py-2">Billing details</h4>
            <div>
                <div class="sm:flex md:block lg:flex gap-6 mt-6">
                    <div class="w-full sm:w-1/2 md:w-full lg:w-1/2">
                        <label for="first_name">First Name <span class="text-primary">*</span></label>
                        <input
                            class="w-full text-sm border border-[#E9E4E4] rounded focus:ring-0 focus:border-primary mt-2"
                            type="text" id="first_name">
                    </div>
                    <div class="w-full sm:w-1/2 md:w-full lg:w-1/2 mt-6 sm:mt-0 md:mt-6 lg:mt-0">
                        <label for="last_name">Last Name <span class="text-primary">*</span></label>
                        <input
                            class="w-full text-sm border border-[#E9E4E4] rounded focus:ring-0 focus:border-primary mt-2"
                            type="text" id="last_name">
                    </div>
                </div>
                <div class="mt-4">
                    <label for="company_name">Company Name</label>
                    <input class="w-full text-sm border border-[#E9E4E4] rounded focus:ring-0 focus:border-primary mt-2"
                        type="text" id="company_name">
                </div>
                <div class="mt-4">
                    <label for="county_region">County/Region <span class="text-primary">*</span></label>
                    <input class="w-full text-sm border border-[#E9E4E4] rounded focus:ring-0 focus:border-primary mt-2"
                        type="text" id="county_region">
                </div>
                <div class="mt-4">
                    <label for="street_addr">Street Address <span class="text-primary">*</span></label>
                    <input class="w-full text-sm border border-[#E9E4E4] rounded focus:ring-0 focus:border-primary mt-2"
                        type="text" id="street_addr">
                </div>
                <div class="mt-4">
                    <label for="town_city">Town/City <span class="text-primary">*</span></label>
                    <input class="w-full text-sm border border-[#E9E4E4] rounded focus:ring-0 focus:border-primary mt-2"
                        type="text" id="town_city">
                </div>
                <div class="mt-4">
                    <label for="zip_code">Zip Code <span class="text-primary">*</span></label>
                    <input class="w-full text-sm border border-[#E9E4E4] rounded focus:ring-0 focus:border-primary mt-2"
                        type="text" id="zip_code">
                </div>
                <div class="mt-4">
                    <label for="phone_number">Phone Number <span class="text-primary">*</span></label>
                    <input class="w-full text-sm border border-[#E9E4E4] rounded focus:ring-0 focus:border-primary mt-2"
                        type="text" id="phone_number">
                </div>
                <div class="mt-4">
                    <label for="email_addr">Email Address <span class="text-primary">*</span></label>
                    <input class="w-full text-sm border border-[#E9E4E4] rounded focus:ring-0 focus:border-primary mt-2"
                        type="text" id="email_addr">
                </div>
            </div>
        </div>
        <div class="col-span-12 md:col-span-6 lg:col-span-4">
            <h4 class="bg-[#E9E4E4] px-3 py-2">Your Order</h4>
            <div class="border border-[#E9E4E4] px-4 py-6 mt-4">
                <h4 class="uppercase border-b border-[#E9E4E4] pb-2">product</h4>
                <div class="flex justify-between mt-5">
                    <div class="checkorder_cont">
                        <h5>Beigh Knitted Shoes</h5>
                        <p>Size: M</p>
                    </div>
                    <p class="font-semibold">x1</p>
                    <p class="font-semibold">$84.00</p>
                </div>
                <div class="flex justify-between mt-5">
                    <div class="checkorder_cont">
                        <h5>Beigh Knitted Shoes</h5>
                        <p>Color: Red</p>
                    </div>
                    <p class="font-semibold">x2</p>
                    <p class="font-semibold">$84.00</p>
                </div>
                <div class="flex justify-between mt-5">
                    <div class="checkorder_cont">
                        <h5>Beigh Knitted Shoes</h5>
                        <p>Size: M</p>
                    </div>
                    <p class="font-semibold">x1</p>
                    <p class="font-semibold">$84.00</p>
                </div>
                <div class="flex justify-between border-b pb-3 mt-5">
                    <h5 class="font-semibold uppercase">Subtotal</h5>
                    <p class="font-semibold">$140.00</p>
                </div>
                <div class="flex justify-between border-b pb-3 mt-5">
                    <h5 class="font-semibold uppercase">Shipping</h5>
                    <p class="font-semibold">Free</p>
                </div>
                <div class="flex justify-between border-b pb-3 mt-5">
                    <h5 class="font-semibold uppercase">Total</h5>
                    <p class="font-semibold">$140.00</p>
                </div>
                <div class="flex gap-3 items-center mt-4">
                    <input type="checkbox"
                        class="focus:ring-0 text-primary border border-primary focus:bg-primary focus:outline-none"
                        id="save-default">
                    <label for="save-default" class="text-sm cursor-pointer">Agree to our <a href="terms-condition.html"
                            class="text-primary">terms & conditions</a></label>
                </div>

                <div class="mt-4">
                    <button class="default_btn w-full">place order</button>
                </div>
            </div>
        </div>
    </div>

   </x-front-app-layout> 
