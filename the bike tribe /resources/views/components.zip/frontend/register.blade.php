<x-front-app-layout> 



    <!-- breadcrumbs -->
    <div class="container py-5 flex items-center">
        <a href="{{route('homePage')}}" class="flex  items-center">
            <span class="text-primary">
                <svg width="17" height="17" viewBox="0 0 32 32">
                    <path fill="currentColor"
                        d="m16 2.594l-.719.687l-13 13L3.72 17.72L5 16.437V28h9V18h4v10h9V16.437l1.281 1.282l1.438-1.438l-13-13zm0 2.844l9 9V26h-5V16h-8v10H7V14.437z" />
                </svg>
            </span>
            <span>
                <svg width="22" height="22" viewBox="0 0 24 24">
                    <path fill="currentColor" d="M10 6L8.59 7.41L13.17 12l-4.58 4.59L10 18l6-6l-6-6z" /></svg>
            </span>

        </a>
        <a href="{{route('myAccount')}}?action=register" class="text-secondary text-[13px] sm:text-base"> Register </a>
    </div>
    <!-- breadcrumbs end-->

    <!--register wrapper-->
    <div class="w-full max-w-[500px] mx-auto px-6 py-8 box_shadow mb-14">
        <h4 class="text-[28px] uppercase">Create an account</h4>
        <p class="mb-4 text_md">Register here if you are a new customer.</p>
        <form action="#">
            <div>
                <div>
                    <label class="block">Full Name <span class="text-primary">*</span></label>
                    <input class="w-full border border-[#E9E4E4] rounded focus:ring-0 focus:border-primary mt-1"
                        type="text" placeholder="Jone Doe">
                </div>
                <div class="mt-4">
                    <label>Email Address <span class="text-primary">*</span></label>
                    <input class="w-full border border-[#E9E4E4] rounded focus:ring-0 focus:border-primary mt-1"
                        type="email" placeholder="example@mail.com">
                </div>
                <div class="mt-4">
                    <label class="block">Password <span class="text-primary">*</span></label>
                    <input class="w-full border border-[#E9E4E4] rounded focus:ring-0 focus:border-primary mt-1"
                        type="password" placeholder="type password">
                </div>
                <div class="mt-4">
                    <label class="block">Confirm Password <span class="text-primary">*</span></label>
                    <input class="w-full border border-[#E9E4E4] rounded focus:ring-0 focus:border-primary mt-1"
                        type="password" placeholder="confirm your password">
                </div>
                <div class="sm:flex gap-3 items-center mt-4">
                    <input type="checkbox"
                        class="focus:ring-0 text-primary border border-primary focus:bg-primary focus:outline-none"
                        hidden id="save-default">
                    <label for="save-default">I have read and agree to the <a href="terms-condition.html"
                            class="text-primary">terms & conditions</a> </label>
                </div>
                <div class="mt-4">
                    <button type="submit" class="default_btn w-full">create
                        account</button>
                </div>

            </div>
        </form>

        <div
            class="flex justify-center mt-4 relative after:absolute after:w-full after:h-[1px] after:bg-gray-300 after:top-3">
            <p class="px-2 bg-white z-10">Or login in with</p>
        </div>

        <div class="flex gap-5 mt-4">
            <button class="default_btn w-full bg-facebook">
                <i class="fab fa-facebook-f me-2"></i> Facebook
            </button>
            <button class="default_btn w-full bg-google">
                <i class="fab fa-google me-2"></i> Google
            </button>
        </div>

        <p class="text-center mt-3 mb-0">Already have an account.? <a href="login.html" class="text-primary">Login
                Now</a></p>

    </div>

    </x-front-app-layout> 

