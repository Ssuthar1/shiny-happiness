<div>
    <div class="border-b border-stroke py-4 px-7 dark:border-strokedark">
      <h3 class="font-medium text-black dark:text-white">
       {{ucfirst($mode)}}  
      </h3>
    </div>

      @if (session('error'))
        <div class="w-full">
          <h6 class="mb-3 text-lg font-bold text-red dark:text-[#ad0c16]" style="color: red;">
            {{ session('error') }}
          </h6> 
        </div> 
      @endif
    <div class="p-7">     
        <div class=" flex flex-col gap-5.5 sm:flex-row mb-2">
          <div class="w-full sm:w-1/2">
            <label class="mb-3 block text-sm font-medium text-black dark:text-white"
            for="emailAddress">Title</label>
	     		<select name="itineries_days" id="itineries_days" class="w-full rounded border border-stroke bg-gray py-3 pl-3 pr-4.5 font-medium text-black focus:border-primary focus-visible:outline-none dark:border-strokedark dark:bg-meta-4 dark:text-white dark:focus:border-primary" wire:model="itineries_days" placeholder="">
	                    <option value="">Select Rating</option>
	                    @for($itinery=1;$itinery<=25;$itinery++)
	                		<option value="{{$itinery}}" @if($itineries_days==$itinery) selected @endif >{{$itinery}}</option>
	                	@endfor
	          	</select>
              <x-input-error class="mt-2" :messages="$errors->get('title')" />
          </div>
        </div> 

        <div class="grid grid-cols-3 gap-6">
          <div class="col-span-3 sm:col-span-2">
            <div class="mt-1 flex rounded-md shadow-sm text-2xl font-bold "> 
                <h3></h3>
            </div>
          </div>
        </div>


    	@for($count=1;$count<=$itineries_days;$count++)
	        <div class="grid grid-cols-3 gap-6">
	          <div class="col-span-3 sm:col-span-2">
	             <label class="mb-3 block text-sm font-medium text-black dark:text-white"
            for="emailAddress">Itinery Info : {{$count}}</label>
	            <div class="mt-1 flex rounded-md shadow-sm"> 
	              <input type="text"   class="w-full rounded border border-stroke bg-gray py-3 pl-3 pr-4.5 font-medium text-black focus:border-primary focus-visible:outline-none dark:border-strokedark dark:bg-meta-4 dark:text-white dark:focus:border-primary" wire:model.defer="itineraryInfo.{{$count}}.title" placeholder=""> 
	            </div>
	             <div class="mt-1 flex rounded-md shadow-sm"> 
	              <textarea   name="description" id="description" cols="3" class="w-full rounded border border-stroke bg-gray py-3 pl-3 pr-4.5 font-medium text-black focus:border-primary focus-visible:outline-none dark:border-strokedark dark:bg-meta-4 dark:text-white dark:focus:border-primary" placeholder="Description" wire:model.defer="itineraryInfo.{{$count}}.desc" placeholder="" ></textarea>
	            </div>
	          </div>
	        </div>
        @endfor

        <div class="flex justify-end gap-4.5">
          <button
            class="flex justify-center rounded border border-stroke py-2 px-6 font-medium text-black hover:shadow-1 dark:border-strokedark dark:text-white"
            type="button" wire:click="cancel()">
            Cancel
          </button>
          <div wire:loading.remove>
            <button
              class="flex justify-center rounded bg-primary py-2 px-6 font-medium text-gray hover:bg-opacity-90"
              type="button" wire:click="updateItinery()"   >
              Update Itinery 
            </button> 
           
          </div>
          <div wire:loading>
            <button 
              class="flex justify-center rounded bg-primary py-2 px-6 font-medium text-gray hover:bg-opacity-90"
              type="button">
              Loading.... 
            </button>
          </div>
        </div>
    </div> 
 
</div>