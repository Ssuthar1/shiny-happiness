<x-front-app-layout>  
   
    @include('frontend.includes.home-sections.slider')

    @include('frontend.includes.home-sections.experience-india')

    @include('frontend.includes.home-sections.popular-tours')

    @include('frontend.includes.home-sections.happy-holiday')

    @include('frontend.includes.home-sections.why-choose-us')

    @include('frontend.includes.home-sections.review')

    @include('frontend.includes.home-sections.subscriber-now') 
   
	  
</x-front-app-layout>
