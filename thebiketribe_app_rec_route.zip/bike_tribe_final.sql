-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 17, 2024 at 02:50 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bike_tribe_final`
--

-- --------------------------------------------------------

--
-- Table structure for table `banners`
--

CREATE TABLE `banners` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `sub_title` varchar(255) DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `link_text` varchar(255) DEFAULT NULL,
  `link_url` varchar(255) DEFAULT NULL,
  `banner_location` enum('Main Banner','Home Middle Small Banner','Home Bottom Banner') NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0:Active, 1:Inactive',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `banners`
--

INSERT INTO `banners` (`id`, `title`, `sub_title`, `image`, `description`, `link_text`, `link_url`, `banner_location`, `status`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'Rajasthan is best', NULL, 'public/HfKNf6AdOX1SO4HfjkQqMPdNlGBDvXDVsrJVyomW.jpg', NULL, NULL, NULL, 'Main Banner', 1, NULL, '2024-01-16 02:59:00', '2024-01-16 05:54:10');

-- --------------------------------------------------------

--
-- Table structure for table `destinations`
--

CREATE TABLE `destinations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `destination_category_id` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_tag_keywords` varchar(255) DEFAULT NULL,
  `meta_tag_descriptions` varchar(255) DEFAULT NULL,
  `short_description` varchar(255) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `featured_image` varchar(500) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1 COMMENT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `destinations`
--

INSERT INTO `destinations` (`id`, `destination_category_id`, `title`, `slug`, `meta_title`, `meta_tag_keywords`, `meta_tag_descriptions`, `short_description`, `description`, `featured_image`, `status`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Jaipur', 'jaipur', 'Jaipur', 'Jaipur', NULL, 'Jaipur the pinkcity', 'Jaipur  formerly Jeypore, is the capital and largest city of the Indian state of Rajasthan. As of 2011, the city had a population of 3.1 million, making it the tenth most populous city in the country. Jaipur is also known as the Pink City, due to the dominant colour scheme of its buildings. It is also known as the Paris of India, and C. V. Raman called it the Island of Glory. It is located 268 km (167 miles) from the national capital New Delhi. Jaipur was founded in 1727 by the Kachhwaha Rajput ruler Jai Singh II,  the ruler of Amer, after whom the city is named. It was one of the earliest planned cities of modern India, designed by Vidyadhar Bhattacharya.  During the British Colonial period, the city served as the capital of Jaipur State. After independence in 1947, Jaipur was made the capital of the newly formed state of Rajasthan.', 'ZJJ9nwISOKwiluwmvlG7wjKy8BkY9j-metaamFpcHVyLmpwZw==-.jpg', 1, NULL, '2023-11-27 11:42:49', '2023-11-27 11:42:49'),
(2, NULL, 'Agra', 'agra', 'Agra', 'Agra', NULL, 'Agra is a city on the banks of the Yamuna river in the Indian state of Uttar Pradesh, about 230 kilometres south-east of the national capital Delhi and 330 km west of the state capital Lucknow', 'Agra   is a city on the banks of the Yamuna river in the Indian state of Uttar Pradesh, about 230 kilometres (140 mi) south-east of the national capital Delhi and 330 km west of the state capital Lucknow. With a population of roughly 1.6 million, Agra is the fourth-most populous city in Uttar Pradesh and twenty-third most populous city in India. \n\nAgra\'s notable historical period began during Sikandar Lodi\'s reign, but the golden age of the city began with the Mughals. Agra was the foremost city of the Indian subcontinent and the capital of the Mughal Empire under Mughal emperors Babur, Humayun, Akbar, Jahangir and Shah Jahan. Under Mughal rule, Agra became a centre for learning, arts, commerce, and religion, and saw the construction of the Agra Fort, Sikandra and Agra\'s most prized monument, the Taj Mahal, Constructed between 1632 and 1648 by the Mughal Emperor Shah Jahan as a loving remembrance of his beloved wife Mumtaz Mahal .With the decline of the Mughal empire in the late 18th century.', '65h2OwwBJ92Y1a1uhi3KCOO8yVhsat-metaVGFqX01haGFsLF9BZ3JhLF9JbmRpYS5qcGc=-.jpg', 1, NULL, '2023-11-27 12:13:27', '2023-11-27 12:13:27'),
(3, NULL, 'Goa', NULL, 'Goa', NULL, NULL, 'Goa', NULL, NULL, 1, NULL, '2024-01-17 01:08:40', '2024-01-17 01:08:40');

-- --------------------------------------------------------

--
-- Table structure for table `destination_categories`
--

CREATE TABLE `destination_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_tag_keywords` varchar(255) DEFAULT NULL,
  `meta_tag_descriptions` varchar(255) DEFAULT NULL,
  `short_description` varchar(255) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1 COMMENT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `destination_categories`
--

INSERT INTO `destination_categories` (`id`, `title`, `slug`, `meta_title`, `meta_tag_keywords`, `meta_tag_descriptions`, `short_description`, `description`, `status`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'jaipur ', NULL, 'jaipur ', NULL, NULL, 'jaipur short description ', NULL, 1, NULL, '2024-01-16 05:24:01', '2024-01-16 05:24:01'),
(2, 'Harayana', NULL, 'Harayana', NULL, NULL, 'Harayana short description', 'Harayana long description&nbsp;', 1, NULL, '2024-01-16 05:26:51', '2024-01-16 05:40:57'),
(3, 'Punjab', NULL, 'Punjab', 'Punjab', NULL, 'Punjab short description', 'Punjab lonf description', 1, NULL, '2024-01-16 05:51:29', '2024-01-16 05:53:50');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `image_banks`
--

CREATE TABLE `image_banks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `caption` varchar(1000) DEFAULT NULL,
  `tags` varchar(1000) DEFAULT NULL,
  `image_url` varchar(255) NOT NULL,
  `big_url` varchar(255) DEFAULT NULL,
  `medium_url` varchar(255) DEFAULT NULL,
  `thumb_url` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `image_banks`
--

INSERT INTO `image_banks` (`id`, `title`, `caption`, `tags`, `image_url`, `big_url`, `medium_url`, `thumb_url`, `status`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'jaipur subhash', 'jaipur subhash', 'jaipur subhash', 'storage/uploads/023770-23773_1705386877.jpg', NULL, NULL, NULL, 1, NULL, '2024-01-16 01:04:37', '2024-01-16 01:04:37'),
(14, 'ravi ', 'ravi ', 'ravi ', 'storage/uploads/Chrysanthemum_1705392852.jpg', NULL, NULL, NULL, 1, NULL, '2024-01-16 02:44:12', '2024-01-16 02:44:12'),
(15, 'WAY above and beyond a food tour!', 'WAY above and beyond a food tour!', 'WAY above and beyond a food tour!', 'storage/uploads/Koala_1705392996.jpg', NULL, NULL, NULL, 1, NULL, '2024-01-16 02:46:37', '2024-01-16 02:46:37'),
(16, 'sunmm', 'sunmm', 'sunmm', 'storage/uploads/Jellyfish_1705393070.jpg', NULL, NULL, NULL, 1, NULL, '2024-01-16 02:47:50', '2024-01-16 02:47:50'),
(17, 'ravi ', 'ravi ', 'ravi ', 'storage/uploads/Lighthouse_1705393140.jpg', NULL, NULL, NULL, 1, NULL, '2024-01-16 02:49:00', '2024-01-16 02:49:00'),
(18, 'sunmm', 'sunmm', 'sunmm', 'storage/uploads/Desert_1705393157.jpg', NULL, NULL, NULL, 1, NULL, '2024-01-16 02:49:17', '2024-01-16 02:49:17'),
(19, 'sunmm', 'sunmm', 'sunmm', 'storage/uploads/Hydrangeas_1705393265.jpg', NULL, NULL, NULL, 1, NULL, '2024-01-16 02:51:05', '2024-01-16 02:51:05'),
(20, 'ravi ', 'ravi ', 'ravi ', 'storage/uploads/Tulips_1705393275.jpg', NULL, NULL, NULL, 1, NULL, '2024-01-16 02:51:15', '2024-01-16 02:51:15'),
(21, 'sunmm', 'sunmm', 'sunmm', 'storage/uploads/Lighthouse_1705393308.jpg', NULL, NULL, NULL, 1, NULL, '2024-01-16 02:51:48', '2024-01-16 02:51:48'),
(22, 'jaipur ', 'jaipur ', 'jaipur ', 'storage/uploads/Desert_1705402441.jpg', NULL, NULL, NULL, 1, NULL, '2024-01-16 05:24:01', '2024-01-16 05:24:01'),
(23, 'jaipur ', 'jaipur ', 'jaipur ', 'storage/uploads/Koala_1705402611.jpg', NULL, NULL, NULL, 1, NULL, '2024-01-16 05:26:51', '2024-01-16 05:26:51'),
(24, 'jaipur ', 'jaipur ', 'jaipur ', 'storage/uploads/Lighthouse_1705402677.jpg', NULL, NULL, NULL, 1, NULL, '2024-01-16 05:27:57', '2024-01-16 05:27:57'),
(25, 'Harayana', 'Harayana', 'Harayana', 'storage/uploads/Hydrangeas_1705403457.jpg', NULL, NULL, NULL, 1, NULL, '2024-01-16 05:40:57', '2024-01-16 05:40:57'),
(26, 'Punjab', 'Punjab', 'Punjab', 'storage/uploads/Tulips_1705404090.jpg', NULL, NULL, NULL, 1, NULL, '2024-01-16 05:51:30', '2024-01-16 05:51:30'),
(27, 'Goa', 'Goa', 'Goa', 'storage/uploads/Chrysanthemum_1705473520.jpg', NULL, NULL, NULL, 1, NULL, '2024-01-17 01:08:40', '2024-01-17 01:08:40');

-- --------------------------------------------------------

--
-- Table structure for table `image_infos`
--

CREATE TABLE `image_infos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `type` enum('tour','tour_category','destination','destination_category','post','category','page','slider','blog','testimonial') DEFAULT NULL,
  `image_position` enum('main_image','gallery_image','banner_image') DEFAULT NULL,
  `property_id` bigint(20) UNSIGNED DEFAULT NULL,
  `image_bank_id` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `image_infos`
--

INSERT INTO `image_infos` (`id`, `type`, `image_position`, `property_id`, `image_bank_id`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'tour_category', 'main_image', 6, 1, NULL, '2024-01-16 01:04:37', '2024-01-16 01:04:37'),
(11, 'tour', 'main_image', 11, 13, NULL, '2024-01-16 02:41:32', '2024-01-16 02:41:32'),
(12, 'tour', 'main_image', 12, 14, '2024-01-16 02:49:00', '2024-01-16 02:44:12', '2024-01-16 02:49:00'),
(13, 'tour', 'main_image', 13, 16, '2024-01-16 02:49:17', '2024-01-16 02:47:50', '2024-01-16 02:49:17'),
(14, 'testimonial', 'main_image', 13, 19, '2024-01-16 02:51:48', '2024-01-16 02:51:05', '2024-01-16 02:51:48'),
(15, 'testimonial', 'main_image', 12, 20, NULL, '2024-01-16 02:51:15', '2024-01-16 02:51:15'),
(16, 'testimonial', 'main_image', 13, 21, NULL, '2024-01-16 02:51:48', '2024-01-16 02:51:48'),
(17, 'destination_category', 'main_image', 1, 22, NULL, '2024-01-16 05:24:01', '2024-01-16 05:24:01'),
(18, 'destination_category', 'main_image', 2, 23, '2024-01-16 05:27:57', '2024-01-16 05:26:51', '2024-01-16 05:27:57'),
(19, 'destination_category', 'main_image', 2, 24, '2024-01-16 05:40:57', '2024-01-16 05:27:57', '2024-01-16 05:40:57'),
(20, 'destination_category', 'main_image', 2, 25, NULL, '2024-01-16 05:40:57', '2024-01-16 05:40:57'),
(21, 'destination_category', 'main_image', 3, 26, NULL, '2024-01-16 05:51:30', '2024-01-16 05:51:30'),
(22, 'destination', 'main_image', 3, 27, NULL, '2024-01-17 01:08:40', '2024-01-17 01:08:40');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(7, '2021_12_13_072624_create_settings_table', 1),
(25, '2023_09_21_083145_create_subscribers_table', 2),
(26, '2023_06_19_050210_create_banners_table', 3),
(27, '2023_08_27_125045_create_tours_table', 3),
(28, '2023_08_27_125053_create_destinations_table', 3),
(29, '2023_08_27_125131_create_tour_categories_table', 3),
(30, '2023_08_27_125156_create_destination_categories_table', 3),
(31, '2023_08_27_125421_create_testimonials_table', 3),
(32, '2014_10_12_100000_create_password_reset_tokens_table', 4),
(33, '2022_07_03_122321_create_image_banks_table', 4),
(34, '2022_07_16_160453_create_image_info_table', 4),
(35, '2023_05_23_103348_create_permission_tables', 4);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\User', 1),
(1, 'App\\Models\\User', 2);

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` char(36) NOT NULL,
  `type` varchar(255) NOT NULL,
  `notifiable_type` varchar(255) NOT NULL,
  `notifiable_id` bigint(20) UNSIGNED NOT NULL,
  `data` text NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'roles-list', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(2, 'roles-create', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(3, 'roles-edit', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(4, 'roles-delete', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(5, 'view-admin', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(6, 'add-admin', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(7, 'edit-admin', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(8, 'delete-admin', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(9, 'view-customers', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(10, 'add-customers', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(11, 'edit-customers', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(12, 'delete-customers', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(13, 'view-products', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(14, 'add-products', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(15, 'edit-products', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(16, 'delete-products', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(17, 'view-category', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(18, 'add-category', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(19, 'edit-category', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(20, 'delete-category', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(21, 'view-orders', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(22, 'add-orders', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(23, 'edit-orders', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(24, 'delete-orders', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(25, 'delete-banners', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(26, 'view-banners', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(27, 'add-banners', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(28, 'edit-banners', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(29, 'view-settings', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(30, 'edit-settings', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(31, 'view-products-inventory', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(32, 'product-inventory-add', 'web', '2023-07-02 18:46:33', '2023-07-02 18:46:33'),
(33, 'product-inventory-edit', 'web', '2023-07-02 18:46:34', '2023-07-02 18:46:34'),
(34, 'product-inventory-delete', 'web', '2023-07-02 18:46:34', '2023-07-02 18:46:34'),
(35, 'web-settings', 'web', '2024-01-16 03:23:09', '2024-01-16 03:23:09');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `guard_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'Super Admin', 'web', '2023-06-23 18:35:28', '2023-06-23 18:35:28'),
(2, 'Admin', 'web', '2023-06-23 18:35:28', '2023-06-23 18:35:28'),
(3, 'Sub Admin', 'web', '2023-06-23 18:35:28', '2023-06-23 18:35:28'),
(4, 'Customer', 'web', '2023-06-23 18:35:28', '2023-06-23 18:35:28');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(9, 2),
(10, 2),
(11, 2),
(12, 2),
(13, 2),
(14, 2),
(15, 2),
(16, 2),
(17, 2),
(18, 2),
(19, 2),
(20, 2),
(21, 2),
(22, 2),
(23, 2),
(24, 2),
(25, 2),
(26, 2),
(27, 2),
(28, 2),
(29, 2),
(30, 2),
(31, 2),
(32, 2),
(33, 2),
(34, 2),
(35, 2);

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `tab` varchar(255) DEFAULT NULL,
  `type` enum('image','text','textarea','editor') DEFAULT NULL,
  `option_name` varchar(255) DEFAULT NULL,
  `option_key` varchar(200) NOT NULL,
  `option_type` varchar(200) NOT NULL,
  `option_value` mediumtext DEFAULT NULL,
  `special_option` varchar(200) NOT NULL,
  `is_hide` varchar(20) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `title`, `tab`, `type`, `option_name`, `option_key`, `option_type`, `option_value`, `special_option`, `is_hide`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, NULL, NULL, NULL, 'Website Logo', 'logo', 'file', NULL, '', '0', NULL, '2024-01-17 00:49:12', '2024-01-17 00:49:12'),
(2, NULL, NULL, NULL, 'Footer Logo', 'footer_logo', 'file', NULL, '', '0', NULL, '2024-01-17 00:49:12', '2024-01-17 00:49:12'),
(3, NULL, NULL, NULL, 'Facebook Link', 'facebook_link', 'test', NULL, '', '0', NULL, '2024-01-17 00:49:12', '2024-01-17 00:49:12'),
(4, NULL, NULL, NULL, 'Twitter Link', 'twitter_link', 'test', NULL, '', '0', NULL, '2024-01-17 00:49:12', '2024-01-17 00:49:12'),
(5, NULL, NULL, NULL, 'Instagram Link', 'instagram_link', 'test', NULL, '', '0', NULL, '2024-01-17 00:49:12', '2024-01-17 00:49:12'),
(6, NULL, NULL, NULL, 'Copyright Message', 'copyright_message', 'test', 'hello', '', '0', NULL, '2024-01-17 00:49:12', '2024-01-17 00:55:06');

-- --------------------------------------------------------

--
-- Table structure for table `shop_customers`
--

CREATE TABLE `shop_customers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `gender` enum('male','female') NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shop_customers`
--

INSERT INTO `shop_customers` (`id`, `name`, `email`, `photo`, `gender`, `phone`, `birthday`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Miss Sally Rath 3', 'margarete.bode@example.net', NULL, 'male', '(769) 604-5757', '2002-12-06', '2022-12-27 08:19:09', '2023-09-14 05:58:42', NULL),
(2, 'Katarina Runolfsson', 'angela34@example.org', NULL, 'female', '458.354.9311', '1997-07-27', '2023-02-17 16:27:53', '2023-06-22 13:12:30', NULL),
(3, 'Melba Ebert', 'oleffler@example.net', NULL, 'female', '+1 (743) 613-2492', '1988-10-24', '2022-12-15 20:18:00', '2023-07-26 14:00:18', NULL),
(4, 'Ms. Camille Leannon DDS', 'henderson01@example.org', NULL, 'female', '+1.860.805.0890', '2002-10-10', '2023-01-16 16:18:34', '2023-07-18 02:07:05', NULL),
(5, 'Margot Reinger', 'ecollins@example.com', NULL, 'female', '386.687.8229', '2003-06-25', '2023-01-07 01:53:25', '2023-07-08 20:55:25', NULL),
(6, 'Cecilia Feest', 'nya79@example.com', NULL, 'male', '+1-469-943-4473', '1993-04-08', '2022-12-24 09:28:34', '2023-04-22 03:19:47', NULL),
(7, 'Guadalupe Johnston IV', 'hettinger.adrian@example.org', NULL, 'male', '770.726.7382', '2000-04-28', '2022-11-21 15:37:54', '2023-04-22 05:00:41', NULL),
(8, 'Davion Schumm IV', 'rodger.kautzer@example.org', NULL, 'male', '(314) 513-6005', '1988-11-07', '2022-10-28 15:37:15', '2023-07-13 03:15:09', NULL),
(9, 'Chasity Hackett', 'francisca.mills@example.com', NULL, 'male', '+1-802-970-5118', '2003-02-22', '2023-01-08 14:57:02', '2023-07-13 05:08:50', NULL),
(10, 'Clinton O\'Kon', 'cecile.ebert@example.org', NULL, 'male', '+1.352.367.5919', '2001-06-05', '2022-12-04 03:49:41', '2023-07-09 16:25:39', NULL),
(11, 'Aleen Aufderhar', 'hgulgowski@example.com', NULL, 'female', '+1-681-610-5654', '2000-09-22', '2023-01-15 08:59:37', '2023-06-06 07:08:41', NULL),
(12, 'Prof. Alisa Upton DVM', 'ibecker@example.net', NULL, 'male', '(878) 751-7110', '2004-01-03', '2022-09-22 04:40:56', '2023-05-06 12:12:05', NULL),
(13, 'Elwin Harber MD', 'jjohnston@example.net', NULL, 'male', '(262) 995-2712', '2004-06-04', '2022-12-26 01:00:53', '2023-06-17 21:48:56', NULL),
(14, 'Garth Dibbert', 'gutkowski.oswald@example.com', NULL, 'male', '573.607.3248', '1989-07-09', '2023-03-09 16:37:02', '2023-08-14 02:16:40', NULL),
(15, 'Lisette Bauch', 'hermiston.murphy@example.net', NULL, 'female', '1-385-897-2160', '2001-04-08', '2023-03-11 13:11:40', '2023-04-25 01:21:43', NULL),
(16, 'Prof. Karelle Kerluke IV', 'laurianne.hessel@example.com', NULL, 'female', '(281) 747-2883', '2004-06-30', '2023-01-30 06:38:20', '2023-07-02 01:23:21', NULL),
(17, 'Germaine Ankunding', 'avis.kessler@example.net', NULL, 'female', '(928) 397-2071', '1989-01-04', '2022-11-23 11:36:28', '2023-06-09 00:08:09', NULL),
(18, 'Grayson Lang', 'jadyn.hill@example.net', NULL, 'female', '+1-305-777-0961', '1999-11-14', '2022-11-17 14:29:36', '2023-05-21 20:35:14', NULL),
(19, 'Gwen Hyatt', 'zane.bergstrom@example.org', NULL, 'male', '+1.973.597.5334', '2002-11-21', '2022-09-15 06:18:58', '2023-06-30 00:09:59', NULL),
(20, 'Mr. Tobin Dach', 'mlubowitz@example.com', NULL, 'female', '1-559-712-0024', '2003-09-07', '2023-01-27 02:19:59', '2023-08-08 14:43:48', NULL),
(21, 'Mr. Isac Goyette', 'gshanahan@example.com', NULL, 'female', '1-913-971-5613', '1999-08-10', '2022-10-19 21:36:23', '2023-08-21 18:30:54', NULL),
(22, 'Brenna Hill', 'jprosacco@example.com', NULL, 'female', '(859) 402-7067', '1997-01-28', '2022-11-10 09:41:51', '2023-04-22 08:23:30', NULL),
(23, 'Kendall Emmerich I', 'graynor@example.net', NULL, 'male', '(458) 542-1864', '1996-03-21', '2023-02-23 16:39:32', '2023-05-29 00:02:25', NULL),
(24, 'Miller Nolan Jr.', 'jschamberger@example.com', NULL, 'female', '+1-563-695-6358', '1991-01-05', '2023-03-13 04:06:26', '2023-05-04 20:04:18', NULL),
(25, 'Miss Lia D\'Amore I', 'wgibson@example.net', NULL, 'female', '1-480-300-9815', '1989-01-08', '2022-10-23 16:12:26', '2023-05-04 12:59:21', NULL),
(26, 'Prof. Anastacio Nienow', 'emely25@example.com', NULL, 'female', '1-732-397-8781', '1996-03-03', '2022-10-06 17:18:10', '2023-06-13 12:16:35', NULL),
(27, 'Prof. Amir Altenwerth', 'aubrey43@example.com', NULL, 'male', '757.527.6017', '1994-04-09', '2023-03-05 05:07:50', '2023-07-12 08:28:20', NULL),
(28, 'Webster Smitham', 'schneider.oma@example.com', NULL, 'male', '+1-360-301-4606', '1995-05-16', '2022-11-25 23:54:29', '2023-09-03 23:36:30', NULL),
(29, 'Brenna Cole', 'marjolaine.ratke@example.com', NULL, 'female', '+1 (929) 504-6338', '1989-08-02', '2023-03-11 17:04:07', '2023-04-24 07:11:56', NULL),
(30, 'Merlin Welch I', 'amaya99@example.org', NULL, 'female', '+1 (610) 399-1160', '1991-11-28', '2023-03-05 13:38:38', '2023-06-10 07:34:41', NULL),
(31, 'Priscilla Zulauf', 'carolanne.yost@example.net', NULL, 'female', '(260) 585-3169', '1991-11-22', '2022-10-27 23:32:00', '2023-04-21 15:51:22', NULL),
(32, 'Kenna Jenkins', 'antoinette.osinski@example.net', NULL, 'male', '(401) 551-2593', '2001-11-14', '2023-02-19 10:08:50', '2023-09-03 08:41:13', NULL),
(33, 'Emerson Nitzsche', 'ned68@example.org', NULL, 'male', '445-432-6385', '1990-06-29', '2022-11-07 00:21:00', '2023-04-19 04:32:28', NULL),
(34, 'Orval Morar IV', 'katlynn.fisher@example.net', NULL, 'male', '+1-845-219-6485', '1995-02-25', '2023-02-10 07:05:42', '2023-07-14 04:42:21', NULL),
(35, 'Jeramy Mohr', 'lemke.gustave@example.org', NULL, 'female', '+1-770-727-1869', '1991-06-11', '2022-11-18 06:31:32', '2023-04-20 19:31:00', NULL),
(36, 'Prof. Jaron Goldner MD', 'nyasia86@example.org', NULL, 'female', '+1 (650) 712-9123', '1989-01-25', '2023-02-27 17:05:29', '2023-04-14 23:49:56', NULL),
(37, 'Dr. Allie Block', 'eli31@example.net', NULL, 'male', '339.593.2813', '1991-08-01', '2022-11-18 09:15:49', '2023-07-27 14:16:11', NULL),
(38, 'Hannah Kohler', 'hkreiger@example.org', NULL, 'male', '+1.505.632.6026', '2004-05-21', '2022-12-04 03:34:06', '2023-08-05 09:46:29', NULL),
(39, 'Miss Joanne Goyette DVM', 'stanton.ayla@example.net', NULL, 'male', '915-751-2186', '1996-12-26', '2023-01-03 18:54:51', '2023-05-28 09:02:25', NULL),
(40, 'Delfina Hyatt', 'asha.hettinger@example.com', NULL, 'female', '+14138844408', '2002-08-16', '2022-12-17 06:24:58', '2023-08-26 22:48:48', NULL),
(41, 'Dallin McKenzie', 'elena.walker@example.org', NULL, 'male', '+1-717-405-9611', '1989-03-22', '2022-09-17 23:43:26', '2023-06-13 19:23:43', NULL),
(42, 'Winston Bode', 'otis.casper@example.com', NULL, 'male', '978.655.7395', '1999-04-08', '2022-12-22 19:30:11', '2023-09-03 09:56:43', NULL),
(43, 'Sigmund Mante', 'abshire.marilie@example.net', NULL, 'female', '1-619-748-2749', '1998-05-12', '2023-01-30 05:18:50', '2023-06-18 07:00:22', NULL),
(44, 'Jadon Smitham', 'utreutel@example.com', NULL, 'female', '706.696.3837', '1995-05-30', '2022-12-21 18:29:40', '2023-07-17 03:29:48', NULL),
(45, 'Marco Heidenreich', 'aurelia.rowe@example.org', NULL, 'female', '+1.530.379.9658', '1989-10-01', '2023-02-04 01:38:32', '2023-05-10 20:35:17', NULL),
(46, 'Charley Ondricka', 'erick.bode@example.net', NULL, 'male', '+1 (515) 239-3865', '2002-12-12', '2022-11-24 03:56:08', '2023-05-04 15:05:26', NULL),
(47, 'Maeve Johnston', 'ekshlerin@example.com', NULL, 'female', '321-246-3978', '1998-11-20', '2022-10-01 02:28:17', '2023-06-18 14:04:48', NULL),
(48, 'Joelle Runolfsdottir', 'rlang@example.net', NULL, 'male', '+1 (417) 665-4584', '1998-11-11', '2023-01-09 12:29:54', '2023-04-25 03:56:16', NULL),
(49, 'Erling Von', 'esmeralda82@example.org', NULL, 'female', '(484) 665-3812', '2002-11-08', '2022-09-30 06:11:29', '2023-06-02 13:43:45', NULL),
(50, 'Mr. Harley Ryan', 'ray75@example.org', NULL, 'male', '1-601-578-9989', '2003-07-11', '2023-01-23 12:31:31', '2023-04-25 00:11:36', NULL),
(51, 'Janiya Wyman', 'emard.christelle@example.org', NULL, 'male', '(737) 962-0090', '2005-06-12', '2022-12-07 12:46:24', '2023-05-15 18:17:39', NULL),
(52, 'Harold Legros', 'conn.triston@example.net', NULL, 'female', '+1-559-361-4592', '2000-07-30', '2022-10-07 00:59:10', '2023-09-05 20:42:19', NULL),
(53, 'Hubert Rosenbaum II', 'lubowitz.elwyn@example.net', NULL, 'male', '1-408-544-8772', '1988-10-18', '2023-02-19 15:35:36', '2023-06-23 08:52:31', NULL),
(54, 'Albert Hand', 'christa.wyman@example.com', NULL, 'male', '+1-423-529-9472', '1991-12-07', '2023-03-12 13:09:23', '2023-06-12 12:48:18', NULL),
(55, 'Howard Howell', 'casper.elody@example.com', NULL, 'female', '(580) 966-3111', '1997-03-28', '2022-12-29 04:07:04', '2023-05-11 20:03:29', NULL),
(56, 'Dr. Colton Schaden Jr.', 'maynard.hill@example.com', NULL, 'male', '(580) 405-7968', '1989-07-02', '2022-11-25 06:08:47', '2023-04-27 22:59:19', NULL),
(57, 'Cruz Konopelski', 'leuschke.clarissa@example.com', NULL, 'male', '+1.240.724.0659', '2004-10-06', '2022-10-26 10:32:12', '2023-05-16 21:20:23', NULL),
(58, 'Kraig Reilly', 'guadalupe80@example.com', NULL, 'female', '540.854.8548', '2003-08-22', '2023-01-13 11:35:54', '2023-06-08 04:30:25', NULL),
(59, 'Tomas Grant', 'enos59@example.net', NULL, 'male', '(650) 669-4257', '1994-08-27', '2022-10-19 20:26:34', '2023-09-02 07:36:51', NULL),
(60, 'Karianne Jacobi', 'king77@example.org', NULL, 'female', '(931) 781-1942', '1995-12-22', '2022-11-11 21:59:12', '2023-04-15 18:46:34', NULL),
(61, 'Obie Kessler III', 'bcrist@example.net', NULL, 'male', '(575) 823-6602', '1998-12-19', '2022-10-09 22:35:07', '2023-09-08 04:14:46', NULL),
(62, 'Timmothy Sawayn', 'lbernier@example.org', NULL, 'female', '725.345.8612', '1994-05-06', '2022-10-18 08:06:40', '2023-07-27 00:30:37', NULL),
(63, 'Ms. Edythe Kemmer MD', 'mgerlach@example.com', NULL, 'male', '+18327227805', '2000-08-13', '2022-12-19 11:35:32', '2023-04-18 21:53:19', NULL),
(64, 'Leonora Yost DVM', 'reichert.vinnie@example.net', NULL, 'male', '+1-253-602-0349', '1997-04-26', '2023-01-23 18:18:50', '2023-05-07 06:32:47', NULL),
(65, 'Noemie Fritsch', 'kennedi22@example.org', NULL, 'male', '+19345443103', '1988-10-25', '2023-02-01 19:01:14', '2023-08-11 23:54:48', NULL),
(66, 'Beaulah Rogahn', 'ryost@example.com', NULL, 'female', '+1-938-659-8192', '2004-04-26', '2022-12-27 09:38:50', '2023-05-10 05:56:17', NULL),
(67, 'Kiel Hahn Sr.', 'houston19@example.com', NULL, 'male', '1-606-897-9643', '1995-06-21', '2022-11-09 04:36:53', '2023-05-01 13:21:48', NULL),
(68, 'Christa Dach', 'sabrina36@example.org', NULL, 'female', '352.515.5823', '1997-11-27', '2022-11-14 12:34:59', '2023-06-02 12:25:33', NULL),
(69, 'Dante Nader DVM', 'bkessler@example.net', NULL, 'male', '1-518-326-9482', '1994-05-21', '2022-12-30 04:01:35', '2023-06-07 16:01:32', NULL),
(70, 'Elna Gleason', 'schiller.mara@example.org', NULL, 'male', '1-937-947-6040', '2005-08-01', '2022-10-12 05:28:49', '2023-07-23 01:43:58', NULL),
(71, 'Ms. Cindy McKenzie', 'kimberly.wisozk@example.com', NULL, 'female', '+1-484-804-0170', '2003-12-27', '2022-11-08 21:42:36', '2023-06-14 23:28:41', NULL),
(72, 'Ashlee Tromp', 'daugherty.lottie@example.org', NULL, 'male', '(520) 647-8530', '2004-04-24', '2022-10-05 09:12:34', '2023-09-05 11:19:47', NULL),
(73, 'Desiree Keeling', 'vincent87@example.net', NULL, 'male', '+1.678.293.9344', '2005-09-01', '2023-01-20 22:48:09', '2023-05-01 10:54:59', NULL),
(74, 'Dr. Wilton Grimes PhD', 'dwhite@example.net', NULL, 'male', '+1-586-627-8436', '1996-09-26', '2022-12-08 02:22:31', '2023-04-29 16:56:32', NULL),
(75, 'Dr. Lesly Treutel', 'smorar@example.net', NULL, 'male', '(240) 652-2789', '1997-11-01', '2022-12-19 19:22:27', '2023-07-04 01:20:23', NULL),
(76, 'Alfred Miller', 'gleichner.dora@example.net', NULL, 'male', '973.571.9760', '2001-07-16', '2023-02-21 20:52:20', '2023-06-21 17:06:46', NULL),
(77, 'Charity Schamberger', 'lonie.olson@example.org', NULL, 'male', '831.460.7558', '1993-08-07', '2022-12-15 07:13:29', '2023-07-31 00:12:24', NULL),
(78, 'Casper Hettinger', 'brown.jacinthe@example.com', NULL, 'male', '+1 (785) 971-3005', '1989-06-15', '2022-12-01 20:20:31', '2023-05-25 06:39:17', NULL),
(79, 'Jess Brown', 'marquardt.estella@example.org', NULL, 'male', '956-499-1599', '1996-09-16', '2022-11-30 09:13:30', '2023-06-24 06:10:22', NULL),
(80, 'Lucius Green', 'mwiegand@example.org', NULL, 'female', '315.376.5653', '1998-07-05', '2022-11-01 22:25:17', '2023-06-19 03:02:08', NULL),
(81, 'Loma Tillman', 'monahan.florida@example.org', NULL, 'female', '760-606-2293', '1994-01-26', '2023-01-25 15:30:18', '2023-07-15 22:52:26', NULL),
(82, 'Mrs. Maryjane Mills', 'uhahn@example.org', NULL, 'male', '1-201-747-0073', '1989-02-14', '2022-12-30 07:13:19', '2023-05-09 09:32:26', NULL),
(83, 'Renee Watsica', 'lester01@example.net', NULL, 'female', '916.989.2973', '2003-02-18', '2022-11-21 09:21:56', '2023-07-15 06:15:30', NULL),
(84, 'Prof. Jarret Lowe', 'cummings.hallie@example.com', NULL, 'female', '701.413.4749', '1990-08-30', '2023-02-22 08:57:51', '2023-07-01 20:50:53', NULL),
(85, 'Prof. Giuseppe Schmeler', 'peyton.hoppe@example.com', NULL, 'male', '+12546615065', '2005-03-25', '2023-03-05 17:05:37', '2023-06-01 18:19:10', NULL),
(86, 'Rocky Nicolas', 'purdy.augusta@example.org', NULL, 'male', '480.327.6121', '2003-10-16', '2023-03-06 13:39:24', '2023-08-02 05:22:04', NULL),
(87, 'Anna Ernser', 'odell.lehner@example.com', NULL, 'female', '(336) 618-0798', '1995-12-08', '2023-03-11 02:21:41', '2023-07-03 05:15:59', NULL),
(88, 'Prof. Brandon Batz', 'ullrich.obie@example.com', NULL, 'male', '678.570.0263', '1988-10-05', '2022-11-09 12:22:59', '2023-09-09 20:12:56', NULL),
(89, 'Rosie Mayer', 'art.torphy@example.net', NULL, 'male', '726-486-4561', '1996-12-16', '2022-10-01 13:03:04', '2023-05-04 13:39:04', NULL),
(90, 'Henriette Rolfson', 'nyundt@example.net', NULL, 'male', '+12674634604', '2004-02-27', '2023-01-16 19:32:38', '2023-08-22 16:53:53', NULL),
(91, 'Dashawn Predovic', 'greichel@example.net', NULL, 'female', '(931) 387-7540', '1993-09-08', '2022-11-26 10:26:37', '2023-06-01 00:59:35', NULL),
(92, 'Lola Reilly', 'kris.adrien@example.com', NULL, 'male', '364.582.7187', '1991-07-27', '2023-01-06 13:30:33', '2023-09-01 02:20:34', NULL),
(93, 'Dr. Kaleb Gulgowski', 'senger.horacio@example.org', NULL, 'female', '480.386.6121', '2001-11-17', '2023-01-02 20:34:43', '2023-07-31 10:21:26', NULL),
(94, 'Araceli Fay Sr.', 'xprice@example.org', NULL, 'male', '+1-323-257-5637', '2001-01-17', '2022-09-25 04:22:55', '2023-05-10 12:30:38', NULL),
(95, 'Kobe Orn', 'walter.janick@example.net', NULL, 'male', '(724) 210-4030', '1995-10-14', '2023-03-12 04:44:04', '2023-09-12 09:53:27', NULL),
(96, 'Ms. Mabel Armstrong', 'qhill@example.com', NULL, 'male', '+1.929.536.8041', '1997-12-03', '2022-10-20 04:48:35', '2023-07-23 08:28:28', NULL),
(97, 'Webster Cassin', 'breitenberg.kim@example.org', NULL, 'female', '+1 (631) 359-4771', '2000-06-16', '2022-10-31 14:16:53', '2023-09-09 11:53:10', NULL),
(98, 'Mackenzie Koepp', 'leffler.libby@example.org', NULL, 'male', '252-747-8312', '1995-11-05', '2022-11-02 20:37:03', '2023-06-01 14:35:36', NULL),
(99, 'Dr. Yoshiko McDermott', 'frederick.vonrueden@example.com', NULL, 'male', '878-262-8876', '1997-05-12', '2022-12-02 02:44:33', '2023-06-30 14:11:40', NULL),
(100, 'Mr. Sheridan Krajcik', 'kariane.blick@example.org', NULL, 'female', '+1-586-598-5287', '2000-10-03', '2022-09-22 17:28:36', '2023-07-20 19:27:44', NULL),
(101, 'Zackery Olson', 'donnell08@example.net', NULL, 'female', '+1-540-755-9478', '2002-12-10', '2022-12-15 08:18:27', '2023-07-21 15:12:35', NULL),
(102, 'Ezekiel Casper III', 'huels.emil@example.org', NULL, 'male', '+1-760-744-6933', '1990-06-29', '2022-10-14 19:37:17', '2023-08-18 20:59:20', NULL),
(103, 'Nikolas Waelchi MD', 'lindsay12@example.com', NULL, 'female', '+1 (838) 615-6180', '1994-11-14', '2022-10-24 06:16:21', '2023-07-18 08:37:57', NULL),
(104, 'Aiyana Kirlin', 'johnathan99@example.org', NULL, 'male', '580-819-1531', '1991-08-22', '2023-02-02 18:47:00', '2023-08-20 16:40:02', NULL),
(105, 'Clair Hagenes', 'brooke.skiles@example.com', NULL, 'female', '+1-727-313-3689', '1992-11-28', '2022-11-26 12:20:00', '2023-05-31 09:23:42', NULL),
(106, 'Nathan Stamm', 'leannon.emmet@example.org', NULL, 'female', '+1-931-314-7581', '2004-08-21', '2022-11-05 18:02:32', '2023-07-07 21:55:50', NULL),
(107, 'Prof. Kaitlyn Botsford MD', 'sonya45@example.org', NULL, 'male', '845-306-2185', '2002-06-21', '2022-11-10 04:55:15', '2023-05-29 03:40:32', NULL),
(108, 'Prof. Raven O\'Connell', 'gcarter@example.com', NULL, 'male', '(269) 739-1984', '1997-03-25', '2022-10-11 08:53:25', '2023-08-08 08:36:47', NULL),
(109, 'Marc Stehr', 'brooklyn.tromp@example.org', NULL, 'female', '1-757-321-0923', '1996-03-17', '2023-02-18 11:34:36', '2023-06-02 04:51:27', NULL),
(110, 'Jedediah Lakin', 'yschimmel@example.net', NULL, 'male', '(910) 531-3927', '1989-02-11', '2023-03-10 09:04:33', '2023-05-15 09:43:34', NULL),
(111, 'Mariano Wuckert', 'esta.labadie@example.org', NULL, 'male', '+1.435.709.1184', '2001-07-24', '2022-12-29 22:04:36', '2023-08-31 18:58:43', NULL),
(112, 'Miss Avis Ferry MD', 'vida96@example.org', NULL, 'female', '+1 (678) 949-6146', '2002-03-22', '2022-11-18 14:46:45', '2023-08-22 22:20:30', NULL),
(113, 'Jalen Howell PhD', 'iokeefe@example.com', NULL, 'female', '973-760-3673', '1995-06-02', '2023-03-05 18:26:32', '2023-09-08 21:29:45', NULL),
(114, 'Toney Parker', 'kkovacek@example.com', NULL, 'female', '(307) 922-8981', '1996-10-27', '2023-03-03 23:35:33', '2023-06-17 12:58:34', NULL),
(115, 'Roy Crona', 'maximillian77@example.com', NULL, 'male', '657-237-4054', '1990-07-04', '2022-10-27 10:46:34', '2023-05-22 03:19:13', NULL),
(116, 'Gregory Mayert I', 'emmie56@example.com', NULL, 'female', '+1 (575) 200-3968', '2002-08-25', '2023-01-20 09:20:39', '2023-05-14 04:18:29', NULL),
(117, 'Chauncey Paucek', 'carroll.raul@example.org', NULL, 'male', '+1.980.791.8251', '1999-06-22', '2022-09-28 13:37:42', '2023-08-16 16:29:35', NULL),
(118, 'Elaina Kovacek', 'matt.schamberger@example.net', NULL, 'female', '1-845-713-8150', '1992-01-10', '2022-10-13 06:43:19', '2023-07-01 07:49:53', NULL),
(119, 'Brook Weber', 'lmorissette@example.org', NULL, 'female', '313.419.6806', '1989-05-11', '2022-09-16 20:42:28', '2023-05-13 21:03:40', NULL),
(120, 'Michale Murray PhD', 'morris23@example.com', NULL, 'male', '1-667-918-5490', '1990-08-30', '2022-11-23 13:56:29', '2023-08-01 12:03:07', NULL),
(121, 'Leann McKenzie PhD', 'kacie.witting@example.org', NULL, 'female', '775-509-8668', '1992-03-09', '2023-01-24 18:04:21', '2023-09-03 06:32:25', NULL),
(122, 'Koby Prosacco', 'trent.bartell@example.org', NULL, 'female', '+1.231.409.0089', '1996-03-19', '2022-09-26 20:01:23', '2023-07-14 03:48:45', NULL),
(123, 'Jana Flatley Jr.', 'obernhard@example.org', NULL, 'male', '423-415-4758', '1994-10-02', '2022-12-05 18:20:54', '2023-06-01 16:06:43', NULL),
(124, 'Annabelle Kreiger', 'lempi37@example.org', NULL, 'male', '+1-430-500-3288', '1997-10-16', '2022-10-16 13:00:11', '2023-05-19 15:37:47', NULL),
(125, 'Kiera Cassin', 'kkreiger@example.net', NULL, 'female', '941.803.3986', '1993-01-31', '2022-11-25 19:37:28', '2023-05-28 22:46:33', NULL),
(126, 'Dr. Sammy Treutel I', 'keely04@example.net', NULL, 'male', '1-978-978-4493', '1988-11-22', '2023-03-12 10:15:11', '2023-05-09 10:01:09', NULL),
(127, 'Miss Lysanne Hamill MD', 'timmothy.carter@example.com', NULL, 'male', '1-909-566-6529', '1995-05-30', '2022-09-27 10:23:25', '2023-05-25 08:15:58', NULL),
(128, 'Lillie Labadie IV', 'vschuppe@example.net', NULL, 'female', '+1 (854) 872-1652', '2003-07-16', '2022-10-18 08:37:45', '2023-08-27 10:06:43', NULL),
(129, 'Willard Effertz', 'pollich.leo@example.org', NULL, 'female', '380-254-8308', '2001-02-05', '2022-11-10 22:49:11', '2023-07-20 08:29:28', NULL),
(130, 'Madelyn Beier Jr.', 'irwin79@example.org', NULL, 'male', '+19565473457', '2004-04-11', '2022-12-02 08:53:02', '2023-07-22 22:22:54', NULL),
(131, 'Jesse Bahringer', 'beer.ruth@example.org', NULL, 'male', '662-596-2352', '2003-11-04', '2022-10-11 07:04:46', '2023-05-27 10:14:34', NULL),
(132, 'Roxanne Dickens', 'morgan38@example.org', NULL, 'female', '863.524.1320', '2001-09-07', '2022-09-18 22:11:20', '2023-04-29 10:17:04', NULL),
(133, 'Mrs. Esperanza Runolfsdottir', 'corwin.bianka@example.com', NULL, 'male', '1-309-699-7297', '2005-06-21', '2023-03-08 09:59:43', '2023-05-13 03:54:11', NULL),
(134, 'Mrs. Cierra Ziemann DDS', 'clementine.shields@example.com', NULL, 'male', '(954) 751-8292', '2000-11-20', '2022-11-19 12:50:20', '2023-05-01 02:42:38', NULL),
(135, 'Keith Toy IV', 'yost.alize@example.com', NULL, 'female', '(218) 654-1096', '1988-09-24', '2022-11-14 15:06:26', '2023-07-22 12:04:00', NULL),
(136, 'Magdalena Hilpert II', 'eldon.schaden@example.org', NULL, 'female', '1-954-898-1066', '1992-09-10', '2022-12-03 04:12:59', '2023-06-23 20:05:55', NULL),
(137, 'Hermann Dach', 'alana92@example.com', NULL, 'female', '1-615-936-8572', '1991-04-08', '2022-12-15 04:22:27', '2023-06-28 19:36:06', NULL),
(138, 'Prof. Rudy Marquardt IV', 'wmiller@example.net', NULL, 'male', '+1-423-495-2676', '1996-03-27', '2022-09-29 09:12:35', '2023-04-24 03:25:43', NULL),
(139, 'Eleanore Larkin', 'mbrakus@example.com', NULL, 'male', '458.200.5284', '2001-11-25', '2022-12-14 10:53:48', '2023-05-28 22:06:55', NULL),
(140, 'Franco Durgan', 'npacocha@example.net', NULL, 'female', '(334) 702-2339', '2003-09-24', '2023-01-14 21:34:10', '2023-06-29 00:36:12', NULL),
(141, 'Mrs. Mattie Schamberger', 'hegmann.margarete@example.org', NULL, 'female', '+1-262-816-1603', '1995-12-20', '2023-01-12 05:20:19', '2023-05-30 10:46:50', NULL),
(142, 'Elva Krajcik', 'turner.johnson@example.org', NULL, 'male', '870.498.0865', '1989-05-23', '2023-01-12 13:44:05', '2023-05-30 23:39:11', NULL),
(143, 'King Corkery', 'romaine.mclaughlin@example.com', NULL, 'male', '+1.458.888.1034', '1996-01-04', '2023-01-19 07:18:07', '2023-06-01 06:32:25', NULL),
(144, 'Larue Schneider', 'cheyanne.sipes@example.org', NULL, 'male', '854-448-1560', '1990-07-29', '2022-12-15 18:56:16', '2023-07-31 05:37:56', NULL),
(145, 'Mr. Lorenz Ferry IV', 'bryana.weimann@example.org', NULL, 'male', '+14246313605', '1996-11-13', '2023-03-11 08:46:08', '2023-08-05 05:02:38', NULL),
(146, 'Prof. Mervin Dickinson III', 'baumbach.mellie@example.com', NULL, 'female', '662-299-0132', '1992-07-29', '2022-12-09 05:02:51', '2023-06-01 07:43:31', NULL),
(147, 'Jacinto Heaney', 'maiya.keebler@example.net', NULL, 'male', '(743) 378-7009', '1999-08-26', '2023-03-07 08:51:48', '2023-08-16 14:28:22', NULL),
(148, 'Reece Mayer', 'blaze20@example.org', NULL, 'male', '+12483628975', '2002-09-18', '2022-12-23 19:17:54', '2023-08-28 10:34:56', NULL),
(149, 'Gianni Ferry', 'virgie.keebler@example.com', NULL, 'male', '1-434-436-9216', '1997-08-25', '2023-01-25 18:18:52', '2023-05-16 12:52:03', NULL),
(150, 'Alexanne Tromp III', 'konopelski.reanna@example.net', NULL, 'male', '413-555-2335', '1991-11-16', '2023-03-12 10:38:45', '2023-05-28 15:36:58', NULL),
(151, 'Bailee Kutch', 'neffertz@example.net', NULL, 'male', '234-629-3441', '2001-11-19', '2023-01-07 11:49:40', '2023-05-12 09:20:03', NULL),
(152, 'Vallie Yost', 'obotsford@example.com', NULL, 'female', '1-816-375-1827', '1995-11-13', '2022-12-08 21:20:13', '2023-06-17 04:52:51', NULL),
(153, 'Lane Luettgen', 'brooke.reinger@example.net', NULL, 'female', '734-244-9954', '1997-08-08', '2023-02-25 21:20:04', '2023-04-25 19:30:12', NULL),
(154, 'Aubrey Hirthe', 'grayson96@example.net', NULL, 'female', '682.352.2824', '1993-02-26', '2022-10-29 11:23:04', '2023-07-06 10:06:22', NULL),
(155, 'Idell Langworth', 'jovanny.moen@example.net', NULL, 'female', '+1.248.807.2640', '2002-05-19', '2022-11-10 20:19:02', '2023-06-16 10:59:01', NULL),
(156, 'Jackie Cormier', 'hubert.nolan@example.com', NULL, 'male', '+1 (820) 443-9031', '1997-12-29', '2023-02-19 09:22:04', '2023-04-29 12:12:17', NULL),
(157, 'Keely Kilback', 'vreinger@example.com', NULL, 'female', '+1-248-617-1102', '2000-09-04', '2023-01-11 15:55:33', '2023-05-04 04:59:13', NULL),
(158, 'Rosalind Lindgren I', 'isidro94@example.net', NULL, 'male', '623.515.8103', '2002-10-20', '2022-11-11 01:18:11', '2023-09-03 21:02:07', NULL),
(159, 'Zakary Schowalter', 'adan07@example.net', NULL, 'female', '(484) 777-7970', '1999-04-01', '2022-12-09 20:50:48', '2023-06-01 15:29:14', NULL),
(160, 'Mr. Woodrow Moore I', 'swift.jovanny@example.net', NULL, 'female', '+1 (678) 506-8944', '1989-03-13', '2023-02-27 18:56:02', '2023-04-16 14:52:11', NULL),
(161, 'Reilly Keebler', 'elesch@example.org', NULL, 'male', '361-431-8253', '1999-03-21', '2023-01-26 00:35:54', '2023-07-03 10:09:27', NULL),
(162, 'Prof. Aidan Hartmann', 'emiliano27@example.org', NULL, 'male', '+1.330.247.6512', '1992-04-13', '2022-10-05 09:49:18', '2023-06-25 11:21:37', NULL),
(163, 'Dr. Jerod Schmidt DDS', 'legros.jordi@example.org', NULL, 'female', '+1 (678) 716-4187', '1998-03-28', '2023-01-12 12:47:40', '2023-05-09 14:59:57', NULL),
(164, 'Kamryn Mosciski', 'collier.howell@example.com', NULL, 'female', '(283) 233-7043', '1995-03-01', '2023-01-19 19:55:57', '2023-08-19 03:11:16', NULL),
(165, 'Gordon Carter Jr.', 'bahringer.hailee@example.net', NULL, 'female', '+1.970.518.9752', '2004-09-05', '2022-11-27 15:19:59', '2023-04-20 22:43:18', NULL),
(166, 'Dr. Raheem Marks', 'sim41@example.net', NULL, 'female', '+1.651.737.7747', '1992-12-14', '2023-01-07 03:37:34', '2023-05-31 22:00:13', NULL),
(167, 'Laney Kris', 'leatha73@example.org', NULL, 'male', '325-247-0110', '1998-03-18', '2023-01-23 21:26:45', '2023-07-20 14:58:18', NULL),
(168, 'Lauryn Smitham MD', 'libby.moen@example.com', NULL, 'male', '+15178826795', '2003-01-14', '2023-02-08 06:09:20', '2023-05-19 17:32:26', NULL),
(169, 'Dr. Einar Nicolas', 'marvin.lind@example.net', NULL, 'female', '1-283-842-8449', '2004-04-12', '2022-12-09 00:08:39', '2023-05-13 13:40:31', NULL),
(170, 'Charity Jacobs', 'eda34@example.com', NULL, 'female', '743.786.5529', '2004-08-02', '2022-12-29 18:08:44', '2023-05-17 11:51:34', NULL),
(171, 'Garth McDermott', 'newton74@example.org', NULL, 'female', '1-225-744-4621', '2000-10-04', '2023-03-02 17:56:44', '2023-04-17 00:32:53', NULL),
(172, 'Nannie Torp', 'sernser@example.org', NULL, 'female', '1-843-484-1791', '1991-05-04', '2023-01-14 17:27:29', '2023-06-30 00:18:50', NULL),
(173, 'Kaylee Funk', 'eliza82@example.org', NULL, 'female', '1-551-939-8773', '2002-09-13', '2022-09-27 12:55:02', '2023-07-05 15:38:45', NULL),
(174, 'Elfrieda Wehner', 'steuber.rosalind@example.com', NULL, 'female', '562.560.4686', '2004-05-03', '2022-10-09 09:28:02', '2023-05-06 07:06:26', NULL),
(175, 'Nicola Kutch', 'flavio88@example.com', NULL, 'male', '754-212-3612', '2002-10-02', '2022-11-16 14:08:41', '2023-06-23 09:31:29', NULL),
(176, 'Prof. Gus Wolf DDS', 'neil78@example.net', NULL, 'female', '341.257.3560', '2005-08-16', '2022-11-08 00:04:14', '2023-07-05 01:14:39', NULL),
(177, 'Narciso Douglas', 'rondricka@example.com', NULL, 'male', '1-985-303-2877', '1990-08-01', '2022-12-20 16:46:33', '2023-06-07 09:33:49', NULL),
(178, 'Mrs. Theodora Labadie DVM', 'danny.runolfsson@example.net', NULL, 'male', '475-306-8426', '2002-11-09', '2022-10-23 19:26:51', '2023-07-22 05:07:17', NULL),
(179, 'Cole McLaughlin', 'ashtyn.christiansen@example.com', NULL, 'male', '+1.323.232.8382', '2000-05-08', '2022-11-12 18:49:10', '2023-05-25 17:20:06', NULL),
(180, 'Vesta Walsh I', 'thiel.ethyl@example.org', NULL, 'female', '+1.740.414.1152', '1999-01-24', '2022-10-29 07:05:57', '2023-08-03 10:52:07', NULL),
(181, 'Hilda Zulauf', 'natalia52@example.com', NULL, 'male', '(804) 613-4495', '2003-06-05', '2023-02-24 12:01:54', '2023-07-08 15:29:31', NULL),
(182, 'Wendell Nitzsche I', 'hegmann.watson@example.net', NULL, 'female', '281-366-7321', '2003-08-07', '2022-10-04 06:20:39', '2023-07-09 02:27:11', NULL),
(183, 'Mozell Trantow', 'retha25@example.net', NULL, 'male', '336.602.5613', '1991-03-25', '2023-01-09 19:33:19', '2023-04-16 06:45:56', NULL),
(184, 'Wilhelm Little II', 'hkshlerin@example.org', NULL, 'male', '1-509-477-2475', '1990-04-09', '2023-03-13 00:34:02', '2023-07-25 09:02:20', NULL),
(185, 'Brock Graham DVM', 'dooley.willa@example.net', NULL, 'female', '+14322139520', '2000-12-15', '2022-11-10 11:14:30', '2023-06-27 15:46:15', NULL),
(186, 'Raphaelle Mante V', 'tchristiansen@example.com', NULL, 'female', '346.800.6606', '2003-09-02', '2023-03-01 11:43:10', '2023-07-11 23:13:18', NULL),
(187, 'Norval Rogahn', 'iankunding@example.net', NULL, 'male', '828.884.2060', '1990-12-01', '2022-11-27 02:42:17', '2023-09-10 17:07:33', NULL),
(188, 'Lawson Renner IV', 'destiny.mante@example.org', NULL, 'female', '+1 (220) 708-0642', '2001-08-05', '2022-11-03 03:16:38', '2023-08-10 14:03:19', NULL),
(189, 'Elisha Nienow III', 'qpfeffer@example.net', NULL, 'male', '+1-239-947-1788', '1996-06-06', '2022-11-07 00:00:26', '2023-06-26 03:43:32', NULL),
(190, 'Ms. Beth Kirlin', 'altenwerth.jeffery@example.com', NULL, 'male', '1-478-643-9524', '1992-02-25', '2022-10-13 23:27:41', '2023-09-03 19:31:51', NULL),
(191, 'Ernestina Vandervort', 'federico23@example.org', NULL, 'male', '1-954-925-7474', '1996-05-11', '2022-10-13 07:09:31', '2023-05-19 00:46:24', NULL),
(192, 'Miss Addison Daniel I', 'dock.tillman@example.org', NULL, 'male', '(731) 559-4247', '1995-07-07', '2023-01-02 09:02:08', '2023-07-31 13:56:35', NULL),
(193, 'Sam Casper Sr.', 'langosh.ed@example.org', NULL, 'male', '973.913.1670', '1994-07-02', '2022-10-15 04:01:57', '2023-06-28 16:51:51', NULL),
(194, 'Orville Nitzsche', 'jeanette13@example.org', NULL, 'female', '509.357.6092', '1994-01-17', '2023-01-07 23:30:43', '2023-07-18 11:20:33', NULL),
(195, 'Hubert Harris Sr.', 'adolfo.funk@example.org', NULL, 'female', '+1-774-333-0662', '2002-06-18', '2022-11-29 23:50:21', '2023-05-16 11:18:07', NULL),
(196, 'Lucy Lakin', 'lila84@example.org', NULL, 'female', '323-470-4887', '1996-10-12', '2022-10-24 08:30:47', '2023-07-13 05:46:25', NULL),
(197, 'Roma Harris', 'murazik.kameron@example.net', NULL, 'female', '1-917-542-0232', '1989-11-17', '2022-11-07 03:30:33', '2023-08-07 07:55:46', NULL),
(198, 'Ms. Samara Bradtke', 'kreiger.vernon@example.net', NULL, 'male', '+1 (602) 443-5827', '2001-05-18', '2022-12-12 06:57:57', '2023-07-01 20:24:36', NULL),
(199, 'Saige Borer', 'donnelly.armando@example.com', NULL, 'female', '262.914.3546', '2003-02-22', '2023-01-24 04:29:53', '2023-06-12 10:42:50', NULL),
(200, 'Kathryn Connelly V', 'frederik.stokes@example.com', NULL, 'male', '570-316-7188', '2001-10-19', '2022-12-05 19:42:02', '2023-08-23 14:12:37', NULL),
(201, 'Joseph Goodwin', 'shea64@example.org', NULL, 'male', '505-886-7824', '1998-06-08', '2023-02-12 12:39:34', '2023-09-10 22:55:36', NULL),
(202, 'Ms. Karianne Nienow', 'felix.weimann@example.org', NULL, 'male', '+12545280291', '2005-06-08', '2023-01-24 08:15:28', '2023-07-20 07:20:58', NULL),
(203, 'Dr. Dejuan Veum DVM', 'dereck93@example.net', NULL, 'male', '1-484-320-6198', '1996-08-10', '2022-11-11 12:01:34', '2023-08-30 05:00:37', NULL),
(204, 'Aric Botsford DVM', 'chase47@example.org', NULL, 'male', '+1 (986) 512-5688', '1999-01-24', '2023-03-13 13:50:01', '2023-07-14 08:34:30', NULL),
(205, 'Gabriel Pouros', 'schuster.lloyd@example.com', NULL, 'female', '307-687-9991', '2001-04-21', '2022-10-10 12:42:45', '2023-05-03 02:40:43', NULL),
(206, 'Winfield Fahey', 'wrice@example.org', NULL, 'male', '(781) 928-9432', '2004-07-18', '2022-12-08 05:16:18', '2023-06-06 18:47:18', NULL),
(207, 'Rollin Boehm', 'cschaefer@example.net', NULL, 'male', '1-267-929-5428', '2002-07-12', '2022-12-17 01:03:34', '2023-05-09 16:34:40', NULL),
(208, 'Bernard Tremblay', 'lueilwitz.mina@example.net', NULL, 'male', '1-872-249-9907', '2005-01-10', '2022-12-20 14:58:25', '2023-05-08 16:43:43', NULL),
(209, 'Valerie Dach MD', 'laury00@example.org', NULL, 'male', '+1.862.996.5833', '1997-01-09', '2023-03-08 07:30:22', '2023-06-10 08:20:08', NULL),
(210, 'Kamren Tillman', 'queen37@example.net', NULL, 'male', '773-490-3867', '2005-07-25', '2023-02-26 07:06:12', '2023-08-30 17:02:20', NULL),
(211, 'Mrs. Kathleen Davis V', 'taurean59@example.com', NULL, 'female', '442.717.4848', '2004-01-19', '2023-01-25 06:03:42', '2023-08-24 18:26:16', NULL),
(212, 'Orion Grant', 'karl.cormier@example.net', NULL, 'female', '(848) 984-2961', '1989-05-30', '2022-10-22 04:30:07', '2023-04-17 20:32:05', NULL),
(213, 'Amalia Marquardt', 'jacobs.jaclyn@example.net', NULL, 'male', '858-303-1700', '2004-11-10', '2022-09-23 20:02:31', '2023-07-16 17:21:27', NULL),
(214, 'Prof. Thora Hansen II', 'houston.spinka@example.net', NULL, 'male', '+16262038315', '1996-07-29', '2022-10-21 08:30:49', '2023-08-21 09:58:38', NULL),
(215, 'Alvina Ondricka', 'kurtis.gulgowski@example.com', NULL, 'male', '1-838-965-7695', '1999-05-28', '2022-11-11 23:56:15', '2023-08-11 07:11:40', NULL),
(216, 'Stephanie Fritsch', 'waelchi.dayton@example.net', NULL, 'male', '+1.269.954.9319', '2000-08-29', '2022-10-18 02:47:13', '2023-06-19 05:43:05', NULL),
(217, 'Trevor Dibbert', 'hamill.carolyne@example.org', NULL, 'female', '+1.513.968.0460', '2004-01-30', '2022-11-19 06:53:51', '2023-05-10 23:34:33', NULL),
(218, 'Yasmeen Kris', 'oscar.deckow@example.org', NULL, 'female', '425-239-7171', '2000-11-09', '2023-03-09 03:06:32', '2023-09-04 00:46:01', NULL),
(219, 'Myrna Kerluke', 'linda77@example.net', NULL, 'female', '+15418681724', '1999-12-09', '2022-12-16 15:15:57', '2023-08-16 06:27:51', NULL),
(220, 'Clay Schmitt', 'pfannerstill.katelyn@example.net', NULL, 'female', '(989) 719-5175', '1995-10-22', '2022-12-19 18:12:21', '2023-04-20 21:43:31', NULL),
(221, 'Autumn Torp', 'kdubuque@example.org', NULL, 'male', '(563) 505-2463', '1989-10-07', '2022-12-05 19:51:01', '2023-04-14 17:48:25', NULL),
(222, 'Buster Mertz', 'vschulist@example.net', NULL, 'female', '1-872-576-7204', '1993-08-19', '2022-12-26 09:10:08', '2023-04-21 09:21:05', NULL),
(223, 'Lue Nicolas', 'mwilkinson@example.org', NULL, 'female', '+1 (234) 727-1903', '1995-03-03', '2022-12-13 03:11:42', '2023-05-17 00:21:59', NULL),
(224, 'Prof. Linnea Grant DDS', 'hamill.chet@example.org', NULL, 'male', '321.308.2113', '1993-07-25', '2022-10-01 19:16:05', '2023-07-10 18:20:45', NULL),
(225, 'Astrid Roob', 'hbashirian@example.org', NULL, 'female', '+1-608-261-7495', '2001-05-27', '2022-09-26 16:08:25', '2023-07-26 16:18:02', NULL),
(226, 'Evalyn Gorczany', 'yhauck@example.net', NULL, 'female', '1-610-537-6537', '1996-10-06', '2023-02-20 14:43:59', '2023-06-01 01:35:46', NULL),
(227, 'Tyrell Kshlerin', 'sporer.anastasia@example.org', NULL, 'male', '+1.863.973.3413', '1997-12-11', '2023-02-20 20:59:10', '2023-08-23 21:51:36', NULL),
(228, 'Ms. Queenie Rempel Sr.', 'gusikowski.jeanette@example.net', NULL, 'male', '+15634574859', '1998-12-06', '2022-12-01 15:28:22', '2023-06-16 10:54:10', NULL),
(229, 'Prof. Mikel Graham', 'aryanna.sipes@example.org', NULL, 'female', '+1 (320) 401-6647', '2002-03-29', '2023-02-05 14:30:23', '2023-08-14 23:29:09', NULL),
(230, 'Kristian Ondricka', 'anderson.vince@example.com', NULL, 'male', '320-694-1366', '1992-01-25', '2022-10-21 23:55:02', '2023-06-06 04:39:57', NULL),
(231, 'Hadley Keebler III', 'jdach@example.org', NULL, 'female', '1-804-234-0893', '1996-02-09', '2023-03-11 06:52:15', '2023-06-04 00:02:42', NULL),
(232, 'Jaylin Treutel PhD', 'tess46@example.com', NULL, 'female', '364.551.8848', '1994-01-28', '2023-02-11 18:37:49', '2023-05-14 02:08:36', NULL),
(233, 'Arlie Watsica', 'schinner.cynthia@example.org', NULL, 'male', '785.968.3942', '2002-03-09', '2022-11-07 23:41:49', '2023-08-04 12:20:42', NULL),
(234, 'Amely Kreiger', 'ronny29@example.com', NULL, 'female', '+19518589104', '2003-06-15', '2022-12-26 03:09:32', '2023-07-25 17:50:41', NULL),
(235, 'Hank Robel', 'becker.violette@example.org', NULL, 'male', '+1-330-853-7021', '2000-02-20', '2022-10-17 07:25:13', '2023-06-04 23:23:44', NULL),
(236, 'Frieda Fahey', 'karli.lowe@example.net', NULL, 'male', '+1 (508) 328-6709', '2000-06-24', '2022-12-15 06:08:07', '2023-08-18 20:24:08', NULL),
(237, 'Vesta Carroll', 'predovic.clifford@example.net', NULL, 'female', '(925) 579-9326', '1997-11-16', '2023-02-10 16:08:05', '2023-07-26 19:36:48', NULL),
(238, 'Vern Harris', 'aiden.kutch@example.com', NULL, 'male', '480.901.6652', '1993-08-31', '2022-09-18 05:32:33', '2023-06-17 12:57:21', NULL),
(239, 'Eusebio Gulgowski III', 'lenora49@example.net', NULL, 'male', '+1-747-747-9456', '2005-02-11', '2022-11-30 18:18:36', '2023-07-14 19:38:02', NULL),
(240, 'Wilhelm Smitham', 'bsenger@example.com', NULL, 'female', '458.520.5801', '2005-04-29', '2023-03-13 01:23:52', '2023-07-17 10:32:03', NULL),
(241, 'Annetta O\'Kon', 'jdickinson@example.com', NULL, 'female', '+15759786875', '2000-12-31', '2023-01-09 02:26:56', '2023-05-16 01:17:24', NULL),
(242, 'Myriam Cartwright', 'kihn.yessenia@example.net', NULL, 'female', '+1.224.651.6522', '2005-01-17', '2022-12-28 07:45:47', '2023-06-27 01:55:29', NULL),
(243, 'Wilhelm Stokes', 'grayson.harber@example.com', NULL, 'female', '272-430-5869', '1995-02-18', '2022-10-15 14:32:37', '2023-08-02 09:13:39', NULL),
(244, 'Fred Rutherford', 'korbin.rowe@example.org', NULL, 'male', '+1 (540) 401-9900', '1992-10-17', '2023-01-01 16:29:35', '2023-05-16 10:22:58', NULL),
(245, 'Rupert Reinger', 'zgreenfelder@example.org', NULL, 'male', '+1-860-486-5786', '1993-12-02', '2022-11-10 18:10:30', '2023-07-01 12:42:43', NULL),
(246, 'Marquise Mayer', 'keaton61@example.org', NULL, 'male', '870-206-5541', '2003-09-18', '2022-10-25 08:07:59', '2023-07-18 10:12:14', NULL),
(247, 'Mr. Price Ratke IV', 'anderson33@example.org', NULL, 'male', '740.358.7019', '2003-10-30', '2022-12-17 14:15:42', '2023-05-15 12:57:45', NULL),
(248, 'Isabell Oberbrunner DVM', 'ostoltenberg@example.com', NULL, 'female', '+19155445660', '2002-04-25', '2023-01-12 16:16:20', '2023-08-01 03:55:14', NULL),
(249, 'Prof. Pasquale Yost IV', 'corine.padberg@example.org', NULL, 'female', '1-984-677-2535', '1988-11-19', '2022-09-30 02:49:04', '2023-08-14 05:23:47', NULL),
(250, 'Faye McLaughlin', 'ernser.jayde@example.org', NULL, 'male', '678-629-8313', '1990-01-05', '2023-02-28 23:09:23', '2023-05-01 13:28:07', NULL),
(251, 'Blake Eichmann', 'boyle.flavie@example.net', NULL, 'female', '+1-214-205-9177', '2004-08-18', '2022-09-29 09:27:36', '2023-05-07 03:03:34', NULL),
(252, 'Carmel Windler', 'ewilkinson@example.com', NULL, 'male', '+1-331-355-0872', '2000-09-16', '2022-10-26 08:14:35', '2023-07-09 23:35:46', NULL),
(253, 'Beau Sawayn MD', 'gus.schmeler@example.net', NULL, 'male', '279-595-1876', '1998-11-07', '2022-12-07 21:45:11', '2023-06-21 14:14:01', NULL),
(254, 'Jamil Leannon', 'rutherford.hazle@example.net', NULL, 'male', '+1-567-417-9178', '1999-09-24', '2022-10-25 15:42:24', '2023-05-04 22:50:36', NULL),
(255, 'Joey Langworth', 'karson54@example.org', NULL, 'male', '+1-678-469-7009', '1993-11-09', '2022-12-28 15:13:02', '2023-08-29 08:51:49', NULL),
(256, 'Tillman Heathcote III', 'oswaldo.casper@example.net', NULL, 'female', '+1-913-473-1657', '1994-06-09', '2023-02-18 17:08:44', '2023-06-05 17:13:41', NULL),
(257, 'Prof. Leila Leuschke', 'rschmeler@example.com', NULL, 'male', '364.976.4829', '1997-07-27', '2022-12-22 15:03:51', '2023-07-27 15:26:55', NULL),
(258, 'Trystan Daniel Sr.', 'keebler.jana@example.org', NULL, 'female', '+1-716-392-2234', '1997-04-20', '2023-01-06 10:20:39', '2023-06-02 23:11:20', NULL),
(259, 'Austin Lemke IV', 'mhand@example.org', NULL, 'male', '(970) 372-1296', '1999-02-11', '2022-10-30 19:39:35', '2023-08-20 04:41:16', NULL),
(260, 'Cleve Cartwright Sr.', 'mertz.santina@example.com', NULL, 'male', '443-214-6681', '1998-05-06', '2023-01-31 09:44:47', '2023-09-04 07:37:10', NULL),
(261, 'Sibyl Lebsack', 'phills@example.net', NULL, 'female', '1-707-546-3119', '1990-05-21', '2022-10-22 10:49:22', '2023-06-02 12:26:11', NULL),
(262, 'Prof. Rodger Harber Sr.', 'benedict.johns@example.org', NULL, 'male', '1-563-745-9337', '1995-06-19', '2023-01-16 02:08:06', '2023-09-13 11:49:10', NULL),
(263, 'Alison Larkin PhD', 'nicolas.danny@example.net', NULL, 'female', '+1-726-421-4507', '1996-06-18', '2022-11-07 05:17:30', '2023-08-10 12:56:23', NULL),
(264, 'Meta Schinner', 'alittle@example.org', NULL, 'male', '757-892-3299', '2004-07-08', '2023-01-19 18:24:25', '2023-05-28 02:51:57', NULL),
(265, 'Dr. Nels Doyle', 'bbotsford@example.org', NULL, 'male', '979-260-3734', '2001-10-15', '2022-09-27 07:59:12', '2023-06-09 03:13:21', NULL),
(266, 'Doris Rodriguez', 'llindgren@example.net', NULL, 'male', '+15802257735', '2000-03-07', '2023-01-21 03:46:43', '2023-08-13 22:12:23', NULL),
(267, 'Deshawn Carroll', 'schaefer.john@example.com', NULL, 'female', '1-862-927-7187', '1999-07-12', '2023-02-18 23:32:40', '2023-06-23 03:50:38', NULL),
(268, 'Johnathan Hyatt', 'oskiles@example.org', NULL, 'male', '203.962.3208', '2002-08-06', '2023-02-03 20:23:32', '2023-06-07 05:54:06', NULL),
(269, 'Katelin Roob', 'doyle.logan@example.org', NULL, 'male', '1-786-909-3622', '1999-03-12', '2023-01-15 12:28:46', '2023-07-27 14:45:41', NULL),
(270, 'Stephany Lebsack', 'arturo11@example.com', NULL, 'female', '+1.949.422.4999', '1992-07-31', '2022-11-01 01:06:06', '2023-06-27 13:15:28', NULL),
(271, 'Darian Wiza', 'scotty70@example.net', NULL, 'male', '1-956-530-1332', '1990-05-26', '2023-03-10 07:47:22', '2023-05-16 11:44:47', NULL),
(272, 'Mavis Cremin', 'jast.sean@example.org', NULL, 'male', '+1-586-310-2455', '1998-05-06', '2022-10-22 01:32:09', '2023-05-09 04:33:17', NULL),
(273, 'Dr. Flo Emard', 'fschoen@example.com', NULL, 'female', '1-305-798-2970', '2000-11-27', '2023-02-08 06:01:30', '2023-06-12 01:35:12', NULL),
(274, 'Van Torp', 'jordy28@example.com', NULL, 'female', '+16828432524', '1998-06-04', '2022-10-10 16:11:17', '2023-09-08 05:04:03', NULL),
(275, 'Drew Abbott', 'achamplin@example.com', NULL, 'female', '+1-640-332-5671', '1992-10-31', '2023-01-29 03:02:48', '2023-04-26 17:32:49', NULL),
(276, 'Woodrow Gutmann', 'stoltenberg.eloise@example.net', NULL, 'male', '740-400-5489', '1989-01-13', '2023-03-01 12:33:40', '2023-06-02 23:25:45', NULL),
(277, 'Leta Hintz', 'ubuckridge@example.com', NULL, 'male', '803-239-0701', '2000-07-03', '2022-12-09 07:52:31', '2023-06-11 04:58:32', NULL),
(278, 'Ilene Schowalter', 'tyrese24@example.org', NULL, 'female', '+14634408489', '1995-02-17', '2022-10-06 11:02:20', '2023-06-30 04:01:32', NULL),
(279, 'Murphy McCullough', 'ykassulke@example.org', NULL, 'male', '+1 (816) 997-2384', '2002-07-06', '2022-09-28 19:52:34', '2023-06-08 12:52:30', NULL),
(280, 'Hayley Legros', 'giovanna.prohaska@example.com', NULL, 'female', '(410) 216-8734', '2003-09-12', '2022-11-09 03:35:59', '2023-06-22 22:05:26', NULL),
(281, 'Sophia Robel', 'ttreutel@example.com', NULL, 'male', '1-848-358-3032', '2001-05-10', '2022-11-25 01:12:20', '2023-06-08 00:38:16', NULL),
(282, 'Daphney Hegmann DVM', 'marquis.gusikowski@example.net', NULL, 'female', '620.571.9708', '1991-01-08', '2022-12-19 14:11:00', '2023-06-20 07:47:38', NULL),
(283, 'Rosetta Hettinger', 'gutmann.orion@example.net', NULL, 'female', '+1-984-539-5065', '2003-01-04', '2023-01-19 11:53:01', '2023-08-22 05:25:23', NULL),
(284, 'Edgardo Pouros I', 'nkutch@example.com', NULL, 'female', '669-318-9359', '1997-05-22', '2023-02-19 00:13:40', '2023-04-20 18:47:22', NULL),
(285, 'Deron O\'Kon', 'rosalinda.frami@example.com', NULL, 'male', '743.659.7169', '1995-06-12', '2023-03-11 19:51:19', '2023-05-24 21:27:23', NULL),
(286, 'Mrs. Mara Bashirian', 'stoltenberg.anjali@example.org', NULL, 'male', '352.934.9463', '1989-10-26', '2022-10-16 10:00:53', '2023-06-19 19:21:54', NULL),
(287, 'Miracle Altenwerth', 'dewayne.torphy@example.com', NULL, 'male', '+16892492482', '2002-08-29', '2022-09-14 20:12:51', '2023-08-02 16:00:36', NULL),
(288, 'Dr. Otha Huel Jr.', 'jmiller@example.org', NULL, 'female', '586-764-2979', '2004-09-29', '2023-01-17 14:39:45', '2023-07-14 17:28:58', NULL),
(289, 'Theron Stiedemann', 'jasen13@example.net', NULL, 'male', '810-858-5219', '1995-02-14', '2023-02-23 01:44:01', '2023-07-14 02:35:32', NULL),
(290, 'Kamille Hill', 'rick24@example.org', NULL, 'female', '+16789297478', '1996-01-14', '2023-03-11 15:32:34', '2023-08-31 00:33:16', NULL),
(291, 'Rosella Nader', 'schaefer.vida@example.org', NULL, 'female', '1-845-834-3311', '1999-08-25', '2022-10-11 22:18:02', '2023-04-20 10:44:28', NULL),
(292, 'Juliana Mann', 'raphaelle77@example.net', NULL, 'female', '810-510-3909', '1996-04-18', '2023-01-18 11:34:09', '2023-04-17 23:10:52', NULL),
(293, 'Violette Daugherty', 'klesch@example.net', NULL, 'female', '(248) 452-5495', '1995-12-18', '2022-12-11 10:35:02', '2023-04-17 09:49:52', NULL),
(294, 'Jedediah Erdman', 'austin.osinski@example.com', NULL, 'female', '610-690-1886', '1996-03-31', '2023-01-13 07:24:44', '2023-07-07 15:27:40', NULL),
(295, 'Dr. Amelie Ernser IV', 'von.caitlyn@example.org', NULL, 'male', '(667) 501-6444', '1992-02-07', '2022-12-04 12:52:21', '2023-07-11 16:01:14', NULL),
(296, 'Ettie Beier', 'oberbrunner.gage@example.net', NULL, 'male', '+1.912.389.2593', '1988-12-25', '2023-01-16 15:26:56', '2023-06-14 22:18:41', NULL),
(297, 'Mr. Buster Rolfson IV', 'magnus.white@example.org', NULL, 'male', '1-361-591-1145', '2003-03-18', '2023-02-04 21:42:19', '2023-04-27 04:07:47', NULL),
(298, 'Ford Bergstrom', 'jordi44@example.net', NULL, 'male', '(307) 437-8975', '1998-08-12', '2022-12-22 03:30:18', '2023-06-29 02:52:33', NULL),
(299, 'Miss Magali Howell V', 'smaggio@example.com', NULL, 'male', '651.438.8710', '1991-10-14', '2023-02-15 15:53:11', '2023-07-02 04:39:53', NULL),
(300, 'Arnoldo Grant', 'carter.roderick@example.net', NULL, 'male', '(330) 687-8677', '2002-02-18', '2022-12-30 10:52:27', '2023-05-09 07:03:39', NULL),
(301, 'Vena Heller', 'mmckenzie@example.com', NULL, 'female', '(223) 973-9354', '1995-11-29', '2023-02-25 10:17:45', '2023-08-06 06:40:23', NULL),
(302, 'Kathlyn Swift MD', 'sincere52@example.net', NULL, 'female', '972-243-6119', '1989-07-14', '2022-09-24 13:38:27', '2023-07-26 19:31:28', NULL),
(303, 'Dr. Clare McLaughlin MD', 'beatty.vladimir@example.org', NULL, 'female', '(641) 833-7348', '2002-01-03', '2023-01-12 14:08:30', '2023-05-08 09:03:27', NULL),
(304, 'Reanna Murphy', 'meagan19@example.com', NULL, 'male', '+1-475-795-3409', '2003-12-28', '2023-01-01 10:06:10', '2023-06-21 21:27:11', NULL),
(305, 'Odell Padberg', 'obradtke@example.com', NULL, 'male', '+1.864.392.4210', '1990-07-26', '2023-01-20 06:08:16', '2023-05-13 06:23:31', NULL),
(306, 'Thurman Crist', 'lockman.roderick@example.net', NULL, 'male', '1-551-345-9433', '1997-05-24', '2022-11-25 03:44:16', '2023-04-23 16:10:13', NULL),
(307, 'Olaf West', 'lori37@example.com', NULL, 'male', '(215) 360-3866', '1993-11-22', '2022-11-13 23:52:35', '2023-07-01 02:20:58', NULL),
(308, 'Jett Goodwin', 'hwisozk@example.net', NULL, 'male', '1-234-620-2810', '1998-06-24', '2022-11-13 10:42:30', '2023-09-03 15:11:19', NULL),
(309, 'Vilma Hyatt PhD', 'bud.flatley@example.com', NULL, 'female', '458.879.1686', '2004-05-14', '2023-02-04 14:17:33', '2023-07-18 04:03:00', NULL),
(310, 'Dr. Lela Anderson III', 'enoch48@example.org', NULL, 'female', '(629) 307-2956', '2004-09-29', '2022-09-24 09:46:17', '2023-05-12 04:17:00', NULL),
(311, 'Allen Marvin', 'linnie84@example.org', NULL, 'male', '+1.208.325.6380', '1993-09-04', '2022-10-16 06:41:47', '2023-05-28 11:49:42', NULL),
(312, 'Lori Huel', 'rosetta85@example.com', NULL, 'female', '+1-754-636-6452', '2000-12-02', '2023-02-14 15:44:46', '2023-06-02 04:26:20', NULL),
(313, 'Toney Okuneva', 'tbernhard@example.org', NULL, 'male', '470.422.4830', '1989-04-02', '2022-12-12 23:47:14', '2023-07-09 15:11:30', NULL),
(314, 'Neal Lockman', 'fredy.kling@example.org', NULL, 'female', '1-680-327-1739', '2004-06-30', '2022-10-05 14:54:31', '2023-08-31 07:12:38', NULL),
(315, 'Ahmed Spencer', 'koelpin.natasha@example.net', NULL, 'female', '1-737-254-7781', '2005-04-19', '2023-01-01 19:43:07', '2023-07-04 19:31:31', NULL),
(316, 'Dr. Dario Hudson PhD', 'bernardo73@example.org', NULL, 'female', '(848) 960-1093', '1989-01-02', '2022-10-22 14:14:36', '2023-08-30 06:04:10', NULL),
(317, 'Mr. Leo Koepp Jr.', 'maggio.juliana@example.com', NULL, 'male', '323-307-5390', '1994-10-31', '2022-11-13 13:50:35', '2023-04-17 15:47:22', NULL),
(318, 'Antonina Langosh', 'feest.hattie@example.com', NULL, 'male', '+1-563-571-8433', '1995-10-10', '2022-09-23 07:17:06', '2023-08-20 21:22:48', NULL),
(319, 'Ms. Karine Wolff', 'sherman.satterfield@example.net', NULL, 'female', '+1-856-207-7975', '1989-09-26', '2022-12-13 01:26:12', '2023-05-03 17:30:41', NULL),
(320, 'Jonatan Bergnaum', 'gdickens@example.net', NULL, 'male', '336-493-7505', '1998-05-24', '2023-02-18 15:02:27', '2023-06-29 17:16:43', NULL),
(321, 'Dr. Vladimir Lind Jr.', 'dovie31@example.net', NULL, 'female', '+1 (312) 650-1578', '1989-09-08', '2022-10-31 09:17:55', '2023-06-21 13:25:27', NULL),
(322, 'Rudy Boehm', 'esmeralda93@example.com', NULL, 'male', '+1-380-610-8238', '1998-06-14', '2022-09-16 15:16:59', '2023-08-20 08:33:16', NULL),
(323, 'Lonie Connelly', 'bergstrom.abigale@example.org', NULL, 'male', '+13642561343', '1998-06-24', '2022-10-30 16:21:41', '2023-05-05 16:39:13', NULL),
(324, 'Celestino Raynor', 'considine.frank@example.org', NULL, 'male', '737.410.9561', '1999-07-06', '2022-09-30 07:14:26', '2023-07-26 06:05:32', NULL),
(325, 'Cheyanne Grant', 'bjaskolski@example.org', NULL, 'male', '+1-808-808-6455', '1990-04-12', '2023-01-22 21:55:25', '2023-05-15 14:42:16', NULL),
(326, 'Miss Nya Corwin', 'gleichner.gideon@example.com', NULL, 'female', '703-623-1031', '1997-08-20', '2022-11-29 04:07:08', '2023-04-25 02:17:00', NULL),
(327, 'Roxane Hoeger', 'lucius79@example.net', NULL, 'male', '575-518-1059', '1988-12-03', '2022-10-13 18:17:00', '2023-09-05 02:50:38', NULL),
(328, 'Clay Stiedemann', 'willard.stoltenberg@example.com', NULL, 'female', '520.884.4362', '1993-04-24', '2022-12-02 03:35:13', '2023-07-03 14:54:55', NULL),
(329, 'Melba Muller', 'elyse.kris@example.org', NULL, 'female', '541-426-3340', '1998-12-12', '2023-01-08 15:10:05', '2023-09-07 02:42:03', NULL),
(330, 'Dr. Aniyah Aufderhar I', 'roosevelt69@example.com', NULL, 'male', '463-286-5120', '1993-06-17', '2022-12-29 18:04:43', '2023-07-02 22:02:34', NULL),
(331, 'Irwin Hermiston', 'heaney.pedro@example.com', NULL, 'male', '+1-847-568-3916', '2000-02-18', '2022-09-20 03:04:31', '2023-05-19 19:25:32', NULL),
(332, 'Dustin Borer', 'myrtie30@example.net', NULL, 'male', '(901) 862-9804', '1990-12-17', '2023-01-03 04:56:35', '2023-05-08 01:38:10', NULL),
(333, 'Mr. Gardner Upton', 'rhianna.krajcik@example.org', NULL, 'male', '+1-678-740-7947', '2001-05-12', '2022-09-15 18:31:57', '2023-09-14 01:15:16', NULL);
INSERT INTO `shop_customers` (`id`, `name`, `email`, `photo`, `gender`, `phone`, `birthday`, `created_at`, `updated_at`, `deleted_at`) VALUES
(334, 'Arch Padberg DDS', 'jamison.berge@example.com', NULL, 'female', '(651) 339-1739', '1991-11-15', '2022-11-19 06:51:01', '2023-07-04 10:40:43', NULL),
(335, 'Dr. Billy Durgan I', 'lyda.reinger@example.net', NULL, 'female', '424.285.9439', '1991-10-06', '2023-01-26 21:54:12', '2023-07-02 18:48:28', NULL),
(336, 'Miss Dandre Ziemann', 'harley.kuhlman@example.com', NULL, 'female', '+1-580-371-6313', '1989-06-05', '2023-02-27 00:26:29', '2023-06-06 18:20:29', NULL),
(337, 'Mrs. Rosie Dare V', 'collin10@example.net', NULL, 'female', '1-586-635-0177', '1991-11-25', '2023-01-30 10:02:18', '2023-07-19 21:20:08', NULL),
(338, 'Marquis Wilkinson', 'jrobel@example.net', NULL, 'male', '+1-631-412-2322', '1991-02-07', '2022-12-02 02:22:01', '2023-08-24 13:51:18', NULL),
(339, 'Elmira Walter II', 'ferry.darius@example.com', NULL, 'female', '(863) 610-5941', '1994-12-15', '2022-09-18 12:42:10', '2023-06-04 19:38:43', NULL),
(340, 'Jerrod Flatley', 'dangelo84@example.com', NULL, 'female', '828.278.8602', '1990-06-23', '2022-12-16 14:45:43', '2023-07-16 02:00:34', NULL),
(341, 'Miss Giovanna Lakin II', 'elza.reichert@example.com', NULL, 'female', '630.463.1105', '1994-06-27', '2022-09-15 13:36:03', '2023-06-30 03:37:06', NULL),
(342, 'Alfonzo Schulist II', 'conner58@example.org', NULL, 'female', '+1-737-796-3915', '2005-02-12', '2023-02-25 07:26:28', '2023-04-22 05:46:38', NULL),
(343, 'Dr. Jo Botsford', 'hfeest@example.com', NULL, 'male', '(279) 703-5228', '1991-07-01', '2022-11-25 17:25:20', '2023-05-12 10:01:58', NULL),
(344, 'Hope Blanda', 'kuvalis.kristoffer@example.org', NULL, 'male', '864.452.4128', '1998-11-17', '2022-12-02 06:16:49', '2023-07-24 13:58:46', NULL),
(345, 'Ernestine Bergstrom', 'kovacek.adalberto@example.com', NULL, 'female', '(520) 516-0739', '1992-09-12', '2022-10-06 00:16:03', '2023-08-03 09:52:41', NULL),
(346, 'Van Pfeffer V', 'plehner@example.org', NULL, 'male', '+1.906.536.3662', '1993-09-30', '2022-12-23 21:11:19', '2023-07-24 09:23:47', NULL),
(347, 'Raymundo Eichmann', 'dcorwin@example.net', NULL, 'female', '+1 (458) 821-2568', '1996-02-03', '2023-02-01 17:22:41', '2023-08-06 15:44:44', NULL),
(348, 'Dr. Gabe Bruen DDS', 'hudson.luna@example.com', NULL, 'female', '+13605074882', '2002-06-17', '2023-01-08 22:20:38', '2023-04-19 02:53:08', NULL),
(349, 'Prof. Ethel Nicolas Sr.', 'wilhelm50@example.org', NULL, 'male', '1-585-618-0198', '1999-08-24', '2023-03-01 04:44:21', '2023-04-20 19:34:28', NULL),
(350, 'Mac Hermiston MD', 'fdouglas@example.net', NULL, 'male', '651-330-4407', '1991-09-15', '2022-09-17 17:56:24', '2023-05-31 23:45:40', NULL),
(351, 'Hunter Feeney', 'hschuster@example.com', NULL, 'female', '1-603-767-5982', '1993-11-10', '2022-09-15 17:46:39', '2023-05-04 13:02:05', NULL),
(352, 'Titus Doyle Sr.', 'wryan@example.org', NULL, 'male', '+1.701.893.1775', '1993-11-09', '2022-11-03 06:35:26', '2023-08-21 21:43:43', NULL),
(353, 'Jabari Bernhard II', 'kim.purdy@example.org', NULL, 'female', '+13602587310', '2000-03-15', '2023-01-25 23:07:15', '2023-07-15 03:28:13', NULL),
(354, 'Dr. Marco Miller DVM', 'aglae.schulist@example.org', NULL, 'male', '+17856561305', '1989-07-17', '2023-03-06 12:05:02', '2023-05-06 05:33:52', NULL),
(355, 'Landen Stehr', 'xconroy@example.org', NULL, 'male', '210-887-9851', '2000-08-09', '2023-01-06 02:22:26', '2023-06-11 08:59:23', NULL),
(356, 'Rozella Murphy', 'lavina.weber@example.com', NULL, 'male', '+1-478-292-6240', '1994-01-22', '2022-12-24 18:51:54', '2023-05-27 01:21:05', NULL),
(357, 'Vita Kutch', 'kelli90@example.org', NULL, 'female', '+1 (424) 410-6238', '2001-03-05', '2023-01-24 19:40:58', '2023-05-15 10:21:28', NULL),
(358, 'Ms. Aiyana Adams', 'lebsack.christine@example.com', NULL, 'male', '+1-386-391-5545', '1995-08-19', '2022-11-11 18:35:35', '2023-05-01 17:15:33', NULL),
(359, 'Kamryn Goldner', 'melyssa.shields@example.org', NULL, 'female', '+1 (405) 627-9454', '1994-12-18', '2023-02-04 21:31:55', '2023-07-26 13:07:42', NULL),
(360, 'Selmer Howe', 'edgardo02@example.net', NULL, 'male', '845.469.4291', '1989-04-27', '2022-10-25 11:29:31', '2023-05-15 17:08:00', NULL),
(361, 'Mrs. Reva O\'Conner IV', 'okuneva.rosalind@example.net', NULL, 'male', '(434) 490-9785', '1990-07-06', '2022-11-09 11:32:58', '2023-05-04 14:38:28', NULL),
(362, 'Prof. Franz Stiedemann', 'frami.bridie@example.org', NULL, 'female', '351-512-9931', '1994-07-21', '2022-10-23 08:05:23', '2023-07-21 20:23:49', NULL),
(363, 'Prof. Garnet Rippin', 'stuart01@example.net', NULL, 'female', '682-303-0737', '1992-08-20', '2023-03-11 00:23:58', '2023-08-31 21:53:26', NULL),
(364, 'Ashlynn Crona', 'glemke@example.org', NULL, 'female', '+1 (405) 404-8657', '1994-12-25', '2022-12-10 20:01:16', '2023-05-01 08:41:11', NULL),
(365, 'Christy Dickinson DVM', 'delia39@example.net', NULL, 'male', '1-469-672-9491', '1993-06-26', '2022-11-30 06:24:46', '2023-07-07 15:08:31', NULL),
(366, 'Jayne Kshlerin MD', 'marquardt.fernando@example.com', NULL, 'male', '(346) 430-6640', '1998-10-17', '2022-12-03 14:32:08', '2023-04-17 19:28:31', NULL),
(367, 'Kristin Heidenreich', 'keanu.nitzsche@example.com', NULL, 'female', '352.269.5197', '1998-02-24', '2023-02-07 08:19:16', '2023-05-30 14:23:57', NULL),
(368, 'Adolfo Kiehn', 'ykuvalis@example.org', NULL, 'male', '256-704-1723', '1995-03-31', '2022-11-17 18:36:44', '2023-07-17 04:14:07', NULL),
(369, 'Savion Ward III', 'champlin.lorena@example.com', NULL, 'female', '910-642-7070', '1999-06-15', '2023-01-18 02:31:42', '2023-04-27 03:31:17', NULL),
(370, 'Braulio Nienow', 'pwisozk@example.org', NULL, 'female', '+1.207.878.6825', '1998-07-24', '2022-12-26 16:21:40', '2023-08-31 09:34:31', NULL),
(371, 'Carolyn Torphy DDS', 'dickens.keara@example.org', NULL, 'female', '832-519-4220', '1993-09-13', '2022-11-28 21:14:25', '2023-07-04 10:06:04', NULL),
(372, 'Sincere Lueilwitz V', 'ines63@example.net', NULL, 'male', '+1-973-428-2093', '1991-08-19', '2023-03-10 16:50:02', '2023-06-22 18:29:13', NULL),
(373, 'Dr. Wendy Leannon V', 'kristina94@example.net', NULL, 'male', '432-287-4798', '1991-03-29', '2023-02-14 09:18:32', '2023-09-05 06:57:27', NULL),
(374, 'Mr. Olin Von', 'gibson.javonte@example.com', NULL, 'female', '+1-936-895-5956', '1999-08-08', '2023-01-18 12:11:10', '2023-05-06 08:45:27', NULL),
(375, 'Marina Dicki', 'clarabelle.runolfsson@example.org', NULL, 'male', '1-458-373-6503', '1999-04-28', '2023-01-25 21:40:54', '2023-05-26 23:08:13', NULL),
(376, 'Mr. Mathias Ryan', 'price.halie@example.net', NULL, 'male', '678.654.1651', '1997-12-04', '2022-12-14 18:06:25', '2023-04-24 08:27:51', NULL),
(377, 'Sadye Kris DDS', 'chelsea.schinner@example.net', NULL, 'female', '623-291-1874', '2004-04-11', '2022-09-25 01:47:53', '2023-09-13 22:53:46', NULL),
(378, 'Alden Jenkins', 'schmidt.ignacio@example.net', NULL, 'male', '+1-218-533-7344', '1997-05-24', '2023-03-06 02:59:25', '2023-08-02 22:15:08', NULL),
(379, 'Leone Dooley DDS', 'adam.corkery@example.net', NULL, 'female', '+1-248-437-0284', '1992-01-05', '2022-12-27 21:12:38', '2023-05-24 17:04:22', NULL),
(380, 'Mrs. Dulce Connelly', 'beahan.adriana@example.com', NULL, 'female', '985.505.8978', '2000-11-14', '2023-03-11 22:07:52', '2023-05-12 22:04:17', NULL),
(381, 'Agustin Romaguera', 'gharber@example.org', NULL, 'male', '1-831-695-2564', '1997-09-25', '2022-10-21 03:58:15', '2023-06-13 04:52:50', NULL),
(382, 'Halie Corwin', 'marquise.rutherford@example.net', NULL, 'female', '380.842.4854', '1997-09-06', '2022-11-14 17:44:37', '2023-06-29 12:36:01', NULL),
(383, 'Dovie Kessler DVM', 'ehackett@example.com', NULL, 'male', '415.684.9209', '2001-10-08', '2023-02-26 06:28:15', '2023-06-30 10:47:37', NULL),
(384, 'Dr. Monique Mayert I', 'mina15@example.net', NULL, 'female', '1-239-542-4321', '1990-08-05', '2022-12-12 12:34:48', '2023-09-13 12:28:23', NULL),
(385, 'Joel White Jr.', 'tyrell90@example.org', NULL, 'male', '253-621-1769', '1989-01-15', '2022-11-22 17:06:12', '2023-07-16 03:50:29', NULL),
(386, 'Holden Price', 'estelle.lemke@example.org', NULL, 'male', '+1-657-858-6250', '1998-10-02', '2023-03-05 05:25:03', '2023-05-13 01:55:24', NULL),
(387, 'Keenan Bednar', 'wintheiser.jovany@example.net', NULL, 'male', '765.278.4519', '2002-05-10', '2022-10-01 05:27:39', '2023-07-14 23:45:31', NULL),
(388, 'Paolo Predovic', 'hagenes.meagan@example.org', NULL, 'male', '1-947-685-1793', '1991-08-07', '2023-02-24 08:38:37', '2023-08-10 07:35:26', NULL),
(389, 'Mona Rempel', 'caleb79@example.com', NULL, 'female', '361.707.5654', '1990-03-02', '2023-01-18 05:25:34', '2023-06-24 17:22:23', NULL),
(390, 'Prof. Velva Torphy MD', 'ywehner@example.org', NULL, 'female', '(930) 856-0091', '1992-06-22', '2022-12-03 06:46:25', '2023-04-25 08:27:30', NULL),
(391, 'Leone Welch', 'lennie.homenick@example.org', NULL, 'female', '915-449-8787', '2004-04-24', '2022-11-23 06:03:20', '2023-04-28 17:30:25', NULL),
(392, 'Mrs. Rhoda Mertz', 'bankunding@example.org', NULL, 'male', '+1 (925) 947-0427', '2004-04-11', '2022-11-24 18:36:25', '2023-09-04 19:22:13', NULL),
(393, 'Prof. Mikel O\'Reilly', 'hledner@example.net', NULL, 'male', '+17208671236', '1998-07-23', '2023-01-31 00:22:13', '2023-09-08 02:24:24', NULL),
(394, 'Fern Fadel', 'tavares04@example.org', NULL, 'male', '1-385-708-6096', '2000-02-11', '2023-03-12 10:44:04', '2023-05-13 03:14:44', NULL),
(395, 'Aisha Pouros', 'mohara@example.com', NULL, 'female', '936-283-7386', '2000-07-20', '2022-12-03 10:09:52', '2023-06-30 09:26:48', NULL),
(396, 'Royce Herman', 'marcelo72@example.net', NULL, 'male', '+15415157428', '2002-08-14', '2022-11-25 14:59:23', '2023-05-19 22:33:06', NULL),
(397, 'Maggie Wisoky', 'hill.tamia@example.org', NULL, 'male', '+1 (785) 566-0521', '1990-09-25', '2022-12-05 19:57:24', '2023-07-15 14:46:44', NULL),
(398, 'Prof. Cristina Kunde', 'briana.goyette@example.org', NULL, 'male', '+1-520-618-6802', '1997-07-15', '2022-12-15 05:36:16', '2023-07-08 02:22:00', NULL),
(399, 'Delilah Osinski PhD', 'louie.kuphal@example.org', NULL, 'female', '269.214.1943', '1994-12-13', '2023-02-15 03:28:03', '2023-05-13 15:08:37', NULL),
(400, 'Lamont Harber', 'merritt.connelly@example.com', NULL, 'female', '+15868387048', '2001-09-23', '2022-09-26 06:35:16', '2023-05-04 22:25:44', NULL),
(401, 'Ms. Nyasia Toy Jr.', 'udeckow@example.net', NULL, 'female', '+12289755715', '1997-05-22', '2023-01-20 00:01:53', '2023-04-23 08:14:55', NULL),
(402, 'Efren Kulas', 'leonor.koss@example.org', NULL, 'male', '1-786-459-2883', '2005-03-14', '2022-11-01 08:47:52', '2023-04-21 04:42:19', NULL),
(403, 'Diego Witting V', 'pswift@example.net', NULL, 'female', '234-638-0604', '1990-01-07', '2023-01-31 11:16:56', '2023-08-28 10:41:08', NULL),
(404, 'Prof. Alexa Lesch III', 'treutel.charley@example.org', NULL, 'female', '980.757.0000', '2000-05-28', '2023-01-26 04:45:14', '2023-08-19 17:35:10', NULL),
(405, 'Miss Alexandrea Morissette', 'tjacobi@example.net', NULL, 'female', '1-667-740-6593', '1994-02-14', '2023-02-22 11:31:35', '2023-08-05 23:31:03', NULL),
(406, 'Demarco Green', 'cecilia39@example.com', NULL, 'female', '+1.559.716.9585', '1989-09-30', '2023-01-20 22:44:02', '2023-05-06 23:28:45', NULL),
(407, 'Declan Balistreri', 'ereichel@example.net', NULL, 'female', '463-207-1168', '1991-04-09', '2022-10-05 16:37:55', '2023-06-17 09:35:32', NULL),
(408, 'Felton Halvorson', 'hdamore@example.com', NULL, 'male', '862-691-8078', '1993-11-06', '2023-02-22 11:16:31', '2023-08-29 08:35:26', NULL),
(409, 'Rozella Reichert', 'quinton34@example.com', NULL, 'male', '724-690-6700', '1995-08-18', '2022-10-27 19:03:47', '2023-08-03 11:29:10', NULL),
(410, 'Ms. Etha Leuschke Jr.', 'boberbrunner@example.net', NULL, 'male', '+14583044172', '1994-04-30', '2022-10-30 10:17:48', '2023-07-23 08:01:22', NULL),
(411, 'Max Cruickshank PhD', 'conn.maryjane@example.org', NULL, 'male', '+1-279-938-5391', '2004-05-15', '2022-12-23 16:06:23', '2023-07-16 12:30:36', NULL),
(412, 'Dr. Deontae Torp MD', 'della91@example.com', NULL, 'female', '(956) 603-9258', '2002-02-13', '2023-02-23 22:27:29', '2023-08-26 14:24:41', NULL),
(413, 'Mr. Freddy Corkery Sr.', 'florida86@example.net', NULL, 'male', '774-797-1716', '2003-06-16', '2023-01-10 16:32:24', '2023-06-01 14:09:01', NULL),
(414, 'Mr. Curtis Bailey', 'gillian.gibson@example.com', NULL, 'female', '(217) 258-3300', '1991-10-18', '2022-10-10 02:32:26', '2023-06-12 00:30:20', NULL),
(415, 'Mr. Derek Parisian MD', 'barton.kyleigh@example.net', NULL, 'male', '260.945.1672', '1988-10-30', '2022-11-12 22:16:00', '2023-07-17 15:54:58', NULL),
(416, 'Thaddeus Grady', 'nsanford@example.org', NULL, 'female', '1-425-274-3064', '2000-09-18', '2022-09-20 04:23:47', '2023-07-21 02:45:37', NULL),
(417, 'Allison Nikolaus V', 'abshire.barbara@example.org', NULL, 'female', '561-639-2136', '1993-08-23', '2022-10-07 05:06:53', '2023-04-29 10:37:57', NULL),
(418, 'Miss Heaven Mosciski', 'swaters@example.org', NULL, 'female', '1-325-585-3541', '1990-06-24', '2022-11-20 16:18:51', '2023-08-11 08:50:39', NULL),
(419, 'Jammie Jacobson', 'aryanna25@example.net', NULL, 'male', '(443) 843-4073', '1991-10-06', '2022-09-24 05:39:03', '2023-06-13 01:43:20', NULL),
(420, 'Felicita Champlin', 'eschmitt@example.net', NULL, 'male', '(269) 555-2114', '2004-04-27', '2023-01-29 13:01:25', '2023-05-09 05:58:14', NULL),
(421, 'Nico Beatty', 'arjun39@example.com', NULL, 'female', '878.588.8503', '2001-04-26', '2023-03-11 01:24:55', '2023-08-15 10:15:28', NULL),
(422, 'Ransom Brekke', 'dietrich.jacklyn@example.com', NULL, 'male', '(425) 929-7789', '1999-02-19', '2022-10-06 12:17:25', '2023-06-21 04:04:08', NULL),
(423, 'Teagan Littel', 'frosenbaum@example.org', NULL, 'male', '+1 (863) 675-8850', '2004-07-09', '2023-01-12 03:04:21', '2023-09-13 22:41:16', NULL),
(424, 'Gregg Bradtke', 'luettgen.nona@example.com', NULL, 'female', '+1 (541) 855-0905', '2004-12-24', '2022-10-25 00:24:17', '2023-05-27 11:56:05', NULL),
(425, 'Miss Tia Kuvalis MD', 'augustine60@example.net', NULL, 'female', '615-514-2015', '1989-11-28', '2022-12-31 22:29:55', '2023-05-15 04:22:04', NULL),
(426, 'Jodie Kling', 'braulio.rutherford@example.org', NULL, 'male', '(616) 399-5466', '1999-09-28', '2022-12-02 16:42:23', '2023-06-08 20:44:58', NULL),
(427, 'Erika Gleichner I', 'bkunde@example.net', NULL, 'male', '+18052398915', '2001-04-29', '2023-01-29 07:12:53', '2023-04-19 04:21:33', NULL),
(428, 'Rickey Halvorson', 'laury.turner@example.org', NULL, 'male', '+1-971-876-3990', '1995-12-21', '2023-03-11 09:19:52', '2023-07-04 18:18:01', NULL),
(429, 'Kevin Nicolas', 'savion97@example.org', NULL, 'female', '+1-830-902-1677', '1991-04-01', '2022-12-05 11:02:45', '2023-06-26 00:50:11', NULL),
(430, 'Alex Durgan', 'astrid01@example.com', NULL, 'male', '1-810-815-9179', '2002-11-23', '2022-11-27 05:16:57', '2023-09-12 21:31:42', NULL),
(431, 'Earnestine Batz', 'sydney.klein@example.net', NULL, 'male', '339-590-9879', '1996-12-19', '2022-11-24 19:43:19', '2023-05-09 18:56:39', NULL),
(432, 'Oceane Champlin II', 'rowan.homenick@example.org', NULL, 'female', '717.281.3000', '2003-04-04', '2022-09-24 17:23:14', '2023-08-22 05:38:02', NULL),
(433, 'Prof. Cortez Beier', 'hayes.wilbert@example.com', NULL, 'male', '+1.803.427.3998', '1989-07-26', '2022-09-15 20:40:28', '2023-08-11 07:20:30', NULL),
(434, 'Mrs. Mattie Olson MD', 'ireinger@example.org', NULL, 'female', '352-248-5904', '1998-11-10', '2023-01-28 09:59:34', '2023-08-27 09:28:33', NULL),
(435, 'Ava Glover', 'ian.legros@example.org', NULL, 'female', '+1 (240) 835-2244', '1997-05-05', '2022-10-13 05:53:50', '2023-09-12 16:42:37', NULL),
(436, 'Pedro Collier', 'deon.hoeger@example.org', NULL, 'female', '1-725-644-5982', '2004-05-14', '2022-09-14 08:45:08', '2023-05-09 09:43:01', NULL),
(437, 'Cathryn Shanahan I', 'umonahan@example.org', NULL, 'male', '781.802.6536', '2002-02-23', '2023-01-14 06:25:51', '2023-08-30 11:37:09', NULL),
(438, 'Haylie Von', 'xstreich@example.com', NULL, 'male', '+1.240.591.1999', '2001-07-12', '2022-10-21 01:43:54', '2023-09-13 19:49:10', NULL),
(439, 'Delores Farrell', 'jayde.hyatt@example.net', NULL, 'female', '+1 (747) 648-6313', '1992-10-11', '2023-01-07 03:28:14', '2023-05-22 20:05:40', NULL),
(440, 'Adolfo Gutkowski', 'veum.aubrey@example.com', NULL, 'male', '+13049155447', '1990-10-29', '2022-09-22 10:00:41', '2023-06-29 10:26:51', NULL),
(441, 'Jacques Frami IV', 'unique19@example.org', NULL, 'female', '(283) 633-1416', '2002-07-14', '2023-01-25 18:22:25', '2023-06-29 12:13:58', NULL),
(442, 'Dr. Jamaal Parisian', 'nbailey@example.com', NULL, 'female', '+1-360-639-1677', '2003-04-06', '2023-02-22 08:21:01', '2023-08-28 20:31:52', NULL),
(443, 'Ernest Walter', 'gust31@example.org', NULL, 'female', '+1 (959) 315-0248', '1989-12-25', '2022-12-28 21:30:43', '2023-09-13 19:33:09', NULL),
(444, 'Faustino Pacocha', 'chyna.hickle@example.com', NULL, 'male', '(347) 743-3247', '1990-09-21', '2022-11-18 15:54:08', '2023-05-30 08:30:18', NULL),
(445, 'Miss Emelie Barton III', 'cleora.schuster@example.net', NULL, 'female', '(865) 904-7727', '1989-10-13', '2022-10-05 22:18:39', '2023-05-12 01:43:44', NULL),
(446, 'Pink Gleichner I', 'fritz52@example.org', NULL, 'female', '(341) 527-9208', '1992-12-31', '2023-02-06 17:10:29', '2023-05-20 13:48:20', NULL),
(447, 'Miss Libbie Witting', 'ozella.bashirian@example.org', NULL, 'male', '+1.678.222.2980', '2001-04-07', '2023-03-06 04:24:20', '2023-04-21 12:02:49', NULL),
(448, 'Prof. Margret Macejkovic IV', 'rbartell@example.com', NULL, 'female', '+1 (954) 424-7771', '1990-08-22', '2022-10-17 11:08:55', '2023-09-13 00:58:06', NULL),
(449, 'Taya McLaughlin', 'verla.lang@example.net', NULL, 'female', '1-430-918-6626', '2001-08-13', '2023-03-10 10:55:26', '2023-06-17 17:54:15', NULL),
(450, 'Dan Wuckert', 'iwhite@example.net', NULL, 'male', '757-210-3890', '2004-07-04', '2023-01-23 13:44:21', '2023-05-28 16:44:02', NULL),
(451, 'Prof. Melvin Gibson', 'ebony77@example.net', NULL, 'female', '+1.831.269.5941', '1998-01-09', '2022-09-19 11:25:22', '2023-07-24 14:46:29', NULL),
(452, 'Johanna Wyman', 'ahuels@example.com', NULL, 'female', '(434) 850-6423', '1990-12-09', '2022-11-28 03:32:16', '2023-08-10 10:14:36', NULL),
(453, 'Eldred Kuhlman', 'eleazar18@example.org', NULL, 'male', '(657) 325-8933', '2003-08-31', '2022-09-22 22:48:04', '2023-07-27 21:20:08', NULL),
(454, 'Mr. Gerard Lebsack', 'larry.pagac@example.org', NULL, 'female', '858.697.5870', '2003-09-27', '2022-10-01 00:21:57', '2023-08-16 08:37:30', NULL),
(455, 'Sandra Johns', 'noberbrunner@example.com', NULL, 'male', '878.452.0927', '1996-04-18', '2022-09-18 17:42:42', '2023-05-09 06:21:41', NULL),
(456, 'Yazmin Oberbrunner III', 'norma94@example.net', NULL, 'male', '+1-601-437-9350', '1992-02-13', '2023-03-04 02:46:06', '2023-08-14 17:07:29', NULL),
(457, 'Michael Kris', 'walter.bettie@example.org', NULL, 'male', '+1.620.392.1879', '1992-05-07', '2022-12-14 23:03:36', '2023-05-04 14:22:00', NULL),
(458, 'Abigayle Schamberger', 'kiehn.keshaun@example.org', NULL, 'female', '+1.534.354.7665', '1992-12-20', '2023-01-01 07:19:12', '2023-09-05 16:43:46', NULL),
(459, 'Prof. Jerald Windler DVM', 'nmiller@example.com', NULL, 'female', '+1-517-607-2212', '1990-04-14', '2022-11-28 08:16:06', '2023-04-30 10:56:57', NULL),
(460, 'D\'angelo Strosin', 'lavinia64@example.org', NULL, 'female', '+15208950987', '1991-03-31', '2023-01-02 10:10:27', '2023-06-05 10:43:55', NULL),
(461, 'Mr. Francesco Medhurst III', 'cordia.weimann@example.org', NULL, 'male', '(986) 926-2703', '1999-01-14', '2023-01-14 17:15:05', '2023-04-23 15:14:48', NULL),
(462, 'Naomie Lowe', 'raymond41@example.com', NULL, 'female', '+1 (559) 788-2326', '2005-01-09', '2022-11-02 02:37:35', '2023-07-05 18:17:16', NULL),
(463, 'David Klein', 'mia57@example.org', NULL, 'male', '+1-351-944-8162', '2004-09-26', '2023-01-11 18:10:45', '2023-06-11 22:22:57', NULL),
(464, 'Carley Ernser', 'derick.damore@example.com', NULL, 'female', '640-436-6624', '2002-09-12', '2023-03-06 23:59:32', '2023-05-03 11:03:19', NULL),
(465, 'Melyssa Turcotte', 'mallie92@example.com', NULL, 'male', '435-220-4138', '2000-12-22', '2022-10-03 22:33:42', '2023-08-08 21:04:24', NULL),
(466, 'Werner Klein', 'kschowalter@example.org', NULL, 'female', '+1 (530) 475-9959', '1989-11-11', '2022-12-25 17:50:00', '2023-08-12 10:53:11', NULL),
(467, 'Timmy O\'Hara', 'okon.domenick@example.org', NULL, 'female', '1-641-377-3146', '2002-08-09', '2022-09-27 18:45:41', '2023-08-02 13:53:37', NULL),
(468, 'Prof. Raven Effertz', 'ppaucek@example.net', NULL, 'male', '910-355-0325', '1996-11-12', '2023-03-11 08:13:56', '2023-07-21 01:07:21', NULL),
(469, 'Margarette Russel III', 'hamill.ansel@example.org', NULL, 'male', '(820) 743-3116', '1989-05-11', '2022-09-25 22:13:59', '2023-07-31 08:06:21', NULL),
(470, 'Theresia Beer IV', 'douglas.lulu@example.net', NULL, 'male', '713.597.0126', '2002-05-27', '2023-02-23 07:09:37', '2023-07-14 17:49:03', NULL),
(471, 'Providenci Schulist PhD', 'maggio.nella@example.net', NULL, 'male', '(434) 513-5999', '2001-11-09', '2022-12-06 06:51:39', '2023-05-23 22:13:45', NULL),
(472, 'Ferne Schmitt', 'vivian00@example.org', NULL, 'female', '443.640.6645', '2003-05-06', '2022-12-05 12:09:36', '2023-06-26 23:28:38', NULL),
(473, 'Mr. Wilber Wisoky', 'rritchie@example.net', NULL, 'female', '(212) 856-7232', '1995-11-13', '2022-12-10 13:42:04', '2023-05-12 03:55:41', NULL),
(474, 'Mr. Eliezer Jakubowski IV', 'jordyn49@example.net', NULL, 'female', '(405) 616-6838', '1991-09-17', '2023-01-09 23:02:44', '2023-04-28 16:08:15', NULL),
(475, 'Tamia Ernser', 'ifriesen@example.net', NULL, 'female', '+1-928-757-8660', '1993-08-23', '2022-12-17 13:18:50', '2023-06-13 13:03:41', NULL),
(476, 'Mrs. Aryanna Kovacek', 'bogan.teagan@example.net', NULL, 'male', '+1.747.572.6860', '2000-04-06', '2022-10-29 11:01:44', '2023-06-07 00:55:20', NULL),
(477, 'Dr. Reilly Nienow Jr.', 'vincent37@example.org', NULL, 'male', '+1.617.786.3835', '1995-05-06', '2022-11-03 02:28:14', '2023-04-18 18:26:05', NULL),
(478, 'Mr. Jean Beatty II', 'kutch.christelle@example.org', NULL, 'male', '1-712-424-6130', '2000-09-08', '2022-12-26 06:17:35', '2023-05-15 02:45:01', NULL),
(479, 'Ricardo Adams', 'prohaska.al@example.net', NULL, 'female', '419.261.4886', '1998-01-29', '2022-11-12 04:16:53', '2023-07-08 14:28:28', NULL),
(480, 'Mariam Gleason', 'pkuvalis@example.org', NULL, 'female', '+15205256792', '1996-10-05', '2022-12-01 22:47:29', '2023-05-05 10:01:57', NULL),
(481, 'Petra Klocko', 'jbaumbach@example.net', NULL, 'male', '331.825.9379', '1998-06-07', '2022-12-20 01:16:09', '2023-07-07 12:42:00', NULL),
(482, 'Alessia Reichert Sr.', 'xkovacek@example.net', NULL, 'male', '+1 (240) 232-3512', '1998-02-18', '2022-10-30 04:20:02', '2023-05-20 21:06:18', NULL),
(483, 'Glenna Hand', 'wiza.jerry@example.org', NULL, 'female', '+1 (541) 260-6535', '2001-10-27', '2022-09-14 19:29:16', '2023-05-18 18:14:16', NULL),
(484, 'Prof. Maybelle Bruen DDS', 'xgrimes@example.net', NULL, 'male', '+1 (954) 674-7212', '1989-03-14', '2023-03-06 13:10:19', '2023-05-19 05:23:43', NULL),
(485, 'Rollin Feest', 'jordon35@example.net', NULL, 'male', '(804) 591-2474', '2002-02-15', '2022-10-22 01:12:08', '2023-06-19 17:27:40', NULL),
(486, 'Carley Conroy', 'keanu80@example.org', NULL, 'female', '+1-314-503-6489', '1997-06-05', '2022-10-12 15:38:37', '2023-04-29 20:19:16', NULL),
(487, 'Xander Bernhard I', 'janis47@example.org', NULL, 'male', '1-706-617-7602', '1989-07-04', '2022-11-04 01:18:52', '2023-05-07 14:56:48', NULL),
(488, 'Mr. Jaren Flatley IV', 'dulce.mitchell@example.com', NULL, 'female', '678.951.5024', '2003-10-05', '2022-11-18 05:03:14', '2023-05-23 04:14:01', NULL),
(489, 'Isaias Gleichner', 'wiegand.randall@example.net', NULL, 'female', '+1.847.420.2809', '2005-06-22', '2023-01-24 00:45:04', '2023-08-10 14:50:01', NULL),
(490, 'Alena Hermann', 'sydnee.reichert@example.com', NULL, 'female', '1-972-244-1814', '1995-07-02', '2022-12-23 15:34:38', '2023-07-21 09:45:16', NULL),
(491, 'Marlon Waters', 'gorczany.elody@example.com', NULL, 'female', '+1-865-580-5884', '2003-10-30', '2023-02-21 09:22:28', '2023-07-11 14:08:11', NULL),
(492, 'Dorris Barton', 'carolina.johnston@example.org', NULL, 'male', '1-785-257-0026', '2002-08-13', '2023-02-10 12:51:50', '2023-04-27 12:43:40', NULL),
(493, 'Laurence Gulgowski', 'price.alfred@example.net', NULL, 'female', '+13312441084', '2000-08-21', '2022-10-25 04:14:50', '2023-06-29 22:18:01', NULL),
(494, 'Ms. Abigail Mertz', 'cedrick67@example.org', NULL, 'male', '774-336-8420', '1997-12-25', '2022-09-22 00:41:59', '2023-04-28 16:23:18', NULL),
(495, 'Dr. Corbin Rau IV', 'anne62@example.com', NULL, 'female', '1-763-282-8891', '2001-07-14', '2022-10-24 09:28:26', '2023-04-19 11:29:56', NULL),
(496, 'Ray Mayert', 'maximus.ryan@example.com', NULL, 'male', '(256) 332-6874', '2005-02-11', '2022-11-16 15:25:30', '2023-07-27 00:35:12', NULL),
(497, 'Jon Leannon', 'ccruickshank@example.com', NULL, 'female', '1-757-831-4944', '2004-11-16', '2023-02-21 14:21:16', '2023-05-12 22:44:40', NULL),
(498, 'Ms. Henriette Collins Jr.', 'thad.parker@example.net', NULL, 'female', '+18068631104', '2001-05-31', '2022-10-24 21:49:19', '2023-04-20 17:28:35', NULL),
(499, 'Devante Waelchi', 'emcglynn@example.org', NULL, 'female', '(629) 883-6423', '1989-07-09', '2023-02-28 17:37:51', '2023-06-20 00:29:02', NULL),
(500, 'Mr. Darryl Feil', 'streich.jeanne@example.net', NULL, 'female', '404.991.7181', '1990-10-21', '2022-10-14 02:20:26', '2023-09-13 05:27:28', NULL),
(501, 'Nicolette Waelchi', 'treutel.teresa@example.net', NULL, 'female', '+16127240182', '2002-11-18', '2022-11-05 13:50:44', '2023-09-13 18:52:59', NULL),
(502, 'Dr. Luther Olson PhD', 'zemlak.myrtie@example.net', NULL, 'female', '+17818135742', '1994-04-18', '2023-01-08 18:03:38', '2023-04-16 02:36:50', NULL),
(503, 'Mrs. Nadia D\'Amore DVM', 'luisa.auer@example.org', NULL, 'male', '+1 (762) 703-1931', '1999-06-14', '2023-03-02 12:34:35', '2023-09-04 23:29:25', NULL),
(504, 'Cruz Gottlieb', 'quinn79@example.org', NULL, 'male', '202.619.5622', '2003-06-11', '2023-01-26 06:50:18', '2023-05-07 20:33:20', NULL),
(505, 'Prof. Alfredo Metz', 'leta.will@example.com', NULL, 'female', '+1-618-263-4615', '2002-03-31', '2022-12-05 04:16:09', '2023-07-08 08:13:48', NULL),
(506, 'Miss Shanon Schiller IV', 'sauer.johathan@example.com', NULL, 'female', '586-451-6480', '2001-11-24', '2022-11-17 04:58:32', '2023-05-10 02:27:04', NULL),
(507, 'Greg West', 'joana.klocko@example.org', NULL, 'female', '+13475651407', '1992-09-18', '2023-03-05 19:56:10', '2023-05-15 19:15:10', NULL),
(508, 'Tobin Volkman', 'heloise89@example.org', NULL, 'female', '+1-351-558-3657', '1994-03-23', '2022-12-03 14:10:45', '2023-08-01 14:41:39', NULL),
(509, 'Dr. Royal Kuhic IV', 'kaylin.paucek@example.net', NULL, 'male', '+19282082634', '1998-10-25', '2022-12-24 12:46:56', '2023-08-24 01:31:50', NULL),
(510, 'Mr. Gianni Kessler I', 'flossie31@example.org', NULL, 'female', '+13615806087', '1996-11-15', '2022-10-18 04:35:48', '2023-09-07 05:40:11', NULL),
(511, 'Fabiola Price', 'onie10@example.org', NULL, 'male', '1-715-770-5642', '2002-01-28', '2022-11-07 18:57:01', '2023-07-29 15:11:38', NULL),
(512, 'Rhiannon Boehm', 'luisa.hauck@example.org', NULL, 'female', '+1-530-561-2230', '1991-05-02', '2022-10-06 03:27:22', '2023-09-10 06:11:01', NULL),
(513, 'Francesca Dibbert DVM', 'wkris@example.com', NULL, 'female', '435-994-5473', '1989-10-06', '2022-12-28 16:02:04', '2023-06-02 13:13:20', NULL),
(514, 'Hosea Gulgowski Sr.', 'yhauck@example.com', NULL, 'female', '+1-678-316-1428', '2000-01-20', '2022-09-22 14:34:32', '2023-05-24 11:02:07', NULL),
(515, 'Minerva Ankunding DVM', 'sporer.lisa@example.net', NULL, 'female', '+1-386-669-2623', '1993-07-05', '2022-10-27 22:56:16', '2023-08-18 11:17:21', NULL),
(516, 'Lilian Hegmann', 'ashtyn.green@example.org', NULL, 'female', '321-966-8861', '2001-09-11', '2023-01-06 04:25:13', '2023-04-25 19:48:54', NULL),
(517, 'Prof. Letitia Rice MD', 'kuhn.jacinto@example.org', NULL, 'male', '240-740-9647', '2003-08-05', '2023-02-18 00:47:41', '2023-07-02 12:19:46', NULL),
(518, 'Jeramy Yundt', 'muller.jefferey@example.com', NULL, 'female', '+1-325-345-2034', '2000-01-16', '2022-09-18 07:01:41', '2023-08-30 19:10:17', NULL),
(519, 'Mr. Johnny Greenfelder', 'larkin.jade@example.com', NULL, 'male', '+1.585.621.2044', '1993-03-16', '2023-02-14 13:53:00', '2023-08-16 08:49:09', NULL),
(520, 'Moshe Leuschke MD', 'tjohnson@example.org', NULL, 'female', '330.395.3753', '1990-11-06', '2023-03-10 18:13:45', '2023-07-11 07:17:01', NULL),
(521, 'Dr. Maggie Dach', 'reichert.brando@example.net', NULL, 'male', '(720) 967-2210', '1990-02-04', '2022-10-15 23:10:37', '2023-08-25 20:50:59', NULL),
(522, 'Dr. Raphael Roberts', 'zparker@example.org', NULL, 'female', '838.940.3843', '2002-03-03', '2022-12-18 13:32:45', '2023-08-07 05:08:52', NULL),
(523, 'Royal Armstrong', 'dorthy.runte@example.com', NULL, 'female', '979-543-2304', '1994-10-06', '2023-03-12 03:40:40', '2023-08-16 06:05:28', NULL),
(524, 'Prof. Bette Jast MD', 'dheathcote@example.com', NULL, 'male', '+1 (650) 466-7892', '1992-01-08', '2023-01-09 10:33:51', '2023-07-03 19:47:10', NULL),
(525, 'Dr. Larue Trantow', 'teichmann@example.net', NULL, 'male', '541.999.8729', '1991-11-24', '2022-10-10 11:43:34', '2023-08-10 08:27:48', NULL),
(526, 'Rosella Schmitt I', 'zdibbert@example.org', NULL, 'male', '(820) 770-1253', '1989-05-02', '2023-03-07 17:10:31', '2023-05-12 23:11:58', NULL),
(527, 'Mr. Elliot Barton', 'nova83@example.org', NULL, 'female', '(305) 336-1590', '2002-09-03', '2022-11-24 10:32:58', '2023-06-20 06:35:05', NULL),
(528, 'Mona Crist', 'lisandro.blanda@example.com', NULL, 'male', '+1 (740) 553-5769', '1999-10-01', '2023-02-05 07:16:25', '2023-07-30 10:35:13', NULL),
(529, 'Johanna Lesch', 'barrett02@example.org', NULL, 'male', '+1 (417) 401-8232', '1998-01-15', '2022-10-04 08:02:14', '2023-05-21 05:45:47', NULL),
(530, 'Mortimer Grady', 'hamill.luella@example.net', NULL, 'female', '(650) 252-8880', '1990-03-27', '2022-09-27 11:58:34', '2023-07-29 05:41:22', NULL),
(531, 'Jefferey Walker', 'lura21@example.org', NULL, 'male', '+1.254.634.8965', '2002-04-03', '2022-10-14 08:34:35', '2023-07-22 11:42:30', NULL),
(532, 'Kiarra Nicolas', 'adams.sunny@example.net', NULL, 'male', '712.393.9157', '1995-02-16', '2022-11-12 07:16:18', '2023-05-17 10:14:43', NULL),
(533, 'Orpha Reinger I', 'iliana96@example.com', NULL, 'female', '+18659900943', '1999-02-07', '2022-10-09 04:05:18', '2023-06-04 15:36:00', NULL),
(534, 'Dr. Fermin Hermann', 'reynolds.antoinette@example.net', NULL, 'male', '425-938-1131', '2001-12-03', '2022-12-27 10:07:11', '2023-07-23 04:23:35', NULL),
(535, 'Dallas Lowe', 'amiller@example.org', NULL, 'male', '407.409.6671', '1988-10-12', '2022-12-16 09:04:29', '2023-05-12 10:18:27', NULL),
(536, 'Stan Hill', 'rene.kessler@example.net', NULL, 'male', '+18384447503', '1992-08-20', '2023-01-10 17:05:28', '2023-06-23 00:03:04', NULL),
(537, 'Kiarra Robel', 'claud.okuneva@example.com', NULL, 'male', '+1-213-912-2612', '1994-11-02', '2023-02-09 12:37:28', '2023-09-06 09:32:05', NULL),
(538, 'Aniya Luettgen', 'afeest@example.net', NULL, 'female', '337.754.6969', '1996-02-18', '2022-11-16 11:06:22', '2023-05-11 09:11:12', NULL),
(539, 'Ms. Kiana Schowalter', 'ewell59@example.com', NULL, 'female', '480-504-8833', '2001-04-15', '2022-10-12 09:44:07', '2023-08-06 19:21:01', NULL),
(540, 'Victoria Morissette', 'gschmeler@example.com', NULL, 'female', '+1-972-990-7409', '1996-10-02', '2023-01-19 23:44:10', '2023-07-01 06:24:24', NULL),
(541, 'Melvin Flatley', 'pattie.langosh@example.com', NULL, 'male', '252.393.0248', '1988-10-16', '2022-11-26 12:08:16', '2023-05-04 15:24:47', NULL),
(542, 'Dr. Justen DuBuque DDS', 'rohan.ebony@example.com', NULL, 'female', '720.720.5323', '1994-04-20', '2022-10-14 19:45:01', '2023-07-25 16:33:28', NULL),
(543, 'Nickolas Fisher', 'beryl.yost@example.org', NULL, 'male', '+18453592889', '1998-02-24', '2023-02-09 05:30:39', '2023-06-15 00:19:22', NULL),
(544, 'Prof. Rodrick Boyer', 'moen.kennedi@example.com', NULL, 'male', '1-361-770-7002', '2004-07-06', '2022-10-21 22:47:53', '2023-08-22 00:46:13', NULL),
(545, 'Prof. Milton Mosciski', 'tklocko@example.org', NULL, 'female', '+1-646-661-8774', '1989-02-24', '2023-03-01 01:01:04', '2023-04-24 14:55:25', NULL),
(546, 'Joshuah Bechtelar Sr.', 'bauch.lavinia@example.com', NULL, 'female', '+1-941-612-3907', '1995-11-28', '2023-03-07 11:58:05', '2023-05-11 03:24:58', NULL),
(547, 'Mrs. Maci Denesik', 'laney.kub@example.org', NULL, 'male', '541-445-5871', '1990-07-30', '2022-11-19 01:44:54', '2023-05-26 07:06:40', NULL),
(548, 'Dr. Vida Kerluke Sr.', 'bennie.green@example.com', NULL, 'female', '+13168064945', '2001-11-27', '2023-02-07 23:38:40', '2023-08-31 21:18:36', NULL),
(549, 'Ayana Rolfson', 'rice.augustine@example.org', NULL, 'male', '757.761.8636', '1996-08-09', '2023-02-23 15:41:34', '2023-04-25 15:41:50', NULL),
(550, 'Dr. Giovanny Labadie V', 'wiza.uriel@example.net', NULL, 'female', '+16605901288', '1988-10-06', '2022-09-15 05:50:55', '2023-06-06 20:01:06', NULL),
(551, 'Vance O\'Connell', 'brianne57@example.org', NULL, 'female', '+1-239-657-3997', '1992-06-10', '2023-01-19 16:10:34', '2023-04-25 03:09:41', NULL),
(552, 'Vickie Rau', 'birdie92@example.net', NULL, 'male', '817.385.6772', '1996-12-29', '2023-02-27 03:52:54', '2023-06-25 08:49:31', NULL),
(553, 'Maxwell Johnson', 'korey71@example.org', NULL, 'female', '(913) 322-4588', '1990-06-11', '2022-09-20 18:31:59', '2023-05-03 03:22:14', NULL),
(554, 'Dr. Stephan Nader DDS', 'audra.mcglynn@example.org', NULL, 'male', '541-958-1543', '1999-09-14', '2022-11-02 00:39:12', '2023-06-21 23:43:24', NULL),
(555, 'Grayson Heidenreich', 'rsimonis@example.org', NULL, 'male', '+15404515093', '2005-07-29', '2022-10-26 10:15:46', '2023-05-12 05:55:24', NULL),
(556, 'Amara Stark', 'zboncak.addison@example.com', NULL, 'male', '930-562-7748', '1996-10-25', '2022-12-31 17:46:50', '2023-08-07 23:36:51', NULL),
(557, 'Seth Pouros DDS', 'echamplin@example.com', NULL, 'female', '+1 (863) 526-0027', '2005-03-31', '2023-01-12 07:53:16', '2023-04-16 04:07:14', NULL),
(558, 'Henri Mosciski', 'lowe.jackie@example.com', NULL, 'female', '1-725-323-7650', '1998-10-22', '2022-11-02 16:02:01', '2023-05-11 02:01:10', NULL),
(559, 'Carolina Kovacek', 'ansel.bechtelar@example.org', NULL, 'male', '+1 (458) 866-2737', '2002-02-02', '2022-10-09 18:50:27', '2023-09-06 07:37:00', NULL),
(560, 'Prof. Juliana Gerhold DVM', 'wellington.heathcote@example.org', NULL, 'female', '+1 (360) 850-5953', '1990-04-18', '2023-01-13 02:58:42', '2023-07-12 19:58:59', NULL),
(561, 'Mr. Westley Schmidt', 'steuber.niko@example.org', NULL, 'male', '1-937-425-5705', '2001-12-02', '2023-03-02 06:37:44', '2023-09-06 09:02:55', NULL),
(562, 'Gabrielle Heathcote', 'hudson.stamm@example.net', NULL, 'male', '1-845-795-1448', '1992-07-28', '2022-11-14 11:32:01', '2023-09-10 07:29:38', NULL),
(563, 'Joy Gulgowski', 'rath.kelton@example.com', NULL, 'male', '(510) 263-5854', '1994-05-31', '2022-11-13 12:29:19', '2023-09-03 20:13:51', NULL),
(564, 'Miss Zita Hodkiewicz', 'benjamin.mayer@example.net', NULL, 'female', '+1.310.864.1226', '1998-10-10', '2022-10-26 05:18:51', '2023-07-29 15:38:32', NULL),
(565, 'Prof. Marshall Hamill V', 'isaac21@example.net', NULL, 'female', '1-920-661-1618', '2003-11-05', '2023-02-03 00:29:11', '2023-05-23 06:55:04', NULL),
(566, 'Ms. Jewel Klocko III', 'jacobson.giovani@example.com', NULL, 'male', '+1-540-597-2593', '1994-07-22', '2022-10-04 21:01:18', '2023-06-20 09:18:24', NULL),
(567, 'Marcelo Beer I', 'hbartoletti@example.com', NULL, 'male', '(571) 980-3770', '1992-03-25', '2023-01-19 05:05:07', '2023-08-26 22:37:58', NULL),
(568, 'Kendrick Walsh Jr.', 'gulgowski.agnes@example.com', NULL, 'male', '1-725-315-8126', '1993-02-03', '2023-02-17 23:18:52', '2023-05-23 08:41:00', NULL),
(569, 'Presley Wehner', 'leuschke.joan@example.com', NULL, 'female', '772-409-6352', '1992-06-28', '2023-02-10 13:10:02', '2023-05-21 15:27:58', NULL),
(570, 'Gideon Blick II', 'allene.kreiger@example.org', NULL, 'male', '+1-912-299-5112', '1995-09-14', '2023-02-26 15:35:52', '2023-07-13 07:41:20', NULL),
(571, 'Felton Toy', 'qmetz@example.org', NULL, 'female', '+1 (240) 895-5549', '2003-12-11', '2023-01-03 13:13:08', '2023-05-20 03:27:38', NULL),
(572, 'Garth Kozey', 'mona.blick@example.org', NULL, 'male', '1-323-384-2603', '1997-07-12', '2022-11-15 23:37:25', '2023-09-02 21:03:53', NULL),
(573, 'Dr. Rosendo Strosin', 'jazlyn.vonrueden@example.net', NULL, 'male', '1-267-644-6005', '1999-01-15', '2022-10-24 20:58:14', '2023-05-10 03:10:44', NULL),
(574, 'Brianne Bartoletti', 'schoen.cary@example.com', NULL, 'female', '838.583.0861', '2004-08-12', '2023-02-16 02:31:07', '2023-06-30 12:47:07', NULL),
(575, 'Terry Stark PhD', 'xbernhard@example.org', NULL, 'female', '559.712.8849', '2002-09-11', '2023-02-10 23:20:22', '2023-08-21 13:47:49', NULL),
(576, 'Kacie Crooks', 'easton.herman@example.com', NULL, 'male', '1-281-451-3536', '1997-01-28', '2022-12-10 06:46:10', '2023-06-17 00:56:56', NULL),
(577, 'Spencer Hoeger', 'pwiza@example.org', NULL, 'female', '(931) 752-7434', '1988-12-28', '2023-02-27 03:29:44', '2023-05-05 17:32:15', NULL),
(578, 'Turner Macejkovic', 'rath.meda@example.com', NULL, 'male', '(845) 979-2064', '1998-06-24', '2023-02-10 07:15:13', '2023-07-07 13:57:08', NULL),
(579, 'Dr. Jaiden Conroy', 'alexys80@example.net', NULL, 'female', '850.893.4134', '2005-08-07', '2022-11-19 06:46:39', '2023-04-20 12:32:10', NULL),
(580, 'Mr. Earnest Gulgowski', 'tabitha.conroy@example.org', NULL, 'female', '+17739766237', '1998-08-23', '2022-12-14 07:33:29', '2023-08-16 22:58:22', NULL),
(581, 'Kari Schroeder', 'monica43@example.com', NULL, 'male', '+1.919.580.3711', '2000-10-17', '2023-02-15 03:32:02', '2023-08-03 17:59:20', NULL),
(582, 'Dr. Mose Goldner', 'syble35@example.com', NULL, 'female', '+12137153950', '1993-11-03', '2022-11-01 15:00:07', '2023-04-20 10:39:26', NULL),
(583, 'Dwight Schumm', 'wprohaska@example.net', NULL, 'female', '830.650.7920', '1991-09-09', '2023-01-15 04:37:35', '2023-05-05 15:39:14', NULL),
(584, 'Jason Bauch PhD', 'cmante@example.org', NULL, 'female', '(661) 459-1329', '1992-11-26', '2022-10-16 17:26:58', '2023-06-10 21:36:06', NULL),
(585, 'Sven Boyle', 'unicolas@example.net', NULL, 'female', '(763) 912-8090', '2001-08-17', '2022-12-10 08:24:54', '2023-04-20 16:08:43', NULL),
(586, 'Wilton Daniel', 'mccullough.leanna@example.org', NULL, 'female', '463.988.0818', '2004-09-26', '2023-01-21 13:52:59', '2023-04-27 20:53:12', NULL),
(587, 'Miss Flossie Barton V', 'adam.thompson@example.net', NULL, 'female', '321-377-0690', '1999-07-21', '2023-02-03 10:43:14', '2023-09-04 13:29:03', NULL),
(588, 'Tess Powlowski', 'harris.dale@example.net', NULL, 'male', '219-625-7129', '1998-02-22', '2022-10-17 04:17:21', '2023-08-31 23:23:29', NULL),
(589, 'Wilford Nitzsche', 'abbigail53@example.net', NULL, 'female', '+1 (959) 741-5744', '2003-07-01', '2023-02-13 03:26:01', '2023-08-12 21:55:14', NULL),
(590, 'Bonita Frami', 'nikolaus.monte@example.org', NULL, 'female', '1-540-461-3263', '1995-07-02', '2023-03-07 05:00:10', '2023-06-29 05:22:09', NULL),
(591, 'Prof. Kayleigh Koss', 'aubree.vandervort@example.net', NULL, 'male', '(331) 424-9756', '1997-07-01', '2023-02-04 04:02:44', '2023-06-17 06:45:51', NULL),
(592, 'Nichole Blanda', 'garry.bins@example.com', NULL, 'female', '320-464-7764', '1995-08-27', '2022-12-11 22:31:30', '2023-07-21 23:46:43', NULL),
(593, 'Santino Rowe', 'adell.krajcik@example.com', NULL, 'male', '(678) 402-5620', '1997-10-06', '2022-11-13 03:57:50', '2023-08-28 13:25:38', NULL),
(594, 'Berniece Stark', 'keeling.jacinthe@example.net', NULL, 'male', '+15206288365', '2002-02-15', '2022-10-04 17:20:18', '2023-08-23 10:30:07', NULL),
(595, 'Mariela Cartwright PhD', 'kemmer.cyrus@example.org', NULL, 'male', '1-323-234-1197', '2005-08-22', '2022-09-16 11:53:25', '2023-06-13 16:49:02', NULL),
(596, 'Jaquelin Hayes Sr.', 'ericka.runte@example.org', NULL, 'female', '+1 (463) 707-9014', '1998-06-05', '2022-10-01 05:47:06', '2023-05-20 22:14:32', NULL),
(597, 'Dr. Salvatore Rippin', 'duane.murray@example.net', NULL, 'female', '458-994-9923', '1997-01-27', '2022-09-19 00:13:48', '2023-07-06 06:14:35', NULL),
(598, 'Antonia Morissette II', 'eddie23@example.org', NULL, 'male', '727-397-6229', '1993-08-15', '2022-12-24 09:43:26', '2023-05-18 03:22:48', NULL),
(599, 'Ross Sauer', 'lreinger@example.org', NULL, 'male', '727-887-3115', '1991-01-29', '2023-03-12 10:28:16', '2023-04-26 12:25:17', NULL),
(600, 'Gennaro Homenick', 'agustina55@example.org', NULL, 'female', '+13218079087', '1988-11-28', '2023-01-14 12:56:42', '2023-04-14 07:21:23', NULL),
(601, 'Kaleb Jacobson', 'destiney67@example.net', NULL, 'female', '1-520-231-9619', '1998-04-25', '2022-11-16 21:58:32', '2023-07-04 05:05:07', NULL),
(602, 'Arvid Kiehn', 'leonard85@example.org', NULL, 'female', '(617) 233-1212', '1993-11-02', '2022-11-29 11:22:38', '2023-06-12 14:35:28', NULL),
(603, 'Miss Lynn Osinski I', 'keebler.carroll@example.com', NULL, 'male', '+1-364-449-6102', '1994-10-25', '2023-02-25 20:06:14', '2023-06-14 17:58:27', NULL),
(604, 'Emile Schamberger DVM', 'vhaley@example.net', NULL, 'female', '937-387-0972', '1991-03-19', '2023-01-25 02:57:28', '2023-07-05 11:42:04', NULL),
(605, 'Dr. Damian Renner', 'jacobs.nelson@example.com', NULL, 'female', '+1-661-677-0741', '2000-08-06', '2022-12-02 00:40:41', '2023-08-28 03:41:45', NULL),
(606, 'Eloy Jacobi DDS', 'qschmitt@example.org', NULL, 'female', '+1.347.369.6868', '1992-08-01', '2022-12-05 12:36:40', '2023-08-05 20:11:48', NULL),
(607, 'Dr. Germaine Schmidt I', 'xzieme@example.net', NULL, 'female', '+1-231-292-8651', '1996-07-12', '2023-01-28 15:26:14', '2023-07-21 17:21:45', NULL),
(608, 'Ms. Maude Beer', 'maye.kirlin@example.net', NULL, 'female', '+1-810-532-2976', '1996-07-09', '2023-01-14 03:39:16', '2023-08-28 11:40:49', NULL),
(609, 'Dr. Thalia Cruickshank', 'rhegmann@example.com', NULL, 'male', '+1 (660) 241-1492', '2004-02-11', '2023-02-27 13:36:10', '2023-06-01 00:16:30', NULL),
(610, 'Celestine Prosacco', 'trystan60@example.net', NULL, 'male', '909-218-9392', '2003-06-05', '2022-12-28 23:57:11', '2023-05-15 17:20:34', NULL),
(611, 'Xavier Medhurst', 'kaycee26@example.org', NULL, 'female', '1-718-615-4460', '1992-06-15', '2022-11-16 08:35:50', '2023-05-16 05:32:31', NULL),
(612, 'Prof. Beverly Hilpert', 'tcasper@example.org', NULL, 'male', '+19528250587', '1997-10-22', '2022-11-25 12:07:50', '2023-07-23 13:14:04', NULL),
(613, 'Araceli Prohaska', 'augusta31@example.com', NULL, 'male', '1-347-584-3938', '1990-10-03', '2022-09-20 02:17:23', '2023-07-03 06:28:30', NULL),
(614, 'Ambrose Bechtelar II', 'alvina.simonis@example.org', NULL, 'female', '+17317428661', '2002-04-30', '2022-11-28 13:15:25', '2023-06-17 22:05:18', NULL),
(615, 'Aron Little IV', 'willa24@example.net', NULL, 'male', '(540) 870-7530', '1991-12-20', '2022-12-11 17:48:35', '2023-08-07 00:27:31', NULL),
(616, 'Modesto Schmidt', 'ferry.odie@example.org', NULL, 'female', '+1-978-530-5597', '2005-01-28', '2022-11-12 17:31:39', '2023-08-30 02:21:55', NULL),
(617, 'Mossie Hickle', 'clare.murazik@example.org', NULL, 'male', '(508) 758-3325', '1997-01-24', '2022-11-17 20:58:52', '2023-04-28 20:19:06', NULL),
(618, 'Delaney Beer', 'collins.braeden@example.org', NULL, 'male', '479.660.7184', '1996-01-26', '2023-02-11 02:16:51', '2023-07-31 12:40:44', NULL),
(619, 'Desmond Roberts', 'kerluke.idell@example.com', NULL, 'male', '+16815862790', '1997-12-07', '2022-11-25 17:29:09', '2023-09-12 20:05:15', NULL),
(620, 'Gail Hickle', 'dpfeffer@example.com', NULL, 'female', '270.859.3108', '1989-08-08', '2022-11-11 03:17:32', '2023-07-21 21:17:06', NULL),
(621, 'Haley Renner', 'jean.little@example.org', NULL, 'female', '947.484.0840', '2003-06-30', '2022-10-27 05:36:46', '2023-05-04 15:34:41', NULL),
(622, 'Orland Lemke', 'hallie91@example.net', NULL, 'male', '947.689.3167', '2001-10-09', '2022-11-22 03:55:15', '2023-05-21 05:19:59', NULL),
(623, 'Prof. Malvina Hauck IV', 'dane.zemlak@example.com', NULL, 'male', '+17342297662', '1989-04-17', '2023-02-14 03:47:01', '2023-09-02 02:59:00', NULL),
(624, 'Peyton Kirlin', 'jeanette12@example.com', NULL, 'male', '763-840-4733', '1991-10-04', '2022-11-17 17:39:08', '2023-04-18 18:33:31', NULL),
(625, 'Prof. Bruce O\'Connell', 'weissnat.eryn@example.org', NULL, 'female', '+1-305-994-0399', '1994-01-14', '2022-11-07 09:09:04', '2023-05-29 16:13:43', NULL),
(626, 'Prof. Adam Davis', 'greenholt.kaylah@example.com', NULL, 'male', '+1.272.993.1822', '1990-03-21', '2022-11-04 09:16:04', '2023-05-26 21:22:57', NULL),
(627, 'Gabe Wunsch', 'enrico14@example.org', NULL, 'female', '(660) 401-1058', '1996-03-26', '2023-01-14 12:04:44', '2023-08-23 01:47:38', NULL),
(628, 'Mr. Anastacio Balistreri DVM', 'macejkovic.eileen@example.org', NULL, 'female', '551-443-3876', '1994-08-24', '2022-11-23 07:00:01', '2023-08-22 08:14:58', NULL),
(629, 'Brenden Kilback DDS', 'khomenick@example.org', NULL, 'female', '1-820-267-8372', '2000-05-03', '2022-09-21 17:35:55', '2023-08-13 16:32:56', NULL),
(630, 'Alessia Carroll DDS', 'rgreenholt@example.net', NULL, 'female', '+1-469-318-3277', '2002-01-30', '2022-12-31 05:28:30', '2023-07-11 01:14:09', NULL),
(631, 'Mr. Richmond Jacobson IV', 'columbus.mclaughlin@example.org', NULL, 'male', '+1 (341) 573-7931', '2004-03-27', '2023-02-15 16:12:26', '2023-06-12 20:24:14', NULL),
(632, 'Delaney Hagenes', 'fred00@example.org', NULL, 'male', '575.994.3944', '1995-06-03', '2022-11-20 04:37:05', '2023-08-09 20:44:19', NULL),
(633, 'Miss River Sanford III', 'vivian.crona@example.com', NULL, 'male', '332.858.8086', '1999-07-27', '2022-10-30 19:07:09', '2023-04-24 11:56:25', NULL),
(634, 'Glenna Heaney', 'barrett63@example.org', NULL, 'female', '+1.207.583.4370', '1993-04-15', '2022-11-03 03:42:44', '2023-07-03 04:07:46', NULL),
(635, 'Bell Bayer', 'clark15@example.net', NULL, 'male', '423.867.3751', '2001-05-01', '2022-12-11 23:57:12', '2023-05-20 02:05:46', NULL),
(636, 'Sierra Kunde', 'rjohns@example.org', NULL, 'male', '1-541-738-0267', '1995-11-28', '2022-09-22 01:47:01', '2023-04-18 09:14:18', NULL),
(637, 'Kayden Casper', 'hegmann.hayden@example.com', NULL, 'female', '458.471.0067', '1999-09-06', '2023-03-12 11:19:34', '2023-08-24 05:30:36', NULL),
(638, 'Mrs. Patience Volkman IV', 'gabriel81@example.org', NULL, 'male', '1-707-583-9529', '1992-08-21', '2022-12-26 00:57:39', '2023-07-03 02:58:26', NULL),
(639, 'Conor Goyette', 'edythe17@example.net', NULL, 'female', '(681) 353-8820', '2000-12-09', '2022-11-19 14:36:08', '2023-09-04 01:35:04', NULL),
(640, 'Audra O\'Connell', 'ziemann.rogers@example.org', NULL, 'female', '325-269-2281', '1999-05-04', '2023-02-10 00:44:11', '2023-09-09 05:24:59', NULL),
(641, 'Ms. Charity Stamm Sr.', 'era27@example.net', NULL, 'male', '+1 (716) 949-3387', '1998-10-03', '2022-10-14 08:51:01', '2023-08-01 15:41:05', NULL),
(642, 'Vilma Feeney', 'bhintz@example.net', NULL, 'female', '+1.954.268.4354', '1994-03-04', '2022-10-19 12:19:17', '2023-09-04 12:59:40', NULL),
(643, 'Ona Hansen', 'mina23@example.com', NULL, 'female', '+1.740.509.9700', '1997-07-02', '2022-10-31 08:17:11', '2023-07-06 22:44:50', NULL),
(644, 'Nedra Schuppe', 'tpfannerstill@example.net', NULL, 'male', '+16788058411', '1998-12-15', '2023-02-11 02:42:59', '2023-07-03 04:12:26', NULL),
(645, 'Kyla Mraz', 'jaunita17@example.org', NULL, 'female', '567-415-4672', '2005-04-14', '2022-12-05 05:57:33', '2023-05-29 02:09:52', NULL),
(646, 'Jack Leffler', 'vmarks@example.com', NULL, 'female', '832-882-6737', '2004-08-08', '2022-09-23 21:41:13', '2023-08-05 18:25:32', NULL),
(647, 'Prof. Murl Beer', 'bwisoky@example.net', NULL, 'female', '220-438-1883', '1999-03-21', '2023-03-03 12:39:10', '2023-04-21 09:38:55', NULL),
(648, 'Christian Champlin', 'considine.marcelle@example.org', NULL, 'male', '1-207-721-8520', '1996-08-29', '2022-11-19 00:45:12', '2023-08-26 08:35:42', NULL),
(649, 'Salvatore Veum', 'monahan.brittany@example.org', NULL, 'female', '1-986-325-0363', '2000-12-10', '2022-09-29 08:30:12', '2023-05-29 05:04:30', NULL),
(650, 'Amos Smith', 'marquardt.rosemary@example.net', NULL, 'female', '(346) 770-8496', '2004-09-28', '2022-11-22 09:22:52', '2023-08-11 06:22:17', NULL),
(651, 'Mr. Gilberto McLaughlin', 'keyshawn45@example.com', NULL, 'male', '915-798-6979', '1998-02-15', '2022-11-23 19:02:24', '2023-07-27 14:12:16', NULL),
(652, 'Miss Camylle Koelpin IV', 'waldo84@example.org', NULL, 'female', '+17434743746', '1999-07-04', '2023-01-05 05:58:47', '2023-07-07 07:53:45', NULL),
(653, 'Elmira Durgan', 'lacey.sipes@example.org', NULL, 'male', '+1.410.905.1930', '1998-03-10', '2022-10-15 14:46:46', '2023-09-04 10:19:52', NULL),
(654, 'Kassandra Bailey', 'mikayla79@example.net', NULL, 'female', '(308) 770-9496', '2003-07-02', '2022-12-10 06:26:12', '2023-08-20 15:48:11', NULL),
(655, 'Buddy Lang', 'rolfson.georgiana@example.net', NULL, 'female', '+1-479-473-0278', '2003-06-17', '2022-11-05 04:38:34', '2023-06-04 21:57:24', NULL),
(656, 'Prof. Eliza Crist V', 'elfrieda.boyle@example.com', NULL, 'male', '424.888.1485', '2004-08-03', '2022-10-16 10:01:37', '2023-05-06 07:25:19', NULL),
(657, 'Dr. Jordyn Kuhic IV', 'pedro50@example.org', NULL, 'female', '908-509-0586', '1995-04-15', '2022-10-13 18:46:15', '2023-05-24 10:45:26', NULL),
(658, 'Izabella Renner', 'madelyn93@example.org', NULL, 'female', '332.298.1394', '2002-07-11', '2022-12-23 05:24:13', '2023-06-11 00:17:45', NULL),
(659, 'Efren Koepp', 'ireynolds@example.org', NULL, 'female', '513.790.8984', '1994-03-26', '2022-09-29 19:02:21', '2023-05-13 05:08:28', NULL),
(660, 'Hank Roob', 'paul64@example.com', NULL, 'male', '660-714-8957', '1995-11-10', '2023-01-05 06:23:52', '2023-04-21 13:14:32', NULL),
(661, 'Jamel Tillman', 'wisozk.tito@example.com', NULL, 'male', '564-784-3771', '1992-08-25', '2022-12-19 10:23:03', '2023-07-09 09:07:01', NULL),
(662, 'Mr. Johnathan VonRueden', 'abbott.pearlie@example.com', NULL, 'female', '904-716-7542', '1989-06-22', '2023-02-11 18:11:49', '2023-07-23 10:48:57', NULL),
(663, 'Delfina Doyle', 'denesik.pearline@example.org', NULL, 'male', '308.294.8678', '2003-10-31', '2023-02-08 05:59:36', '2023-06-14 23:44:09', NULL),
(664, 'Godfrey Moen', 'bmosciski@example.org', NULL, 'female', '804.609.4914', '1991-05-23', '2022-10-28 17:50:17', '2023-05-03 19:21:12', NULL);
INSERT INTO `shop_customers` (`id`, `name`, `email`, `photo`, `gender`, `phone`, `birthday`, `created_at`, `updated_at`, `deleted_at`) VALUES
(665, 'Grace Kshlerin', 'bertha.volkman@example.org', NULL, 'female', '+1-603-806-1884', '2004-08-05', '2023-02-20 04:19:49', '2023-09-10 00:59:10', NULL),
(666, 'Deion Berge', 'corbin41@example.org', NULL, 'female', '+1.785.447.4497', '1996-02-02', '2023-03-04 23:00:59', '2023-04-25 20:22:03', NULL),
(667, 'Mr. Carleton Thompson DVM', 'uswift@example.org', NULL, 'female', '+1-805-579-0131', '1997-04-23', '2022-09-28 12:44:16', '2023-08-28 19:40:11', NULL),
(668, 'Helmer Weber', 'stroman.marisol@example.com', NULL, 'male', '(567) 247-3058', '1992-11-25', '2022-12-15 22:01:22', '2023-04-30 23:44:44', NULL),
(669, 'Prof. Jerrod Morar Jr.', 'emmerich.adella@example.org', NULL, 'male', '272.732.7359', '1988-12-07', '2022-10-29 12:59:44', '2023-08-27 11:13:31', NULL),
(670, 'Cynthia Collins DVM', 'lesch.stone@example.net', NULL, 'female', '+17704921511', '1989-06-02', '2023-01-13 06:58:40', '2023-08-09 08:49:56', NULL),
(671, 'Mr. Brannon Baumbach DDS', 'mhill@example.net', NULL, 'female', '660.820.3955', '1989-05-11', '2023-03-09 11:08:25', '2023-06-20 11:50:09', NULL),
(672, 'Omari Von', 'barney.simonis@example.org', NULL, 'female', '1-620-208-9555', '1996-03-20', '2022-09-28 06:25:34', '2023-05-25 08:00:22', NULL),
(673, 'Mrs. Kali Walker', 'qwest@example.org', NULL, 'male', '248-366-3411', '1999-01-20', '2022-12-05 08:20:19', '2023-06-28 22:21:33', NULL),
(674, 'Otha Lubowitz', 'efranecki@example.org', NULL, 'female', '+1.678.531.9789', '1994-08-09', '2022-09-24 01:48:24', '2023-07-29 22:24:43', NULL),
(675, 'Prof. Rachael Nader DDS', 'sanford.robert@example.com', NULL, 'female', '757-874-3050', '1998-12-23', '2022-10-14 19:19:02', '2023-06-21 20:55:48', NULL),
(676, 'Malvina Crist DDS', 'kaylah59@example.com', NULL, 'male', '1-984-699-8025', '1999-01-11', '2023-02-18 16:20:51', '2023-05-04 08:23:33', NULL),
(677, 'Dr. Alta Feeney', 'hrussel@example.net', NULL, 'male', '802.643.8158', '1991-10-25', '2022-11-14 19:34:45', '2023-08-05 08:15:43', NULL),
(678, 'Ms. Angelica Quigley DDS', 'orpha.dach@example.net', NULL, 'male', '1-470-733-8262', '1989-09-29', '2022-09-26 22:32:53', '2023-04-24 14:21:52', NULL),
(679, 'Prof. Kendrick Kunde', 'clarabelle47@example.com', NULL, 'male', '+1-260-993-2323', '1988-09-30', '2022-12-24 09:00:42', '2023-06-10 03:09:39', NULL),
(680, 'Mylene Watsica I', 'breana.macejkovic@example.net', NULL, 'male', '501-699-5912', '1998-08-09', '2023-02-01 07:38:18', '2023-05-30 21:02:55', NULL),
(681, 'Dr. Omari Wyman I', 'macejkovic.katlyn@example.net', NULL, 'female', '229-618-9543', '1998-01-13', '2023-02-25 11:21:21', '2023-08-02 11:16:58', NULL),
(682, 'Velma Kling', 'braun.jerald@example.org', NULL, 'female', '747.428.5490', '1989-12-17', '2022-12-25 08:41:04', '2023-07-04 13:57:07', NULL),
(683, 'Miss Rafaela Crona III', 'vernon73@example.com', NULL, 'male', '1-919-527-8294', '2001-11-18', '2022-12-23 11:25:27', '2023-08-09 21:06:09', NULL),
(684, 'Garrick Nader', 'bailey.vince@example.org', NULL, 'female', '540.657.1015', '2000-07-16', '2023-02-27 08:44:28', '2023-06-03 14:07:56', NULL),
(685, 'Ms. Vivianne Rodriguez DVM', 'judd84@example.com', NULL, 'female', '+1-283-278-6763', '1996-05-30', '2022-11-04 14:04:26', '2023-09-08 09:28:57', NULL),
(686, 'Prof. Eleonore Murazik', 'xgreenholt@example.org', NULL, 'female', '501-777-2382', '1991-04-12', '2023-03-14 03:49:20', '2023-04-18 09:37:11', NULL),
(687, 'Deven Ratke', 'scrona@example.net', NULL, 'female', '(820) 237-6504', '1997-08-05', '2022-11-12 17:04:48', '2023-05-28 09:51:40', NULL),
(688, 'Toney Braun', 'blanda.darrion@example.net', NULL, 'female', '1-970-718-7358', '1998-11-08', '2022-11-13 04:50:13', '2023-05-24 06:30:28', NULL),
(689, 'Guiseppe Maggio', 'maximillian58@example.com', NULL, 'female', '+1-720-473-3408', '1998-12-04', '2022-12-24 21:50:28', '2023-05-11 13:53:32', NULL),
(690, 'Meredith Bauch', 'francesco.carter@example.com', NULL, 'male', '+1-458-499-7145', '2002-03-03', '2023-02-12 16:09:56', '2023-08-02 17:52:14', NULL),
(691, 'Mrs. Lolita Gerlach I', 'broderick62@example.org', NULL, 'male', '747-699-2474', '1994-05-27', '2022-11-04 19:48:45', '2023-08-26 13:53:23', NULL),
(692, 'Dr. Wilburn Rowe MD', 'cole.mavis@example.net', NULL, 'male', '1-845-330-3530', '1992-07-15', '2022-12-02 10:27:23', '2023-08-25 00:45:28', NULL),
(693, 'Marlon Larkin', 'jswaniawski@example.com', NULL, 'male', '+16829621272', '2002-08-01', '2022-12-14 07:44:14', '2023-08-20 01:13:43', NULL),
(694, 'Luisa Little MD', 'jacobi.jamil@example.net', NULL, 'male', '858-710-9222', '1996-05-05', '2022-12-25 09:08:49', '2023-08-11 08:26:52', NULL),
(695, 'Dr. Garrison Botsford V', 'neva44@example.org', NULL, 'female', '458.673.9982', '2003-07-17', '2022-12-26 00:26:41', '2023-05-19 07:33:37', NULL),
(696, 'Adelbert Wunsch', 'breana.volkman@example.org', NULL, 'female', '(865) 592-3791', '2004-01-07', '2023-02-22 10:32:21', '2023-07-02 21:57:54', NULL),
(697, 'Jennie Hickle', 'yost.sister@example.net', NULL, 'male', '859-594-2705', '1993-08-19', '2022-11-14 10:59:43', '2023-05-26 02:55:59', NULL),
(698, 'Prof. Walker Murray', 'schmeler.boyd@example.net', NULL, 'female', '956.284.7312', '1989-06-13', '2022-10-20 12:33:39', '2023-06-29 15:34:04', NULL),
(699, 'Neha DuBuque', 'fcarter@example.org', NULL, 'male', '+1.843.220.6390', '2002-08-15', '2023-02-22 13:26:58', '2023-05-21 13:51:14', NULL),
(700, 'Joshua Murazik I', 'kuhic.leanna@example.com', NULL, 'female', '+1.440.474.5651', '1990-11-14', '2023-01-09 10:08:10', '2023-09-08 06:58:33', NULL),
(701, 'Miss Alta Barrows', 'wuckert.kayla@example.net', NULL, 'female', '1-757-895-0640', '1989-09-29', '2022-12-27 02:31:39', '2023-07-22 20:44:23', NULL),
(702, 'Josie Simonis I', 'ylubowitz@example.org', NULL, 'female', '+16516521314', '2002-04-28', '2022-09-18 01:53:40', '2023-07-29 05:19:02', NULL),
(703, 'Addison Farrell', 'kara.medhurst@example.net', NULL, 'female', '1-424-219-8071', '1993-10-09', '2023-03-13 23:00:40', '2023-04-24 23:35:25', NULL),
(704, 'Dr. Rudolph Murazik', 'little.garrett@example.net', NULL, 'male', '845-772-9432', '2002-04-15', '2022-10-26 10:24:45', '2023-06-15 05:47:34', NULL),
(705, 'Murray Leffler', 'lueilwitz.tracey@example.com', NULL, 'female', '+1.469.355.5058', '1993-05-28', '2022-11-26 20:11:20', '2023-06-24 14:57:21', NULL),
(706, 'Stephan Auer IV', 'ktreutel@example.com', NULL, 'male', '1-712-254-9043', '2001-12-14', '2023-03-01 18:21:54', '2023-08-28 16:56:33', NULL),
(707, 'Addison Langworth', 'ljacobs@example.com', NULL, 'female', '(337) 861-5094', '1996-03-26', '2022-09-30 17:59:06', '2023-07-02 16:10:53', NULL),
(708, 'Mafalda Champlin Sr.', 'raynor.kiara@example.net', NULL, 'female', '1-760-693-3518', '2004-01-27', '2022-12-07 18:28:53', '2023-05-14 12:20:05', NULL),
(709, 'Amanda Gutkowski MD', 'roosevelt.feeney@example.com', NULL, 'male', '203-602-8677', '1992-07-03', '2022-10-06 02:13:33', '2023-09-11 08:51:57', NULL),
(710, 'Mrs. Piper Stoltenberg', 'lowe.arjun@example.com', NULL, 'female', '+19474363897', '2004-07-14', '2022-09-26 10:35:52', '2023-05-11 23:41:28', NULL),
(711, 'Harmony Bartell', 'abe20@example.com', NULL, 'female', '980-299-3886', '2001-07-27', '2022-12-02 21:23:17', '2023-05-02 20:56:06', NULL),
(712, 'Freeda Wisozk', 'auer.kolby@example.org', NULL, 'female', '+1-364-439-2606', '1992-08-31', '2022-10-20 08:10:30', '2023-06-14 12:58:28', NULL),
(713, 'Price Batz', 'qzemlak@example.org', NULL, 'male', '+1.667.821.8040', '1993-02-22', '2022-12-13 04:40:28', '2023-06-03 11:31:09', NULL),
(714, 'America Zemlak IV', 'doug16@example.net', NULL, 'female', '1-872-712-8693', '1993-04-27', '2022-12-16 23:13:58', '2023-05-23 00:30:43', NULL),
(715, 'Dr. Nelda Witting', 'elouise.barton@example.org', NULL, 'male', '1-458-319-7885', '2004-08-08', '2023-01-10 16:57:19', '2023-08-26 02:13:46', NULL),
(716, 'Elroy Morar', 'kassandra80@example.net', NULL, 'female', '630-937-1999', '1996-03-24', '2023-01-17 19:20:21', '2023-06-14 05:22:24', NULL),
(717, 'Alexandra McDermott IV', 'shannon60@example.com', NULL, 'female', '1-858-826-0077', '2000-06-14', '2023-01-11 14:42:17', '2023-07-27 14:53:00', NULL),
(718, 'Dr. Arianna Bednar', 'carter.vallie@example.org', NULL, 'female', '+1-405-306-5779', '2001-06-27', '2022-09-23 16:02:56', '2023-04-25 13:24:58', NULL),
(719, 'Mr. Norberto Mosciski Sr.', 'reuben.mitchell@example.org', NULL, 'male', '760.601.1286', '1999-11-04', '2023-01-23 09:07:52', '2023-08-31 00:28:15', NULL),
(720, 'Jacquelyn Mohr', 'vicenta.brown@example.net', NULL, 'male', '(301) 722-1526', '2002-03-20', '2023-01-10 20:45:30', '2023-06-02 04:41:37', NULL),
(721, 'Ofelia Bosco', 'sdoyle@example.net', NULL, 'female', '551-283-8780', '1990-12-29', '2023-02-28 03:57:38', '2023-06-30 02:30:47', NULL),
(722, 'Roslyn Ortiz', 'uhintz@example.net', NULL, 'male', '908-436-9707', '1993-10-29', '2023-01-07 08:45:16', '2023-05-24 18:04:51', NULL),
(723, 'Darwin Jenkins', 'vkozey@example.net', NULL, 'male', '+1 (925) 558-4068', '1997-11-21', '2023-02-04 22:07:00', '2023-04-30 20:47:57', NULL),
(724, 'Dr. Xander Abernathy', 'morar.terrell@example.com', NULL, 'male', '+1.571.515.4612', '2005-05-19', '2022-12-04 00:25:12', '2023-06-24 18:26:19', NULL),
(725, 'Dulce Cassin', 'ransom17@example.net', NULL, 'male', '845.628.8176', '1994-07-26', '2023-02-11 18:11:50', '2023-05-05 20:09:47', NULL),
(726, 'Rudy King', 'rashawn10@example.net', NULL, 'male', '+1.726.248.7237', '2002-10-10', '2023-02-25 08:41:41', '2023-04-14 12:41:25', NULL),
(727, 'Alba Wiegand', 'kconnelly@example.org', NULL, 'female', '518-339-9724', '2005-07-31', '2022-11-20 01:47:32', '2023-07-07 23:38:01', NULL),
(728, 'Dr. Damon Graham Jr.', 'okutch@example.com', NULL, 'male', '+1.925.417.5534', '2004-05-25', '2023-03-03 19:37:51', '2023-06-18 05:59:54', NULL),
(729, 'Darrick Hirthe', 'travis.kunze@example.net', NULL, 'female', '702.280.5621', '1994-12-06', '2023-01-12 16:36:22', '2023-05-03 20:22:12', NULL),
(730, 'Ms. Elza Mitchell V', 'gottlieb.myriam@example.net', NULL, 'male', '423-846-3937', '1989-11-09', '2023-02-19 23:35:07', '2023-08-29 22:49:03', NULL),
(731, 'Betty Zieme V', 'shirley02@example.net', NULL, 'female', '+1-267-240-9729', '2001-12-26', '2022-11-12 10:28:27', '2023-06-21 14:07:53', NULL),
(732, 'Arnulfo Blick MD', 'cathryn.miller@example.net', NULL, 'female', '+1-424-838-7053', '1999-06-15', '2022-10-20 22:20:57', '2023-06-01 08:24:57', NULL),
(733, 'Ms. Therese Gibson', 'arlene21@example.com', NULL, 'female', '+1-541-440-3845', '1995-08-20', '2022-10-21 19:21:54', '2023-07-15 13:58:16', NULL),
(734, 'Prof. Drake Schmidt', 'tskiles@example.net', NULL, 'female', '320-866-2020', '1997-12-20', '2022-11-14 20:22:36', '2023-09-06 23:59:57', NULL),
(735, 'Rubie Schmidt V', 'emely55@example.com', NULL, 'female', '+1-231-401-9923', '2005-08-28', '2023-01-01 17:11:38', '2023-06-10 20:21:45', NULL),
(736, 'Molly Bosco', 'pete.treutel@example.org', NULL, 'female', '240-999-9369', '1990-02-24', '2023-02-15 13:52:24', '2023-05-09 21:35:35', NULL),
(737, 'Mr. Clement Ebert Sr.', 'emard.henriette@example.org', NULL, 'female', '971.683.0388', '1998-11-22', '2022-09-16 05:41:11', '2023-07-27 14:00:59', NULL),
(738, 'Vallie Larson', 'angelina75@example.com', NULL, 'male', '725.390.9992', '2001-07-30', '2023-03-06 09:59:52', '2023-05-31 01:51:23', NULL),
(739, 'Jarod Rogahn', 'odach@example.org', NULL, 'male', '+1-938-738-3549', '1994-09-21', '2023-02-08 16:28:06', '2023-04-23 04:41:38', NULL),
(740, 'Prof. Ambrose Reichert', 'zechariah07@example.org', NULL, 'male', '(575) 444-6815', '2003-05-23', '2022-12-31 11:46:49', '2023-05-02 04:04:01', NULL),
(741, 'Mrs. Marietta Skiles', 'alycia.schamberger@example.net', NULL, 'female', '+1-260-917-1246', '2005-04-15', '2023-01-15 22:16:57', '2023-07-11 15:02:03', NULL),
(742, 'Jacquelyn Fahey', 'jermain83@example.com', NULL, 'female', '(915) 836-7812', '2000-03-14', '2022-11-11 09:40:06', '2023-08-07 23:43:34', NULL),
(743, 'Kaya Doyle', 'emmitt.collins@example.com', NULL, 'male', '434-476-5060', '1992-06-05', '2023-01-19 09:48:33', '2023-06-21 16:21:59', NULL),
(744, 'Jonathan Keebler', 'scole@example.net', NULL, 'male', '1-743-323-1854', '1994-05-21', '2022-10-07 15:22:08', '2023-08-24 18:39:13', NULL),
(745, 'Brooke Smitham IV', 'cummerata.aubrey@example.com', NULL, 'male', '252.695.1940', '2003-08-21', '2022-09-15 20:18:06', '2023-08-17 07:02:25', NULL),
(746, 'Erich Schultz DVM', 'darrel70@example.org', NULL, 'male', '682-814-8570', '2003-11-07', '2022-11-20 17:27:15', '2023-04-14 12:46:28', NULL),
(747, 'Arnoldo Dickens MD', 'lou.hauck@example.net', NULL, 'female', '458-872-9255', '2002-06-03', '2022-10-12 23:57:56', '2023-08-25 22:57:24', NULL),
(748, 'Dr. Nelda Mitchell', 'yzieme@example.org', NULL, 'female', '+1-351-767-6174', '1999-04-06', '2023-02-23 05:53:35', '2023-06-14 17:46:52', NULL),
(749, 'Simeon Mann Jr.', 'jdaugherty@example.com', NULL, 'female', '+1-234-456-3634', '2002-08-29', '2022-11-08 04:31:42', '2023-05-17 14:38:51', NULL),
(750, 'Walker Bogisich', 'fdaugherty@example.com', NULL, 'male', '+1-610-624-3685', '2003-09-24', '2023-01-02 21:16:55', '2023-06-17 09:19:42', NULL),
(751, 'Ms. Berniece Dare III', 'johanna.leannon@example.org', NULL, 'male', '+1-507-231-1567', '1994-08-01', '2022-10-20 11:43:31', '2023-08-05 05:08:26', NULL),
(752, 'Karlee Hayes', 'tre.mayer@example.net', NULL, 'female', '(520) 530-2322', '1990-09-11', '2023-01-23 15:19:12', '2023-04-25 20:03:48', NULL),
(753, 'Jillian Walsh', 'edietrich@example.org', NULL, 'female', '260-252-7280', '1990-09-26', '2023-01-30 18:33:19', '2023-08-31 05:46:36', NULL),
(754, 'Bella D\'Amore', 'ywalter@example.org', NULL, 'male', '(321) 786-4262', '1996-10-31', '2022-12-01 03:06:03', '2023-08-27 12:44:52', NULL),
(755, 'Miss Ludie Herman', 'lucious.russel@example.net', NULL, 'female', '+1 (985) 456-2433', '1998-12-14', '2022-11-28 01:06:33', '2023-08-23 05:50:16', NULL),
(756, 'Miss Alice Ledner', 'nikolaus.caesar@example.net', NULL, 'male', '(682) 250-7280', '2003-05-04', '2022-10-05 22:53:33', '2023-05-11 01:27:38', NULL),
(757, 'Prof. Octavia Moen Sr.', 'aliza.labadie@example.org', NULL, 'male', '1-956-740-3017', '1990-12-29', '2023-02-15 18:21:29', '2023-05-04 15:41:15', NULL),
(758, 'Carson Lang', 'cconn@example.net', NULL, 'male', '(404) 566-3594', '2002-01-14', '2023-03-05 15:23:06', '2023-06-24 08:29:33', NULL),
(759, 'Cielo Hauck V', 'tthiel@example.net', NULL, 'male', '1-863-246-7129', '1998-08-07', '2023-02-28 22:54:29', '2023-05-01 00:31:57', NULL),
(760, 'Edgardo Murphy', 'wkunde@example.net', NULL, 'male', '209.669.9391', '1997-03-19', '2022-11-07 16:42:49', '2023-07-22 13:44:22', NULL),
(761, 'Mr. Ike Bailey', 'toni91@example.com', NULL, 'female', '614.735.7728', '1999-01-26', '2022-09-21 14:54:32', '2023-08-04 02:41:27', NULL),
(762, 'Shakira Treutel MD', 'cstehr@example.org', NULL, 'male', '+17312770654', '2004-06-09', '2022-11-23 01:25:29', '2023-05-08 06:59:00', NULL),
(763, 'Prof. Erica Bergnaum IV', 'adams.mabel@example.org', NULL, 'female', '323-923-8263', '2001-04-17', '2023-01-06 13:59:46', '2023-06-24 07:30:52', NULL),
(764, 'Valentine Metz', 'stiedemann.francesco@example.com', NULL, 'male', '603-443-7813', '1996-04-27', '2022-10-27 02:47:30', '2023-06-27 03:11:09', NULL),
(765, 'Hazle White', 'xander77@example.org', NULL, 'female', '1-717-273-1594', '1992-09-18', '2022-12-01 09:39:08', '2023-05-09 02:59:51', NULL),
(766, 'Dovie Franecki', 'erica34@example.org', NULL, 'male', '(864) 623-7888', '1989-11-23', '2022-10-27 13:59:04', '2023-05-15 22:17:34', NULL),
(767, 'Alvina Mann', 'wblanda@example.org', NULL, 'male', '+1 (386) 369-1254', '1992-07-19', '2022-11-20 22:21:58', '2023-06-13 23:13:09', NULL),
(768, 'Prince Schoen', 'strosin.ruthe@example.net', NULL, 'female', '+13108958237', '1992-03-04', '2023-02-07 20:16:43', '2023-06-16 18:32:01', NULL),
(769, 'Yazmin Gaylord', 'savanah71@example.com', NULL, 'male', '+1.386.326.3852', '1990-05-11', '2023-01-07 22:12:08', '2023-08-27 00:38:04', NULL),
(770, 'Miss Mina Mills', 'adolfo.kohler@example.com', NULL, 'female', '364.727.0475', '1989-02-15', '2022-10-04 15:26:24', '2023-06-16 13:46:41', NULL),
(771, 'Liam Quitzon', 'orlando47@example.com', NULL, 'male', '+1 (650) 456-4998', '1999-07-23', '2023-01-10 12:55:38', '2023-05-25 12:26:16', NULL),
(772, 'Krystina Rutherford', 'ida17@example.org', NULL, 'female', '+1.269.580.3735', '1998-11-15', '2023-01-19 13:31:00', '2023-07-22 17:01:20', NULL),
(773, 'Ms. Bella Ledner Sr.', 'grace.schuster@example.com', NULL, 'male', '+13122917516', '1994-12-31', '2022-12-15 02:19:04', '2023-07-08 00:48:51', NULL),
(774, 'Mr. Zackery Lowe', 'stuart71@example.com', NULL, 'male', '1-603-890-8772', '2002-11-24', '2023-01-23 18:30:08', '2023-09-10 16:30:49', NULL),
(775, 'Iva Rutherford IV', 'jhill@example.net', NULL, 'female', '+1.805.660.8215', '1998-03-20', '2022-12-09 10:23:48', '2023-07-31 18:07:31', NULL),
(776, 'Amelia Denesik', 'qhowell@example.com', NULL, 'female', '224-323-3140', '2004-06-29', '2022-11-29 09:01:35', '2023-09-03 04:05:39', NULL),
(777, 'Lizzie Leannon III', 'cleo.gutkowski@example.org', NULL, 'male', '434.423.6842', '1990-03-29', '2023-01-02 19:42:11', '2023-08-24 18:17:36', NULL),
(778, 'Ned Yost PhD', 'dejah.shanahan@example.com', NULL, 'male', '1-240-803-3784', '1990-04-24', '2023-02-25 04:34:21', '2023-08-23 07:27:29', NULL),
(779, 'Ms. Pansy Collins', 'hturcotte@example.com', NULL, 'male', '+1-854-616-5314', '1995-10-17', '2023-03-08 12:10:39', '2023-05-18 02:26:59', NULL),
(780, 'Malika McGlynn DDS', 'ydavis@example.net', NULL, 'male', '(640) 888-5353', '2000-02-24', '2022-09-18 11:37:01', '2023-06-12 05:38:13', NULL),
(781, 'Dejon Von', 'jkerluke@example.net', NULL, 'male', '773-303-9035', '1998-07-24', '2022-12-15 15:06:25', '2023-08-21 01:29:42', NULL),
(782, 'Antwan Marks', 'mraz.johnpaul@example.net', NULL, 'female', '+1 (541) 375-7626', '2001-11-11', '2023-02-22 23:44:30', '2023-06-21 02:30:39', NULL),
(783, 'Hallie Yost IV', 'hallie.bechtelar@example.com', NULL, 'male', '463-826-9192', '1992-05-09', '2023-02-12 15:12:29', '2023-09-05 23:25:00', NULL),
(784, 'Dr. Osvaldo Nicolas V', 'daniela03@example.net', NULL, 'female', '+1 (463) 404-0168', '1990-10-30', '2022-10-30 02:34:19', '2023-04-27 17:19:35', NULL),
(785, 'Anibal Weimann', 'dorthy16@example.org', NULL, 'female', '803-902-3120', '2001-12-22', '2022-09-16 03:23:25', '2023-08-23 17:44:36', NULL),
(786, 'Damien Turner DVM', 'cassandre31@example.org', NULL, 'male', '+1 (585) 746-6325', '1996-09-02', '2022-12-09 09:50:45', '2023-08-25 02:19:26', NULL),
(787, 'Aglae Romaguera IV', 'medhurst.joanie@example.org', NULL, 'female', '+1-386-433-7778', '1991-09-17', '2023-02-12 07:49:29', '2023-05-11 17:07:44', NULL),
(788, 'Prof. Lee Rohan PhD', 'blanda.joannie@example.com', NULL, 'male', '1-417-271-3757', '1993-05-18', '2022-10-12 12:07:05', '2023-05-25 10:09:50', NULL),
(789, 'Dewitt Larson', 'twila36@example.org', NULL, 'female', '(640) 954-5445', '2004-04-05', '2023-02-04 01:06:21', '2023-06-30 12:07:35', NULL),
(790, 'Rashad Bailey', 'willms.gaylord@example.org', NULL, 'male', '906.380.8071', '2002-11-30', '2022-10-30 14:12:29', '2023-06-11 23:02:24', NULL),
(791, 'Ramiro Marks', 'ecruickshank@example.net', NULL, 'female', '+1.209.595.0889', '2002-10-27', '2022-11-28 05:07:34', '2023-06-09 17:54:11', NULL),
(792, 'Evert Feil', 'maymie34@example.org', NULL, 'female', '(769) 203-1586', '2002-06-11', '2023-01-12 20:49:19', '2023-06-08 08:15:38', NULL),
(793, 'Zula Hyatt', 'ben.hand@example.org', NULL, 'male', '+1 (361) 222-3033', '1992-02-16', '2022-09-15 15:11:13', '2023-05-25 11:26:44', NULL),
(794, 'Miss Roxanne Labadie II', 'paula.hamill@example.net', NULL, 'male', '+1.724.352.3535', '1995-09-08', '2022-10-12 10:55:51', '2023-05-14 11:18:34', NULL),
(795, 'Onie Mills', 'irma18@example.net', NULL, 'male', '(480) 767-3316', '1997-04-08', '2022-09-23 02:10:18', '2023-05-05 00:16:17', NULL),
(796, 'Jadyn Leffler', 'ida17@example.net', NULL, 'male', '617.638.7181', '1998-06-05', '2022-12-03 16:12:06', '2023-07-11 11:54:31', NULL),
(797, 'Lexie Hermann', 'sporer.eldora@example.org', NULL, 'male', '1-463-752-9586', '1991-12-29', '2022-10-12 03:26:55', '2023-06-28 04:42:34', NULL),
(798, 'Mr. Deonte Koelpin', 'raphaelle55@example.com', NULL, 'male', '(281) 694-4171', '2004-11-23', '2023-03-07 13:46:50', '2023-05-24 04:19:00', NULL),
(799, 'Camryn Bashirian', 'ukemmer@example.com', NULL, 'male', '(810) 756-2441', '2003-04-18', '2022-11-16 11:53:39', '2023-06-26 07:37:34', NULL),
(800, 'Prof. Tyree Hegmann', 'henderson.stoltenberg@example.net', NULL, 'female', '1-731-469-7933', '1992-05-18', '2022-12-11 23:30:06', '2023-08-25 02:49:13', NULL),
(801, 'Randal Cassin', 'zhermiston@example.org', NULL, 'male', '+13645401193', '1997-12-09', '2022-11-15 10:01:05', '2023-08-27 14:34:24', NULL),
(802, 'Branson Ledner', 'aida.rath@example.org', NULL, 'female', '(920) 455-8298', '1994-07-25', '2023-01-17 06:43:37', '2023-08-18 07:39:41', NULL),
(803, 'Marion Wuckert PhD', 'zieme.gaylord@example.net', NULL, 'female', '318-647-1298', '2001-11-15', '2023-02-04 03:47:37', '2023-07-15 05:59:53', NULL),
(804, 'Prof. Bradford Rempel Sr.', 'nikolaus.devan@example.net', NULL, 'male', '1-484-420-8613', '1997-06-25', '2022-10-22 19:43:37', '2023-07-09 16:12:07', NULL),
(805, 'Clifton O\'Kon', 'marilie.rohan@example.net', NULL, 'female', '434.784.5433', '1992-03-25', '2023-01-22 01:49:39', '2023-06-01 19:42:40', NULL),
(806, 'Torey Hoppe DVM', 'adenesik@example.com', NULL, 'male', '1-678-735-6558', '1993-02-03', '2022-12-29 15:03:21', '2023-05-26 21:41:41', NULL),
(807, 'Estel Witting', 'iledner@example.com', NULL, 'male', '+19546171502', '2002-04-02', '2023-02-07 03:01:06', '2023-05-25 18:48:59', NULL),
(808, 'Alexander Green III', 'travis.schmeler@example.com', NULL, 'male', '(920) 203-7242', '1995-08-20', '2023-02-23 14:55:06', '2023-06-18 17:41:01', NULL),
(809, 'Camila Carter III', 'xaufderhar@example.net', NULL, 'male', '(831) 516-5951', '1989-12-05', '2022-12-20 06:38:09', '2023-07-22 22:33:49', NULL),
(810, 'Raoul Corkery', 'kmcglynn@example.org', NULL, 'female', '(858) 965-1561', '1998-04-12', '2023-03-03 23:16:21', '2023-07-05 08:28:43', NULL),
(811, 'Nakia Bradtke', 'lottie67@example.net', NULL, 'female', '341-606-9362', '1991-07-07', '2023-02-21 18:56:05', '2023-06-04 14:22:18', NULL),
(812, 'Alice Labadie', 'murray.laury@example.net', NULL, 'male', '1-985-827-0568', '2003-02-22', '2023-01-09 19:06:10', '2023-08-02 01:43:56', NULL),
(813, 'Shaniya Kemmer', 'jamir.runolfsdottir@example.net', NULL, 'female', '(332) 889-8882', '1996-10-02', '2023-03-06 02:16:56', '2023-04-24 19:14:41', NULL),
(814, 'Theodora Kuphal', 'mann.lesley@example.com', NULL, 'male', '+1-408-568-6748', '1999-06-08', '2023-02-16 09:09:35', '2023-04-14 23:46:46', NULL),
(815, 'Mya Schneider V', 'lowe.eddie@example.org', NULL, 'male', '+1 (442) 947-1062', '1988-10-18', '2022-12-26 17:54:29', '2023-07-07 15:54:23', NULL),
(816, 'Arielle Bergnaum', 'garfield67@example.com', NULL, 'female', '+15517065076', '1996-10-07', '2023-01-27 15:47:36', '2023-04-27 03:08:30', NULL),
(817, 'Janae Upton', 'witting.ahmed@example.org', NULL, 'female', '689-930-8550', '2002-05-15', '2022-12-03 23:34:47', '2023-06-21 08:18:44', NULL),
(818, 'Carole Marks', 'ymckenzie@example.com', NULL, 'male', '938.408.6522', '1996-11-25', '2022-10-17 01:53:27', '2023-07-09 16:04:46', NULL),
(819, 'Dr. Athena McGlynn', 'ramona31@example.net', NULL, 'male', '+19597031600', '2003-09-25', '2023-01-22 05:31:21', '2023-09-11 11:43:51', NULL),
(820, 'Keara Nicolas', 'laury.gerlach@example.org', NULL, 'female', '+1-321-662-6335', '1989-01-25', '2022-11-05 22:06:58', '2023-07-17 05:05:57', NULL),
(821, 'Prof. Dereck Steuber', 'kraig.konopelski@example.org', NULL, 'male', '(231) 758-9716', '2001-09-08', '2022-12-20 05:28:39', '2023-05-21 16:33:21', NULL),
(822, 'Rhiannon Nolan II', 'gleason.electa@example.net', NULL, 'female', '(838) 567-1066', '1989-07-19', '2022-12-04 19:23:13', '2023-05-03 11:11:16', NULL),
(823, 'Ephraim Wehner', 'zmedhurst@example.org', NULL, 'female', '1-571-734-3014', '1992-05-08', '2022-10-05 06:44:52', '2023-06-24 15:04:37', NULL),
(824, 'Theron Upton', 'ffritsch@example.net', NULL, 'female', '(351) 372-8014', '1995-06-27', '2023-01-21 09:46:12', '2023-05-31 18:19:30', NULL),
(825, 'Asia Fadel', 'ezemlak@example.org', NULL, 'male', '+1-937-261-0939', '2005-08-01', '2022-09-26 07:39:43', '2023-06-08 00:05:38', NULL),
(826, 'Helen Denesik', 'merl.oconner@example.org', NULL, 'male', '+1-234-358-5223', '2003-04-30', '2023-01-10 15:25:20', '2023-04-30 11:42:14', NULL),
(827, 'Ms. Jade Mann II', 'cristal.ankunding@example.net', NULL, 'male', '+1-831-864-4104', '2004-08-04', '2022-11-06 05:29:50', '2023-04-14 08:29:13', NULL),
(828, 'Mrs. Jacynthe Bauch', 'elisha.halvorson@example.net', NULL, 'female', '+1-234-792-2886', '1997-03-15', '2022-11-21 20:01:16', '2023-08-23 09:59:18', NULL),
(829, 'Ulises Huel', 'mariam.veum@example.com', NULL, 'female', '(224) 816-7269', '1998-10-15', '2023-01-16 06:46:48', '2023-08-18 00:13:39', NULL),
(830, 'Zack Terry', 'krystal39@example.com', NULL, 'female', '+18037072126', '2000-03-20', '2022-11-18 16:15:45', '2023-09-05 14:23:30', NULL),
(831, 'Dakota Pagac', 'eric06@example.net', NULL, 'male', '1-769-327-9869', '2005-02-12', '2022-11-01 17:12:41', '2023-05-11 19:34:01', NULL),
(832, 'Fanny Shields', 'lue.lebsack@example.org', NULL, 'male', '(276) 557-6497', '1994-07-10', '2022-10-10 15:28:34', '2023-09-02 00:53:54', NULL),
(833, 'Zack Ward', 'baby08@example.com', NULL, 'male', '+13512365500', '1992-02-04', '2022-11-27 16:29:12', '2023-05-07 02:21:56', NULL),
(834, 'Perry Considine', 'brandon91@example.org', NULL, 'female', '+1.872.867.1638', '1998-02-12', '2023-02-14 10:42:49', '2023-08-09 01:59:37', NULL),
(835, 'Mr. Tate Adams', 'vfeil@example.net', NULL, 'female', '+1.856.872.8272', '2005-05-30', '2022-10-16 10:37:05', '2023-05-07 10:02:34', NULL),
(836, 'Elta Mitchell', 'tromp.hailee@example.net', NULL, 'male', '310-218-7980', '1995-12-03', '2022-12-15 22:58:55', '2023-04-28 06:29:40', NULL),
(837, 'Marques Mertz', 'rachelle.hammes@example.net', NULL, 'female', '+1 (631) 514-0154', '1996-02-26', '2023-02-19 20:54:43', '2023-07-18 10:41:02', NULL),
(838, 'Ms. Aleen Pagac PhD', 'alexanne72@example.net', NULL, 'male', '+17247379014', '2002-07-21', '2023-02-22 11:29:41', '2023-06-06 16:40:43', NULL),
(839, 'May Mayert', 'sanford.maximilian@example.net', NULL, 'female', '279.290.2894', '1999-10-17', '2022-12-27 10:34:10', '2023-06-19 08:14:20', NULL),
(840, 'Jonathon Feil', 'leffler.arch@example.com', NULL, 'female', '+1-929-912-6141', '1996-09-25', '2022-12-01 01:46:26', '2023-09-12 19:23:52', NULL),
(841, 'Lamont Kris', 'uokuneva@example.com', NULL, 'female', '+1 (602) 224-1840', '1993-02-18', '2023-02-22 05:04:00', '2023-04-29 02:50:26', NULL),
(842, 'Audrey Raynor DDS', 'hartmann.ashleigh@example.com', NULL, 'female', '+14632705178', '1996-07-02', '2022-11-25 00:54:32', '2023-08-08 18:53:38', NULL),
(843, 'Lamar Mueller I', 'lewis.hettinger@example.com', NULL, 'female', '+1.828.645.4225', '2000-06-22', '2022-10-26 18:04:25', '2023-05-29 00:52:14', NULL),
(844, 'Kendall Bins', 'dave.mante@example.net', NULL, 'male', '+1-813-673-6888', '1991-08-20', '2023-02-28 08:30:33', '2023-08-05 00:51:27', NULL),
(845, 'Ima Jast', 'catharine52@example.org', NULL, 'male', '680.212.1158', '1992-07-07', '2022-11-01 09:59:46', '2023-04-21 03:49:41', NULL),
(846, 'Edgar Predovic II', 'earnestine53@example.com', NULL, 'female', '+13419562102', '1990-04-22', '2023-01-22 15:04:30', '2023-08-22 20:37:09', NULL),
(847, 'Filiberto Koepp II', 'shields.onie@example.com', NULL, 'female', '1-612-365-7960', '1999-10-10', '2022-11-29 04:15:04', '2023-08-02 03:47:06', NULL),
(848, 'Prof. Deja Lockman', 'amalia14@example.net', NULL, 'male', '(650) 278-5504', '1999-12-06', '2022-11-07 10:02:08', '2023-09-05 14:26:27', NULL),
(849, 'Ciara Quitzon', 'pabshire@example.com', NULL, 'female', '(254) 458-0140', '2000-07-24', '2023-02-10 19:28:28', '2023-05-16 06:21:05', NULL),
(850, 'Mazie Hermiston', 'pzieme@example.com', NULL, 'male', '+1-606-734-1706', '2004-07-14', '2022-11-28 19:42:18', '2023-07-16 21:34:14', NULL),
(851, 'Kellen Balistreri PhD', 'emelie48@example.org', NULL, 'male', '1-737-633-2256', '1992-11-16', '2023-02-08 10:54:59', '2023-05-03 04:59:13', NULL),
(852, 'Dr. Floyd Schmeler II', 'cathy.rowe@example.com', NULL, 'male', '878-669-2316', '1998-05-03', '2023-01-10 21:10:28', '2023-06-02 05:39:56', NULL),
(853, 'Meta Prosacco', 'corwin.liam@example.net', NULL, 'male', '(585) 723-2997', '2003-08-06', '2022-11-06 10:12:03', '2023-05-16 23:11:15', NULL),
(854, 'Alysson Metz', 'adietrich@example.org', NULL, 'female', '+19377212754', '1990-12-02', '2022-12-07 14:01:59', '2023-07-01 18:47:19', NULL),
(855, 'Maybell Hane', 'harvey.newton@example.org', NULL, 'female', '+12024065743', '1993-04-23', '2022-11-07 09:41:54', '2023-05-05 01:41:41', NULL),
(856, 'Margarete Streich', 'bradly.reichel@example.com', NULL, 'female', '918-358-8551', '1990-08-21', '2022-11-03 16:02:19', '2023-05-21 11:32:39', NULL),
(857, 'Berniece Zemlak', 'wade.jacobi@example.org', NULL, 'male', '+1-386-388-4100', '1990-10-28', '2022-11-25 10:05:46', '2023-07-17 13:27:18', NULL),
(858, 'Mr. Laurel Gerhold MD', 'awest@example.com', NULL, 'female', '+1-660-809-7837', '1995-07-23', '2022-10-15 15:18:38', '2023-07-19 17:02:28', NULL),
(859, 'Aida Davis', 'lenora.lindgren@example.com', NULL, 'male', '+1.629.481.3567', '1997-01-12', '2022-11-10 02:46:04', '2023-05-22 20:09:54', NULL),
(860, 'Prof. Cleveland Bauch I', 'ohara.ocie@example.net', NULL, 'male', '+1-863-893-6480', '1997-02-02', '2023-01-25 00:22:40', '2023-07-26 01:10:03', NULL),
(861, 'Gilberto Bogan', 'ibogisich@example.net', NULL, 'male', '(430) 935-2683', '1993-10-03', '2022-12-15 14:16:18', '2023-06-09 22:45:33', NULL),
(862, 'Prof. Earl Stroman I', 'theresa.gislason@example.com', NULL, 'male', '+1 (316) 453-1277', '1992-12-24', '2023-02-20 23:10:54', '2023-08-10 14:32:53', NULL),
(863, 'Rachelle Murphy', 'vruecker@example.org', NULL, 'female', '1-202-214-7983', '1993-03-13', '2022-11-23 05:23:28', '2023-08-15 22:36:58', NULL),
(864, 'Dr. Cielo Roob IV', 'kaia31@example.com', NULL, 'female', '+18595530471', '1995-12-18', '2022-09-25 13:06:08', '2023-08-20 17:38:34', NULL),
(865, 'Mrs. Rebekah Bailey', 'moore.marilie@example.net', NULL, 'male', '1-651-625-5414', '1998-02-11', '2022-09-30 10:21:26', '2023-05-16 12:49:26', NULL),
(866, 'Mrs. Ofelia Johnson', 'kenneth39@example.com', NULL, 'male', '(248) 694-8495', '1997-06-08', '2023-02-06 14:54:05', '2023-08-11 06:45:35', NULL),
(867, 'Dr. Ludwig Hickle', 'naomi11@example.org', NULL, 'male', '856.515.5146', '1998-11-29', '2023-02-12 07:22:00', '2023-09-07 17:50:00', NULL),
(868, 'Joshuah Tremblay MD', 'bleuschke@example.org', NULL, 'female', '+1-518-647-0646', '1989-11-17', '2022-12-15 14:34:02', '2023-06-22 14:30:22', NULL),
(869, 'Tavares Mohr PhD', 'ucorkery@example.com', NULL, 'male', '1-812-803-7231', '2001-08-29', '2022-11-13 02:52:03', '2023-06-08 06:20:26', NULL),
(870, 'Gail Pollich V', 'javon98@example.com', NULL, 'male', '+1 (929) 765-4205', '1991-01-27', '2022-11-02 11:35:13', '2023-08-07 05:18:22', NULL),
(871, 'Prof. Terence Oberbrunner IV', 'karley06@example.net', NULL, 'female', '+1-986-249-6185', '2002-12-14', '2022-12-27 03:12:24', '2023-08-21 17:25:11', NULL),
(872, 'Amparo Pfeffer DDS', 'brendon.witting@example.com', NULL, 'male', '(770) 972-1731', '1999-06-30', '2023-02-21 19:11:52', '2023-09-09 21:00:52', NULL),
(873, 'Randy Armstrong', 'bergnaum.bernardo@example.org', NULL, 'female', '+1-205-521-1306', '1993-01-10', '2023-01-01 22:30:21', '2023-05-08 16:38:14', NULL),
(874, 'Ana Jacobson', 'jaren37@example.org', NULL, 'male', '626-459-4998', '1996-01-08', '2022-10-15 07:23:03', '2023-09-05 08:58:16', NULL),
(875, 'Esteban Schaefer', 'yost.lilyan@example.net', NULL, 'male', '+17125318861', '2003-05-04', '2022-09-23 13:14:00', '2023-05-24 22:22:26', NULL),
(876, 'Burnice Pollich DVM', 'wintheiser.palma@example.com', NULL, 'female', '337-441-9178', '1990-11-05', '2023-01-19 00:20:58', '2023-04-23 04:38:36', NULL),
(877, 'Prof. Giovanna Batz', 'rashawn.barton@example.org', NULL, 'male', '1-352-877-3737', '1994-09-20', '2022-11-01 20:42:53', '2023-08-26 05:33:01', NULL),
(878, 'Marjory Lind', 'amcglynn@example.com', NULL, 'male', '(740) 980-5719', '2000-01-17', '2022-12-20 20:55:31', '2023-05-20 14:27:29', NULL),
(879, 'Mr. Maximus Bauch MD', 'makenzie.collins@example.net', NULL, 'male', '+1-651-482-7466', '2001-12-09', '2023-01-08 03:40:08', '2023-06-08 11:06:42', NULL),
(880, 'Amani Bartoletti', 'xswift@example.com', NULL, 'male', '+1-985-865-9240', '2004-01-24', '2022-09-14 09:59:58', '2023-05-26 21:09:33', NULL),
(881, 'Dr. Vallie Wolf', 'velva.kling@example.com', NULL, 'female', '+14232325228', '2001-02-28', '2022-11-19 13:03:28', '2023-05-08 11:13:02', NULL),
(882, 'Ebba Baumbach', 'manley.abernathy@example.com', NULL, 'female', '1-502-633-4439', '1990-10-07', '2023-02-27 09:50:48', '2023-05-12 16:57:45', NULL),
(883, 'Tate O\'Hara', 'gust69@example.net', NULL, 'male', '+1.570.367.6377', '2000-05-02', '2022-12-08 18:24:20', '2023-04-28 12:38:55', NULL),
(884, 'Bessie Kertzmann', 'sadie.strosin@example.com', NULL, 'female', '+1.770.607.8177', '1994-09-14', '2023-01-12 11:10:26', '2023-05-24 23:13:31', NULL),
(885, 'Miss Clementine Bayer PhD', 'haskell.cremin@example.org', NULL, 'male', '1-913-949-0289', '1990-06-24', '2022-09-27 11:05:21', '2023-05-30 13:39:04', NULL),
(886, 'Dr. Rosalee Rodriguez V', 'tyson.fay@example.net', NULL, 'male', '+1-820-806-4362', '1993-09-29', '2022-12-04 00:28:04', '2023-08-02 02:43:38', NULL),
(887, 'Courtney Schaden', 'skiles.claudie@example.com', NULL, 'female', '1-463-687-6619', '1994-02-12', '2023-03-12 14:35:41', '2023-06-10 16:33:05', NULL),
(888, 'Humberto Renner MD', 'shaina.kuvalis@example.com', NULL, 'male', '+1.480.672.9767', '1994-08-10', '2022-11-26 14:06:19', '2023-05-17 02:19:23', NULL),
(889, 'Henri Schumm', 'rodriguez.eloise@example.net', NULL, 'female', '1-228-925-0998', '1990-09-01', '2023-03-11 00:43:04', '2023-07-03 18:26:45', NULL),
(890, 'Nakia Schuppe', 'emie.heidenreich@example.org', NULL, 'female', '+1.534.793.9086', '1997-11-07', '2022-10-07 09:21:53', '2023-04-17 16:14:05', NULL),
(891, 'Jennyfer Fritsch', 'gus.bogan@example.net', NULL, 'male', '+1-540-672-4923', '1995-06-21', '2023-03-02 14:15:43', '2023-04-28 19:15:02', NULL),
(892, 'Prof. Sylvia Beer MD', 'lebsack.madison@example.net', NULL, 'female', '224.238.1740', '1991-01-22', '2023-01-05 12:42:41', '2023-08-19 04:08:08', NULL),
(893, 'Jonathon Bechtelar', 'shania15@example.org', NULL, 'female', '+1 (725) 612-0358', '1996-04-06', '2022-11-09 07:29:55', '2023-09-02 20:36:50', NULL),
(894, 'Baron Ortiz Jr.', 'marcelino67@example.org', NULL, 'female', '929-534-4242', '1992-04-28', '2023-01-22 11:42:11', '2023-07-23 03:25:23', NULL),
(895, 'Prof. Layne Bartell', 'gillian.ullrich@example.org', NULL, 'female', '+1-941-690-9838', '1993-02-27', '2022-10-20 10:47:20', '2023-06-24 03:37:15', NULL),
(896, 'Vincenzo Olson', 'edooley@example.com', NULL, 'female', '1-979-968-6235', '1995-05-20', '2022-10-17 21:56:36', '2023-06-14 15:53:18', NULL),
(897, 'Deangelo Lueilwitz', 'monserrat78@example.net', NULL, 'female', '1-909-879-1175', '1989-10-16', '2022-11-09 18:42:49', '2023-07-16 03:39:58', NULL),
(898, 'Daren Hartmann', 'nitzsche.juanita@example.org', NULL, 'female', '720.279.3635', '1993-10-15', '2022-11-22 11:04:25', '2023-06-25 20:45:04', NULL),
(899, 'Walton Herzog', 'kassulke.augustus@example.org', NULL, 'male', '+16513563803', '1995-01-25', '2023-02-15 23:53:59', '2023-04-26 19:35:35', NULL),
(900, 'Jo Flatley', 'badams@example.org', NULL, 'male', '1-551-891-2996', '2001-07-17', '2022-12-17 01:47:18', '2023-06-27 05:04:07', NULL),
(901, 'Ephraim Willms Jr.', 'agoldner@example.org', NULL, 'male', '+1-540-327-9921', '2002-08-18', '2022-10-12 07:33:20', '2023-04-28 19:01:56', NULL),
(902, 'Ottis Fritsch', 'padberg.ruth@example.com', NULL, 'male', '364-572-2415', '2003-01-20', '2022-11-15 13:14:36', '2023-08-04 23:22:33', NULL),
(903, 'Jaeden Lind', 'marjory18@example.net', NULL, 'female', '251-481-5661', '2001-07-23', '2022-09-23 02:36:05', '2023-07-02 02:56:04', NULL),
(904, 'Lacy Von', 'rosanna45@example.net', NULL, 'male', '+1-701-421-2456', '2002-02-25', '2022-09-22 17:32:49', '2023-07-06 17:57:37', NULL),
(905, 'Hillard Cremin', 'wluettgen@example.com', NULL, 'male', '1-662-769-0066', '2002-11-23', '2023-02-23 16:32:59', '2023-07-13 07:29:04', NULL),
(906, 'Kevin Carroll', 'jovan.bins@example.org', NULL, 'female', '(361) 881-3281', '2003-11-29', '2022-10-05 03:40:57', '2023-06-08 05:15:31', NULL),
(907, 'Soledad Cole', 'golson@example.com', NULL, 'male', '209.205.5429', '1999-01-11', '2022-12-11 21:09:21', '2023-08-01 07:05:30', NULL),
(908, 'Dr. Kane Bernier DVM', 'west.rylee@example.com', NULL, 'female', '1-240-519-0126', '1994-11-18', '2022-12-27 19:13:07', '2023-08-09 23:42:15', NULL),
(909, 'Dr. Brianne Koch', 'brigitte.satterfield@example.com', NULL, 'male', '+18588248995', '2000-04-11', '2022-10-18 13:04:29', '2023-08-29 09:42:30', NULL),
(910, 'Justina Ortiz', 'yvette55@example.org', NULL, 'female', '351-458-1277', '1991-05-01', '2022-11-25 00:05:35', '2023-07-09 19:57:48', NULL),
(911, 'Madyson Anderson PhD', 'tyree79@example.org', NULL, 'female', '+1-415-593-6844', '1990-07-07', '2022-11-26 10:11:58', '2023-07-23 15:44:20', NULL),
(912, 'Mr. Presley Effertz', 'arielle.veum@example.com', NULL, 'female', '1-443-745-8572', '1989-01-09', '2022-12-19 08:41:33', '2023-09-10 07:05:05', NULL),
(913, 'Dr. Nicholaus Rosenbaum DDS', 'idare@example.org', NULL, 'male', '754.410.4248', '1995-07-05', '2023-03-08 11:58:55', '2023-04-16 07:54:06', NULL),
(914, 'Roxanne Doyle', 'satterfield.emerson@example.org', NULL, 'male', '+15206404588', '2002-04-18', '2022-12-27 00:39:45', '2023-08-25 08:05:44', NULL),
(915, 'Prof. Jalon Green Sr.', 'vzulauf@example.net', NULL, 'female', '423.592.1600', '2002-03-05', '2022-10-09 03:49:37', '2023-09-08 23:36:21', NULL),
(916, 'Lexus Denesik', 'torphy.katlyn@example.com', NULL, 'female', '(678) 580-8216', '1992-05-23', '2022-10-30 19:47:32', '2023-06-27 17:58:11', NULL),
(917, 'Madison King', 'jeremy89@example.com', NULL, 'male', '858-371-7525', '2003-02-24', '2022-12-14 07:17:21', '2023-04-19 22:45:10', NULL),
(918, 'Prof. Dane Toy IV', 'amaya98@example.org', NULL, 'male', '1-575-997-0081', '1997-11-26', '2022-11-02 14:14:41', '2023-09-11 20:21:40', NULL),
(919, 'Jazmin Mann II', 'luigi00@example.com', NULL, 'female', '+15598219481', '1992-11-18', '2022-11-08 05:25:35', '2023-08-20 07:25:17', NULL),
(920, 'Buford Hills', 'cielo.grady@example.org', NULL, 'male', '878.956.9958', '2002-02-11', '2023-02-18 00:51:56', '2023-06-08 07:32:48', NULL),
(921, 'Zelma Heidenreich', 'esta.hammes@example.com', NULL, 'male', '+1.503.263.1174', '1995-09-13', '2023-01-07 01:00:18', '2023-06-30 22:04:28', NULL),
(922, 'Mrs. Trycia Rogahn Sr.', 'hermiston.bryana@example.net', NULL, 'female', '401.964.7439', '1993-12-24', '2023-03-02 16:38:25', '2023-04-23 14:05:18', NULL),
(923, 'Elaina Walker DDS', 'ljohnson@example.com', NULL, 'female', '1-260-258-6545', '1989-04-01', '2023-02-14 03:19:41', '2023-07-31 17:49:03', NULL),
(924, 'Sharon Daniel', 'west.payton@example.org', NULL, 'male', '947-457-8894', '1989-09-20', '2022-11-03 13:03:14', '2023-09-04 04:11:11', NULL),
(925, 'Waldo Hill', 'eleazar30@example.net', NULL, 'female', '+14586894012', '2000-09-10', '2023-01-21 08:42:56', '2023-06-30 21:25:13', NULL),
(926, 'Evie Pfannerstill', 'patience25@example.com', NULL, 'male', '726-674-2330', '1995-05-16', '2022-12-24 20:10:23', '2023-04-27 22:03:09', NULL),
(927, 'Riley Legros', 'frida74@example.org', NULL, 'female', '+13512130028', '2003-08-12', '2023-03-07 06:46:04', '2023-07-11 00:19:34', NULL),
(928, 'Mrs. Kiara Wehner', 'mireya94@example.org', NULL, 'male', '(325) 955-6177', '2001-04-06', '2022-10-15 05:39:20', '2023-07-20 07:53:42', NULL),
(929, 'Mrs. Kasey Turcotte V', 'luella70@example.com', NULL, 'female', '702.774.9578', '1989-06-12', '2022-12-14 22:45:28', '2023-05-16 11:43:48', NULL),
(930, 'Ms. Retha Jacobson', 'jerrold29@example.org', NULL, 'female', '1-272-466-6893', '1998-09-28', '2023-01-15 11:57:08', '2023-07-05 08:07:19', NULL),
(931, 'Phyllis Reichert II', 'block.luther@example.net', NULL, 'male', '361.780.0559', '1995-11-04', '2022-09-18 04:35:58', '2023-07-07 00:05:57', NULL),
(932, 'Etha Nikolaus I', 'kris.columbus@example.net', NULL, 'male', '930-849-9468', '2003-06-23', '2023-03-14 03:51:37', '2023-07-29 08:24:17', NULL),
(933, 'Miss Alivia Glover II', 'cremin.heidi@example.org', NULL, 'male', '(859) 753-7571', '1998-11-14', '2023-01-31 05:54:57', '2023-07-31 19:12:17', NULL),
(934, 'Michele Windler', 'ullrich.blanche@example.net', NULL, 'female', '(385) 685-8798', '2002-02-20', '2022-12-27 08:03:32', '2023-07-13 22:26:07', NULL),
(935, 'Prof. Adrianna Armstrong', 'jdonnelly@example.com', NULL, 'male', '847-226-8794', '1988-12-21', '2022-11-26 06:03:52', '2023-07-21 07:08:06', NULL),
(936, 'Jeffrey Lubowitz', 'georgianna.bernier@example.org', NULL, 'female', '+1-352-624-7797', '1999-06-01', '2022-12-29 18:51:53', '2023-09-03 13:08:20', NULL),
(937, 'Prof. Jaydon Romaguera', 'kozey.dallin@example.com', NULL, 'female', '1-820-264-2119', '2002-02-22', '2023-02-06 21:18:10', '2023-06-25 04:01:10', NULL),
(938, 'Kenton Erdman', 'tod50@example.org', NULL, 'female', '1-984-436-9037', '1998-10-23', '2022-12-23 09:11:20', '2023-07-06 00:48:17', NULL),
(939, 'Larry Walker', 'stanton.oma@example.net', NULL, 'male', '562.751.8210', '2002-11-27', '2022-12-27 00:31:35', '2023-07-13 20:07:35', NULL),
(940, 'Gianni Cartwright', 'herman.halie@example.org', NULL, 'female', '1-386-665-6139', '1991-01-06', '2022-12-06 06:11:29', '2023-05-25 07:03:41', NULL),
(941, 'Mrs. Magdalen Mayert', 'collier.chelsea@example.net', NULL, 'male', '714-473-2513', '1994-04-30', '2022-11-03 18:45:42', '2023-07-11 16:53:52', NULL),
(942, 'Prof. Willy Pfannerstill', 'qdamore@example.net', NULL, 'female', '+16168620821', '2005-08-26', '2022-11-01 07:28:58', '2023-08-05 23:02:23', NULL),
(943, 'Queen Lockman', 'pboyle@example.org', NULL, 'male', '+1-360-267-6134', '1995-07-05', '2023-01-22 19:00:08', '2023-07-02 02:24:50', NULL),
(944, 'Phoebe Price', 'bernard.ritchie@example.org', NULL, 'female', '303.272.7506', '1994-09-02', '2022-10-28 19:32:03', '2023-04-28 19:32:56', NULL),
(945, 'Dr. Yolanda Windler', 'vreichel@example.com', NULL, 'female', '+19204377282', '1997-01-14', '2022-12-07 05:55:01', '2023-04-28 22:36:07', NULL),
(946, 'Daphney Steuber', 'bruen.wade@example.net', NULL, 'male', '+1 (678) 681-6585', '1996-09-21', '2023-02-14 06:10:16', '2023-05-27 18:06:30', NULL),
(947, 'Mr. Talon Langworth III', 'mccullough.earnest@example.net', NULL, 'female', '+1.479.955.2121', '1996-08-03', '2022-11-20 14:23:39', '2023-08-14 20:39:10', NULL),
(948, 'Ms. Tiara Shanahan', 'freeda.russel@example.net', NULL, 'female', '765.705.7096', '1989-07-13', '2022-12-30 14:38:16', '2023-06-03 09:14:27', NULL),
(949, 'Clotilde Schiller', 'emmet.hamill@example.com', NULL, 'male', '272.608.1153', '1988-09-26', '2023-02-08 12:17:56', '2023-05-11 19:40:24', NULL),
(950, 'Jakayla Hansen', 'reinger.brigitte@example.org', NULL, 'female', '(281) 546-1471', '2005-01-30', '2022-12-11 19:42:50', '2023-06-01 21:54:15', NULL),
(951, 'Dr. Kaylah Luettgen', 'mikel93@example.com', NULL, 'female', '838-314-1728', '2005-02-08', '2023-03-03 17:30:28', '2023-09-02 14:25:53', NULL),
(952, 'Tevin Green Sr.', 'ruth.wilderman@example.net', NULL, 'male', '(689) 200-6564', '1991-09-02', '2023-02-05 09:57:43', '2023-06-04 17:28:59', NULL),
(953, 'Prof. Terry Tillman', 'enoch36@example.org', NULL, 'female', '1-848-586-8689', '2002-11-29', '2022-09-22 04:54:34', '2023-09-09 14:57:40', NULL),
(954, 'Kenton Roob', 'fkassulke@example.net', NULL, 'female', '1-718-716-0634', '2001-11-29', '2022-09-24 00:26:05', '2023-09-09 13:29:13', NULL),
(955, 'Dianna Sauer', 'cary.howell@example.net', NULL, 'male', '+16783622079', '1989-05-29', '2022-10-31 17:18:09', '2023-07-06 11:02:25', NULL),
(956, 'Kelsi Reichert', 'alivia21@example.net', NULL, 'male', '1-484-837-4334', '1995-04-26', '2022-10-09 17:04:49', '2023-05-08 14:12:27', NULL),
(957, 'Caleb Toy', 'izieme@example.net', NULL, 'male', '1-331-419-5618', '1998-11-30', '2022-09-28 09:21:52', '2023-07-07 21:53:16', NULL),
(958, 'Regan Boyle', 'telly.walker@example.com', NULL, 'male', '(475) 268-4782', '1989-12-05', '2022-09-26 05:47:29', '2023-06-05 20:30:54', NULL),
(959, 'Norwood Pollich DVM', 'mhoppe@example.org', NULL, 'female', '704.913.2373', '1996-01-31', '2022-10-14 10:22:38', '2023-06-09 12:08:08', NULL),
(960, 'Freida Hoeger', 'tremblay.justyn@example.com', NULL, 'male', '951-814-7069', '2000-04-24', '2023-01-09 22:23:40', '2023-08-08 21:34:50', NULL),
(961, 'Alisa Dooley', 'loraine49@example.org', NULL, 'male', '1-828-272-3898', '2004-09-04', '2023-02-27 08:40:41', '2023-07-28 08:39:41', NULL),
(962, 'Marcel Fritsch', 'lexie.franecki@example.net', NULL, 'male', '(623) 657-6542', '1991-09-01', '2022-12-01 04:56:49', '2023-07-27 14:05:42', NULL),
(963, 'Kristofer Prosacco', 'hjenkins@example.net', NULL, 'female', '+1-650-847-8746', '1990-11-30', '2022-12-01 06:07:03', '2023-07-28 08:39:35', NULL),
(964, 'Efren Boyer', 'josiane.feest@example.net', NULL, 'male', '1-847-814-7433', '1991-09-06', '2023-02-03 19:04:00', '2023-04-20 17:26:49', NULL),
(965, 'Logan Schulist', 'leanne76@example.org', NULL, 'female', '754.964.7990', '1992-05-26', '2022-09-21 14:40:45', '2023-05-11 00:00:53', NULL),
(966, 'Leopoldo Ryan DVM', 'xleffler@example.net', NULL, 'female', '+1 (949) 506-4803', '1992-05-08', '2022-11-07 18:31:03', '2023-06-03 18:54:09', NULL),
(967, 'Constance Hessel', 'kyler.mayert@example.org', NULL, 'male', '(734) 738-5584', '1997-03-30', '2022-11-06 07:23:40', '2023-09-01 09:45:53', NULL),
(968, 'Carlie Keebler', 'sbraun@example.org', NULL, 'male', '(785) 334-5041', '1990-11-10', '2022-09-17 13:38:11', '2023-05-24 08:20:19', NULL),
(969, 'Dr. Emelia Heaney', 'waelchi.kathryne@example.net', NULL, 'female', '1-469-239-3148', '2001-12-03', '2023-02-11 20:29:50', '2023-04-17 08:12:10', NULL),
(970, 'Miss Angelina Mante II', 'melba.rath@example.com', NULL, 'female', '1-573-796-8966', '1991-01-29', '2022-10-05 07:07:27', '2023-04-17 00:05:40', NULL),
(971, 'Prof. Benny Hickle V', 'torphy.sydnee@example.org', NULL, 'female', '+1-337-901-1012', '1997-07-27', '2022-11-27 04:06:38', '2023-08-29 10:48:05', NULL),
(972, 'Prof. Magdalen Pouros IV', 'gleichner.braulio@example.com', NULL, 'female', '+13469555778', '2000-09-11', '2023-01-28 01:16:50', '2023-05-25 12:47:24', NULL),
(973, 'Effie Beahan', 'cathryn61@example.org', NULL, 'male', '+1 (458) 251-8178', '2004-03-05', '2023-01-31 03:04:40', '2023-05-25 03:50:14', NULL),
(974, 'Mr. Marcel Kemmer V', 'ferne69@example.com', NULL, 'male', '912.557.5581', '2002-07-16', '2023-01-21 16:03:55', '2023-07-26 16:46:45', NULL),
(975, 'Ms. Madalyn Osinski', 'nichole.feest@example.com', NULL, 'female', '(914) 397-1894', '1995-02-05', '2022-11-09 06:36:10', '2023-06-25 04:25:32', NULL),
(976, 'Mckenna Carroll', 'lcassin@example.com', NULL, 'female', '+1.551.298.8682', '2005-04-12', '2023-01-28 22:01:16', '2023-06-28 23:52:18', NULL),
(977, 'Rolando Schowalter', 'ola95@example.org', NULL, 'male', '+12602411690', '1991-04-09', '2023-03-04 01:02:09', '2023-06-14 11:27:19', NULL),
(978, 'Lottie Borer', 'beatrice.gutmann@example.net', NULL, 'male', '1-512-610-3282', '1994-08-02', '2022-12-12 19:48:59', '2023-07-10 06:45:49', NULL),
(979, 'Delphine Dare', 'ed82@example.org', NULL, 'male', '+1 (820) 886-5327', '1990-08-27', '2022-12-24 06:21:37', '2023-06-19 15:27:41', NULL),
(980, 'Green Pagac', 'teresa93@example.com', NULL, 'female', '805.613.8181', '1990-08-05', '2022-11-19 10:08:15', '2023-05-10 02:23:10', NULL),
(981, 'Marlon Bauch', 'noemy.anderson@example.com', NULL, 'female', '1-785-372-4948', '2001-04-13', '2022-10-27 04:12:39', '2023-05-13 03:24:05', NULL),
(982, 'Prof. Warren Kohler', 'margie81@example.org', NULL, 'female', '1-386-744-6847', '1999-10-12', '2023-02-26 07:18:14', '2023-09-05 15:08:24', NULL),
(983, 'Derick Schuppe', 'camilla.heller@example.com', NULL, 'female', '(989) 963-5982', '1990-04-11', '2022-10-10 10:07:16', '2023-05-03 13:59:53', NULL),
(984, 'Lina Littel', 'holly35@example.com', NULL, 'male', '1-228-997-6538', '2002-08-23', '2022-11-27 21:58:07', '2023-04-25 11:21:26', NULL),
(985, 'Reagan Emmerich', 'candice08@example.org', NULL, 'female', '409.997.5179', '2005-03-09', '2022-12-07 04:31:32', '2023-08-09 14:00:13', NULL),
(986, 'Miss Maudie Cronin III', 'xcummings@example.org', NULL, 'female', '+1.870.762.8332', '1988-10-06', '2022-11-27 07:24:50', '2023-08-15 01:08:19', NULL),
(987, 'Dr. Malinda Hahn IV', 'jett62@example.net', NULL, 'female', '(617) 787-8130', '1992-03-14', '2022-10-05 04:06:58', '2023-08-16 20:53:11', NULL),
(988, 'Adrienne Rutherford III', 'francisca14@example.com', NULL, 'female', '(321) 440-4651', '1998-10-11', '2023-01-25 13:04:55', '2023-06-04 02:38:55', NULL),
(989, 'Dr. Coby Hane', 'chahn@example.com', NULL, 'female', '1-951-778-5949', '2000-08-03', '2022-12-10 12:26:38', '2023-05-29 17:29:30', NULL),
(990, 'Lucious Rath', 'dach.kacey@example.org', NULL, 'female', '(207) 752-9025', '1991-06-20', '2023-01-31 08:47:34', '2023-07-07 02:55:11', NULL),
(991, 'Daija Harber', 'kiara74@example.com', NULL, 'male', '1-212-941-0931', '2002-04-06', '2023-01-27 09:35:32', '2023-05-21 14:57:57', NULL),
(992, 'Dr. Denis McKenzie Jr.', 'kirlin.leann@example.net', NULL, 'male', '+1 (231) 631-1467', '1995-04-09', '2022-12-25 00:09:31', '2023-07-21 18:46:23', NULL),
(993, 'Helena Casper', 'charley.collier@example.org', NULL, 'female', '(220) 424-0716', '2001-03-30', '2022-10-15 19:14:27', '2023-05-20 04:57:33', NULL),
(994, 'Prof. Ernest O\'Hara V', 'macejkovic.amanda@example.org', NULL, 'female', '(740) 322-7793', '1996-07-27', '2023-01-08 01:14:26', '2023-05-17 00:20:12', NULL),
(995, 'Clinton Moen', 'zlang@example.com', NULL, 'female', '(678) 707-0574', '2001-10-13', '2022-10-04 21:05:38', '2023-07-21 00:30:02', NULL),
(996, 'Annie Lindgren', 'smitham.bella@example.com', NULL, 'female', '928-319-0706', '1995-10-31', '2023-01-10 23:21:18', '2023-07-27 01:03:32', NULL);
INSERT INTO `shop_customers` (`id`, `name`, `email`, `photo`, `gender`, `phone`, `birthday`, `created_at`, `updated_at`, `deleted_at`) VALUES
(997, 'Ruthie McClure MD', 'kenya.mante@example.net', NULL, 'male', '1-918-340-8090', '1999-03-13', '2022-11-20 16:00:58', '2023-05-29 00:11:22', NULL),
(998, 'Alexander Kreiger', 'labadie.jazmin@example.com', NULL, 'male', '1-530-928-9475', '1997-11-30', '2022-12-27 16:05:05', '2023-08-27 12:47:37', NULL),
(999, 'Carlee Adams', 'rae90@example.com', NULL, 'female', '1-813-304-4567', '1991-06-23', '2022-12-09 11:45:12', '2023-07-08 06:03:19', NULL),
(1000, 'Ila Lang', 'wsauer@example.org', NULL, 'female', '806-799-9554', '1999-12-23', '2023-02-04 19:18:24', '2023-05-15 19:55:49', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `subscribers`
--

CREATE TABLE `subscribers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0:Deactive, 1:Active',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `subscribers`
--

INSERT INTO `subscribers` (`id`, `email`, `status`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'codermat@gmail.com', 1, NULL, '2023-09-21 09:05:48', '2023-09-21 09:05:48'),
(2, 'subhasdh@gmail.com', 0, NULL, '2024-01-17 02:22:53', '2024-01-17 02:22:53');

-- --------------------------------------------------------

--
-- Table structure for table `testimonials`
--

CREATE TABLE `testimonials` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1 COMMENT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `testimonials`
--

INSERT INTO `testimonials` (`id`, `title`, `description`, `name`, `designation`, `image`, `status`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'Ride with The Bike Tribe', 'It was so amazing going to Sanjayvan Park, Qutub Minar with The Bike Tribe. Had an amazing trip and even the cycles were so comfortable to ride. We enjoyed a beautiful sunset as well as nature.', 'John', 'Friends', 'uJAlK1CIyku2232Iramq7jiMfQwgVC-metaNC5wbmc=-.png', 1, NULL, '2023-11-26 23:03:29', '2023-11-26 23:05:15'),
(2, 'WAY above and beyond a food tour!', 'We did the Old Delhi heritage food tour. For a six-hour day tour, this is a very deep dive! We sampled delicious street food from five or six different vendors, visited a sihk temple, took some local transit, and more. Joe did an amazing job as a guide, contributing lots of insight, stories, history, context, and fun! He even helped us navigate the metro to get back to the airport. I 💯 recommend this tour!', 'Madhumallika', 'Tourist', 'X8jBOMxQgSTM9HsMPmZESw2y3x8YBQ-metaNS5wbmc=-.png', 1, NULL, '2023-11-26 23:04:06', '2023-11-26 23:05:35'),
(8, 'tester ', 'asdsad', 'jack ', 'friend', NULL, 1, '2024-01-16 02:39:48', '2024-01-16 02:04:38', '2024-01-16 02:39:48'),
(9, 'test ', 'this is a discription ', 'image test ', 'friends ', NULL, 1, '2024-01-16 02:39:46', '2024-01-16 02:27:18', '2024-01-16 02:39:46'),
(10, 'radha ', 'ssms ', 'bls ', 'friend ', NULL, 1, '2024-01-16 02:43:38', '2024-01-16 02:40:26', '2024-01-16 02:43:38'),
(11, 'radha ', 'ssms ', 'bls ', 'friend', NULL, 1, '2024-01-16 02:43:35', '2024-01-16 02:41:32', '2024-01-16 02:43:35'),
(12, 'ravi ', 'it is soo good ', 'amir ', 'friend', NULL, 1, NULL, '2024-01-16 02:44:12', '2024-01-16 02:44:12'),
(13, 'sunmm', 'stars', 'moon', 'friends ', NULL, 1, NULL, '2024-01-16 02:47:50', '2024-01-16 05:53:59');

-- --------------------------------------------------------

--
-- Table structure for table `tours`
--

CREATE TABLE `tours` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tour_category_id` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_tag_keywords` varchar(255) DEFAULT NULL,
  `meta_tag_descriptions` varchar(255) DEFAULT NULL,
  `short_description` varchar(255) DEFAULT NULL,
  `featured_image` varchar(255) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `tour_code` varchar(255) DEFAULT NULL,
  `destinations` varchar(1000) DEFAULT NULL,
  `tour_duration` varchar(255) DEFAULT NULL,
  `itineraries` longtext DEFAULT NULL,
  `included` longtext DEFAULT NULL,
  `excluded` longtext DEFAULT NULL,
  `extra_features` longtext DEFAULT NULL,
  `start_price` decimal(10,2) DEFAULT NULL,
  `tour_type` tinyint(1) DEFAULT 1 COMMENT '1: Single Day Tour, 2: Multi Day Tour',
  `status` tinyint(1) DEFAULT 1 COMMENT '0',
  `published_at` date DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tours`
--

INSERT INTO `tours` (`id`, `tour_category_id`, `title`, `slug`, `meta_title`, `meta_tag_keywords`, `meta_tag_descriptions`, `short_description`, `featured_image`, `description`, `tour_code`, `destinations`, `tour_duration`, `itineraries`, `included`, `excluded`, `extra_features`, `start_price`, `tour_type`, `status`, `published_at`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 1, 'Jaipur Tours', 'Jaipur Tours', 'Jaipur Tours', 'Jaipur Tours', 'Jaipur Tours', 'Jaipur Tours', 'v8JWxrkbeOLJo4osB3DGaurGdDU8sF-metaNS5wbmc=-.png', 'Jaipur Tours', '111', NULL, NULL, 'Jaipur Tours Itineraries', NULL, NULL, NULL, 5000.00, 0, 1, NULL, NULL, '2023-09-26 11:08:26', '2023-10-24 17:11:43'),
(2, 2, 'Rajasthan Tours', 'rajasthan-tours', 'Rajasthan Tours', NULL, 'Rajasthan Tours', NULL, 'tOSOUShHEJgC1OFHRJOU3kNTfJdNTd-metaNS5wbmc=-.png', 'Rajasthan Tours', 'RT001', NULL, '5 Days 6 Nights', '#staritinerary##title#Day 1 : Udaipur Arrival | Local Sightseeing#endtitle##desc#Arrive in Udaipur, check into the hotel followed by a briefing session by the trip captain.\n* Afterward, we\'ll head for a local sightseeing tour where we\'d visit The City Palace which is a testament to the grandeur of Rajasthan with its flamboyant architectural style and panoramic views of the entire city. We\'ll also visit Sajjangarh Fort which is also known as Monsoon Palace and is a unique, one-of-a-kind palatial residence situated on a hilltop.\n* As Udaipur is abode to many beautiful lakes, we\'ll visit the most prominent one in our sightseeing tour which is Lake Pichola. It is an artificial freshwater lake dating back to the 13th century.\n* In the evening, we will head back to our hotel. Dinner followed by an overnight stay in Udaipur.#enddesc##staritinerary##title#Day 2 : Drive from Udaipur to Jodhpur via Kumbhalgarh Fort. (250 Kilometers, 5 Hours)#endtitle#\n#desc#1. After early morning breakfast, we\'ll check out of our hotel and head towards Jodhpur which is renowned as the Blue City owning to the color that almost the entire city is draped in.\n2. En route, we\'ll visit the Kumbhalgarh Fort also known as The Great Wall of India as the fortress is the second longest continuous wall in the world after the Great Wall of China. It is also among the largest fort complexes in the World and was declared a UNESCO World Heritage Site.\n3. We will also visit the Maharana Pratap Museum in Haldighati which was built to commemorate the Mewari Rana and his battle with the Mughals. The museum has many artifacts displayed that will take you back in history.\n4. Upon our arrival in Jodhpur, we\'ll check in at our hotel. Dinner followed by an overnight stay in Jodhpur. \n#enddesc#', 'Rajasthan Tours', 'Rajasthan Tours', NULL, 25000.00, 1, 1, NULL, NULL, '2023-10-24 17:34:06', '2023-10-25 23:32:46'),
(3, 5, 'Delhi Bicycle Tour', 'delhi-bicycle-tour', 'Delhi Bicycle Tour', 'Delhi Bicycle Tour', 'Delhi Bicycle Tour', NULL, 'hMbkvD0zb6HBmgADlNe6o4N0LwCwqG-metaamFtYW1hc2ppZC1iLmpwZw==-.jpg', 'Looking for a unique way to explore Delhi? Consider taking a bicycle tour! On this guided bike ride through the city, you\'ll get to see all of the landmarks and attractions up close. You\'ll be able to take in the sights and sounds of India\'s capital while getting some exercise at the same time. Join us on an unforgettable cycling journey around Delhi – book your spot today!', 'DBT01', NULL, '10', 'Delhi is a vibrant city, full of culture and history. From the majestic Red Fort to the tranquil gardens of Lodhi, there are plenty of sights to explore in this bustling metropolis. In this article, we\'ll take you on an unforgettable tour of some of Delhi\'s most iconic landmarks and attractions - from must-see monuments to hidden gems that will give you an insight into India\'s fascinating past. So get ready for your journey through one of Asia\'s oldest cities!\n', '- Pickup and Drop \n- Guided Tour of Bicycle\n- Rent Included\n- Bottles Water', '- Monuments Entrance Fee\n- Camera fee\n- Any meal', NULL, 2500.00, 1, 1, NULL, NULL, '2023-10-24 17:37:43', '2023-10-25 21:23:27'),
(4, 5, 'Classic Old Delhi - Cycle Tour', 'classic-old-delhi-cycle-tour', 'Classic Old Delhi - Cycle Tour', 'Classic Old Delhi - Cycle Tour', 'Classic Old Delhi - Cycle Tour', NULL, 'weKSapAZ4XST90qZDlvc26kcR3dkMP-metaNi5wbmc=-.png', 'The Old Delhi Cycling Adventure is a ride that will guide you beneath Delhi’s brilliant displays. Experience Delhi in the wee hours of the morning with the Bike Tribe!\nOne of the first images that pop up in one’s head when they think of India is a web of innumerable narrow alleyways, crowded streets jam-packed with people, tangled overhead wires, and an assortment of shops but still finding space for 17th century-old grand architectural marvels amidst this beautiful chaos. Yes, it’s India’s very own version of Harry Potter’s boggling Diagon Alley situated right in its capital Delhi- OLD DELHI! \n\nThe Old Delhi Cycling Adventure is a ride that will guide you beneath Delhi’s brilliant displays. Experience Delhi in the wee hours of the morning with the Bike Tribe!\nOne of the first images that pop up in one’s head when they think of India is a web of innumerable narrow alleyways, crowded streets jam-packed with people, tangled overhead wires, and an assortment of shops but still finding space for 17th century-old grand architectural marvels amidst this beautiful chaos. Yes, it’s India’s very own version of Harry Potter’s boggling Diagon Alley situated right in its capital Delhi- OLD DELHI! \n*Step1\n\n\n', 'COD-CT01', NULL, '8', 'Meet your tour guide at the Red Fort parking lot at 6.30 am. He will equip you with a suitable bike and a helmet. The tour will go at a leisurely pace with plenty of time to stop for photographs, so don’t forget your camera! \nBrace yourselves for a bumpy and adventurous ride as we travel back in time and traverse through ancient galis (lanes) and kuchas (bylanes) of the 7th ancient city of Delhi, the capital of the Great Mughal Emperor Shah Jahan. Back in 17th CE Old Delhi was known as Shahjahanabad and was one of the most prosperous cities in the world.\nYour cycle tour starts through Chandni Chowk where you begin by observing the magnificence of the Jain temple and Hindu temple. Feast your eyes on intricate jewelry as you weave your way through the Dariba Kalan road – famous for renowned jewelry in silver and gold. Your path will then bring you to the famous Kinari Bazar which is famous for wedding collections, pooja items, bandhanwar, door hanging, exclusive diyas & other products. Visit the magnificent marvel which is the world-famous Jama Mosque built by Emperor Shah Jahan, the man behind building the iconic Taj Mahal.\nEnjoy a fresh cup of masala tea paired with hot samosas. After a short tea break, we move towards Matia Mahal - a street inside the walled city that never sleeps. Enjoy authentic Mughal cuisine outside Jama Masjid and Urdu Bazar. \nLater, you will reach the center of the market and enter the magnificent Dharampura Haveli that echoes a distinctive blend of historic grandeur and contemporary comfort. As your guide leads you on, you can admire the unique and iconic architecture of famous Havelis dwarfing their neighbors against the skyline of Chandni Chowk. \nWe also visit the famous Sis Gunj gurudwara (Sikh temple) and soak in an environment of praise and worship and visit their community kitchen for an incredible experience of life and culture. \nSurrender yourself to the soothing aroma of spices as the tour takes you through Ballimaran to Khari Baoli, Asia’s largest wholesale spice market. Get acquainted with the origin of the world’s best spices by learning more about their history. \nFor the final leg of your tour, we come back to the Red Fort parking lot by around 1:00 pm. Here you will bid goodbye to the cycle tour guide and take back memories of a lifetime.\n\n', '* Meals - 1 Breakfast \n* Filtered Water and Refreshments (if Support Vehicle is Included)\n* Team Leader/ Tour Guide\n* Bike/ Cycle Technician\n* Basic First Aid\n\n', '* Any kind of Beverages\n* Emergency evacuations\n* Break down/ Repair expenses\n* Any Private Expenses\n* Room Service Fees\n', NULL, 5000.00, 1, 1, NULL, NULL, '2023-11-08 19:01:07', '2023-11-21 21:21:03'),
(5, 2, 'Brahmaputra River Cruise and Cycle', 'brahmaputra-river-cruise-and-cycle', 'Brahmaputra River Cruise and Cycle', 'Brahmaputra River Cruise and Cycle', 'Brahmaputra River Cruise and Cycle', NULL, 'itKtRfuygqyrrYXYigzJ8Ta6cRd1Gt-metaYnJobXN0b3VyMDEuanBn-.jpg', 'Unwind and slowdown in the state of wonder called Assam, the touchdown at the relatively untouched Northeast India, with this week-long Bike & River Cruise Tour! Discover Assam on land and water: Sail through the mighty Brahmaputra, one of India\'s biggest and most significant rivers. This mighty river is also known as the Red River, as the soil of this region is naturally rich in iron content, bringing the colour red to the river. \n\nCycle through tea plantations, stay on the world’s largest river island, explore tribal villages, city roads, traditional temples, unique biodiversity, world-renowned wildlife sanctuaries and the impeccable culture, cuisine and heritage all in a single state! If you are searching for a tour with a relaxed pace, this is your calling. So come with us and let’s pause this moment for a while, embrace everything around and take it all in. Get in on the fun and hop onto this Assamese Adventure!\n', 'BRC-TR01', 'Guwahati - Xapura - Singri - Silghat - Kaziranga - Majuli - Depart from Jorhat', '9 Nights / 10 Days', '#staritinerary##title#Day 01: Arrival in Guwahati #endtitle#\n#desc# Arrive in Guwahati, the capital city of Assam and the gateway to the Northeast. Your tour leader will greet you at 6 pm. The day is free for you to explore Guwahati or let us know, and we will arrange a day tour in Guwahati, covering all the important places.\n* <strong>Cycling distance:</strong> None\n* Overnight stay in Guwahati\n* <strong>Optional activities:</strong> \nGuwahati half-day sightseeing Tour\n#enddesc#\n##staritinerary##title#Day 02: Day 2: Guwahati to Xapura (Via Pobitora wildlife sanctuary)#endtitle#\n#desc# After breakfast in the hotel, we would be transferred to Uzan Bazaar Ghat and check in at our adventure boat for the first sail of the trip! We’ll be moving towards Govardhan Ghat in an upstream sail pattern. After about two hours, we anchor the boat and start our riding/ cycling towards Pobitora Wildlife Sanctuary which is home to the highest density of the state animal in the world – the great One-Horned Rhino. We will go off-road and cross paddy fields, mustard fields, and tribal villages. Once we hit a concrete road, get ready to spot more rhinos in the peaceful sanctuary of Pobitora, which offers better rhino sightings! Afterwards, we would move towards Maibong Eco Resort for lunch and tea. After tea, we would ride back to Sonoka Village and start sailing as time permits.\nDinner and Overnight stay near Xapura sandbank or houseboat.\n* <strong>Cycling Distance:</strong> 35 km \n#enddesc#\n##staritinerary##title#Day 03: Full day Sail from Xapura to Singri #endtitle#\n#desc#1. Experience the vastness of the mighty Brahmaputra as we cruise through in peace and tranquillity, from Xapura to Singri. Engage in bird watching with profuse birdlife, enjoy lunch on board, witness a phenomenon unique to Northeast India – the sun sets earlier than the rest of the country and it’s breathtaking. \nAlso, keep an eye out for river dolphins- you might spot one if you are lucky! Upon reaching Singri sandbank, we would get a glimpse of the riverside lifestyle: farmers working hard on cultivation lands growing different varieties of vegetables for the mainland and the big cities!\n* <strong>Cycling Distance:</strong> None\n* Overnight stay near Singri sandbank \n#enddesc#\n##staritinerary##title#Day 04: Full day ride from Singri to Silghat #endtitle#\n#desc#1. Post breakfast, gear up for a full day of cycling! Today we will be crossing city roads and big highways which would not be too busy with hardly any traffic as we ride towards Tezpur. One of the most important commercial towns of Assam, steeped in history and mythology. Apart from the scenic beauty discover Tezpur through its old monuments, tea estates, archaeological sites, and it’s ancient relics. Tezpur is known as the cultural capital of Assam because of its rich tradition of music, arts and cinema and also because it is the birthplace of the founder of Assamese cinema! After lunch in the town, we would move towards Silghat, our destination for the day, by crossing one of the longest bridges of Brahmaputra.\n* <strong>Cycling Distance:</strong> 45 km \n* Overnight stay in Silghat.\n#enddesc#\n##staritinerary##title#Day 5: Silghat to Kaziranga (Safari day) #endtitle#\n#desc#1. Gear up for Safari Day! Post breakfast, we would move towards one of the most impressive must-visit places Assam prides itself over, the UNESCO World Heritage Site, Kaziranga National Park. One of India’s most diverse forest areas, Kaziranga is popularly known for the majestic Great One Horned Rhinoceros. However, it is not just about visiting the rhinos; it’s much more than that. Being a part of Brahmpatura’s marshlands, it boasts of a stunning ecosystem. Whether you are a birding enthusiast, a wildlife lover, wilderness explorer, Kaziranga has it all. It is also home to the Big Five: The One-Horned Rhinoceros, Royal Bengal Tiger, Asian Elephant, Wild Water Buffalo and Swamp Deer. Even if you cannot spot any wildlife, a safari through Kaziranga is an out of the world experience, as it’s a very well preserved and maintained national park with wetlands, green lands and other terrains. It is unlike the regular crowded forest trails of India. After an exhilarating safari experience, we have an overnight stay and dinner at a beautiful resort.\n* <strong>Cycling Distance:</strong> None\n* Overnight stay in a resort at Kaziranga National Park.\n#enddesc#\n##staritinerary##title#Day 06: Exploring Kaziranga\n #endtitle#\n#desc#1. Morning cycle ride around Villages and tea gardens in the buffer area, exploring local villages and tea gardens and trying our luck to spot more wildlife, post-lunch free for optional activities! Your Tour Leader will offer you some exciting optional activities.\n* <strong>Cycling Distance:</strong> 35 km\n* Overnight stay in a resort at Kaziranga National Park.\n#enddesc#\n##staritinerary##title#Day 07: Kaziranga to Majuli\n #endtitle#\n#desc#1. Brace yourselves for a long day full of exciting adventures! Post breakfast, we drive out of Kaziranga towards The Negheriting Temple (Doul) which is dedicated to Lord Shiva. The actual temple is dated 8th - 9th A.D (Pre Ahom), built by the Kacharis. The present form of the temple was constructed under the reign of Ahom king Swargadeo Rajeswar Singha (1751-1769) and the latter part was built in the 18th Century after the original structure was devastated by natural calamities. The temple is also known as “The Panchayatana Temple” as the main Temple (Shiva) is surrounded by four corner shrines/Doul dedicated to – Lord Vishnu, Lord Surya, Lord Ganesh and Goddess Durga.\nAfter the temple visit, we get on our cycling gears and ride out on an epic journey to a serene island isolated from the rest of Assam, otherwise overlooked and unheard by most. This place is Majuli and once, it held a Guinness World Record for being the world’s largest river island but is now slowly disappearing due to climate change. As we move away from city life, today’s ride would be about taking in the countryside views, breathing in the fresh air, and cycling through small villages and towns. We will have packed lunch with us today. En route, we will be crossing the Brahmaputra on a small local ferry as it’s the only choice for reaching the island. Make sure that you wear layers of clothing in winter, as it’s chilly and windy on the ferry!\n* <strong>Cycling Distance:</strong> 35 km\n* Overnight stay in Majuli.\n#enddesc#\n##staritinerary##title#Day 08: Majuli exploration day\n #endtitle#\n#desc#1. Rise and shine in Magical Majuli, a romantic place lost in time encircled by the swift waters of the mighty Brahmaputra. What better place to end our cycling expedition than Majuli made for cycling! The Majuli Tourism Board has promoted cycling as part of its Sustainable Eco-Tourism Development Project. They believe travel should be about being in a place and not just passing through it and the best way to engage in a new land – is on a cycle.  Most importantly they want to make Majuli, India’s first carbon-neutral district! Flat, straight, empty and unending roads, forest trails, lush countryside and green fields, verdant farmlands and forests, uncountable wetlands and streams make Majuli the perfect spot to get on our bikes and explore to our heart’s content! As you immerse yourselves in this spectacular island’s slow pace of life, its captivating nature and exciting – history and culture, today we would visit historic satras (monasteries dedicated to Lord Vishnu and centres of traditional crafts and performing arts) and discover fishermen’s villages and the homes of ingenious Mishing Tribe that have been elevated on bamboo stilts for protection during the flood season. We would also have lunch in a monk’s house.\n* <strong>Cycling Distance:</strong> 35 km\n* Overnight stay in Majuli.\n#enddesc#\n##staritinerary##title#Day 09: Majuli free day\n #endtitle#\n#desc#1. Today we would start where we left off and continue our cycling expedition around Majuli. On today’s agenda, we will do a circuit around a few villages and cross a few lakes and water bodies. Thereafter, we will be witnessing the mask making process Majuli is famed for, where masks depicting various gods are meticulously crafted by hand and used for traditional theatre performances. Later, we visit a few more monasteries and proceed for lunch. Post lunch, you are free to explore Majuli on your own or you may speak to your leader for optional activities. Today’s meal would be unique as we would be visiting a local Mishing tribal kitchen and enjoying dinner with a local family, cherishing memories of our epic journey.\n* <strong>Cycling Distance:</strong> 35 km\n* Overnight stay in Majuli.\n#enddesc#\n##staritinerary##title#Day 10: Departure day (Sail to Nimati Ghat and Depart from Jorhat)\n #endtitle#\n#desc#1. On the final day of our tour, we say goodbye to our last trip destination and sail towards Nimati Ghat. You can opt for drop off at Jorhat Airport, Railway Station or Bus Stand for onward travel. Speak to us if you want any extension of your stay in Majuli, Jorhat or Guwahati.\n* <strong>Cycling Distance:</strong> 35 km\n* Overnight stay in Majuli.\n#enddesc#', '* Meals - 9 Breakfast, 5 Lunch, 4 Dinner \n* Accommodation – Hotel/ Resort, Campsite/ Houseboats and Experiential Homestays\n* Team Leader/ Tour Guide \n* Cycle Technician \n* Sweep/ Support Vehicles \n* Refreshments during the ride \n* Basic First Aid \n', '* Any Beverages \n* Emergency evacuations \n* Break down \n* Any Private Expenses \n* Room Service Fees ', '**Terrain/ Riding Conditions**\n* 60% Tarmac and 40% Gravel (best suited for MTB) \n* Full vehicle support on cycling days\n* Riding distances are approximate\n* 4 – 6 hours cycling in a day depending on riding conditions and riding capability.\n\n**Physical Fitness**\nEven though this is not an exhaustive trip, it is necessary to be physically fit and active to appreciate this Tour’s experience. The ride is open to all amateur and seasoned cycling enthusiasts who are physically fit to endure and enjoy riding in the valley. There shall be mostly straight roads along the entire route with small undulating roads. Hence, we only recommend riders who are physically fit and have essential cycle riding capability.\n\n**Climate**\nWeather is unpredictable in Assam. Though we are always observant about the changing climate, no one can guarantee rain or the sun. Do understand that your safety is of utmost importance to us. We will not proceed further from the destination if the weather is not favourable, especially while cruising through the river.\n\n**Accommodation**\nAccommodation is included in all destinations as per the itinerary; if arriving early or staying extra at the end of the Tour, let us know if you need suggestions. Most of the hotels we use are Family-run/ experiential stays with quality service while adhering to Covid-19 guidelines. \nTrip cost is on ‘double-sharing’ and \'twin-sharing\'. \nSingle supplement is available at extra cost. (Please do inform us in advance).\n\n**Food**\nWe make sure all the food we offer/ recommend is freshly cooked, and you get to experience a hint of the local delicacy.\n\nPacked Lunch/Lunch in a Local restaurant, Fruits and Water will be provided when riding. \n\nPlease let us know any special dietary requirements at the time of booking.\n\n**Drink**\nAs our initiative towards Responsible and Sustainable Travel, we will provide filtered/ purified water during the ride days and while cruising to reduce plastic usage. Water shall be provided to all participants when riding to prevent excessive use of plastic. Soft drinks and other beverages during meals are not included. Beer and alcohol are available only at specific destinations but are NOT included in the price. \n\n**Transportation**\nWe use an experienced airconditioned chauffeur for this tour for your comfort and safety; airport pick-up and drop isn’t included in the tour cost. Check with us before your arrival or departure if you want us to have transport services which will be charged separately. Email us at thebiketribe@gmail.com or info@thebiketribe.in or call/ WhatsApp us on +91 9315028184. \n\n***NOTE:** We shall be using a SUPPORT VEHICLE for the entire Tour. If the PARTICIPANT does not wish to continue by Cycle, he/she may sit inside the VEHICLE. The plan, activities, ride, route, and other aspects of the TOUR is subject to change, and the LEADER holds authority to do so.*\n\n**Safety**\nNO HELMET NO RIDE - Wearing a helmet is required on all our Biking Adventures and is non-negotiable. If you do not wear a helmet, you will not be allowed to cycle. Your Team Leader is trained in First Aid and Emergency Rescue, but you must be responsible for your safety to a large degree while riding. \nWe have safety jackets available while cruising and in use of the ferry.\n\n**Bikes**\nWe use premium hybrid or MTB bikes in our tours. \nYou may bring your cycle, and you shall receive a discount (Check with us before the tour for the value). Our team will look after your bike, but we do not take any responsibility for any issue you might face during/ after the tour. Example: Your bike will be with us throughout the term, and many times, we will load it and unload it for your ride, and during this time, there can be the possibility of minor scratches/wounds. Our team will not be responsible for any such issues related to your bike.\n\n***NOTE:** Participants may bring their pedals, padded - saddle covers, or other fittings/ accessories that can be attached to the bike.\n\n**Bike Repairs**\nAny Spares, Replacements, Overhauls on the personal bike is not included in the cost. Carrying a basic tool kit, a spare tube is recommended. (Extra Spares expense as per actual for BYOB)\n\nEssential spares and tools are carried by the Cycle Technician, though we cannot guarantee to have spares for every conceivable problem. \n\n**What to Bring**\n* Relaxed shoes for walking/ Riding\n* Personal toiletries as required. \n* Refill Water Bottles \n* Personal medication \n* Riding Apparel and Clothes (according to Weather) \n* Riding Apparel includes Water/wind resistant jacket, padded Shorts/ trousers, Inner base layer, riding Jersey and riding Jacket/ Fleece etc. \n\n**Others**\n* Cap \n* Sunglasses \n* Essential Bike Tools and Spares \n* Individual Bike-riding equipment – Gloves and Helmet \n* Mosquito Repellent \n* Team Leader \n\nYou will be led by a local Cycle tour guide, otherwise known as your Team Leader, and in cases of larger groups, we will add another Leader to the Tour. All our Team Leaders are well informed in the regions you will be passing, along with prior experience in leading Cycle Tours. \n<hr/>\n**COVID-19**\nAs per regulations, all our Accommodation and Equipment shall be sanitised and checked in advance to ensure a safe environment. Wherever meals were available, they would be prepared with care and hygiene. However, it is advisable to be responsible for your Health and Safety and carry a sanitiser. \n\n**Cancellation policy**\nThe Bike Tribe reserves the right to make modifications/ changes in the retreat program and accommodations as is deemed necessary. We also reserve the right to cancel any Tour. In the unlikely event of a cancellation, you may opt to transfer to Tour or receive a refund of the money you have paid. \nThe Bike Tribe is not responsible for any consequential expenses or damages incurred because of any cancellation, not limited to costs spent in preparation. \n\nCancellation must be made through the corresponding email – thebiketribe@gmail.com or info@thebiketribe.in ONLY; otherwise, no cancellation will be entertained. \n\nCancellations will not be accepted over the phone. Only written cancellation notices (email) will be received for authentication purposes. \n\nIn case of any increase in the cost of Hotel, Transport, govt. Tax, fuel etc., we are bound to augment the same. Any Booking will be tentative unless you pay in advance and book on a \nguaranteed basis. \n\nThe Bike Tribe will not be responsible for any (additional) charges incurred after cancellations/ amendments without confirmation from our side. \n\nThe refund will be made via bank transfer or depending on the original purchase method. Additionally, although The Bike Tribe will instruct the bank to handle the crediting process immediately upon notification of cancellation, it could take 2-3 weeks for the actual crediting to occur, which may differ as per your Bank’s practice. \n\n**Cancellations before 20 days from the start of the Tour**\nRefund Options\nGet 80% refund\n90% cash voucher for any trip till one year\n\n**Cancellations before 15 days from the start of the Tour**\nRefund Options\nGet 60% refund\n75% cash voucher for any trip till one year\n\n**Cancellations before ten days from the start of the Tour**\nRefund Options\nGet 20% refund\n40% cash voucher for any trip till one year\n\n**Cancellations before seven days from the start of the Tour**\nRefund Options\nGet 10% refund\n20% cash voucher for any trip till one year\n\n**Cancellations before six days from the start of the Tour**\nRefund Options\nGet 0% refund\n0% cash voucher for any trip till one year\n\nIn case of transferring a trip to a friend, they should satisfy all the mandatory requirements put forward by The Bike Tribe. TBT holds the right to change/ cancel the policies without prior notice.\n\n**Gratitude**\nWhile gratuities for essential services that you will receive as part of your Tour package, from local specialist guides to drivers, bike technician and the crew who will take care of you onboard, are included as part of your Tour cost, the voyage fare does not include the customary, gratuity for your Cycle/ Team Leaders. While it may not be customary for you, it is of great significance to the people who will care for you during your travels. It inspires excellent service and is an entrenched feature of the tourism industry across many destinations. \n', 25000.00, 1, 1, NULL, NULL, '2023-11-21 21:40:13', '2023-11-28 19:35:57'),
(6, 2, 'Cycling on Cloud Nine in Meghalaya', 'cycling-on-cloud-nine-in-meghalaya', 'Cycling on Cloud Nine in Meghalaya - Cycling and Hiking', 'Cycling Trip, Cycling, Cycling and Hiking, Meghalaya Bike Tour, Meghalaya Cycle Trip, Meghalaya Bike Trip', 'Cycling on Cloud Nine in Meghalaya - Cycling and Hiking', NULL, 'PcWbDqF4TmpwZoHsGaK7sH71ubALz8-metaY2NubXRvdXItbWFpbi5qcGc=-.jpg', 'Craving for a serene but exciting cycling adventure through a living natural paradise? Then this tour is your best bet! Meghalaya, literally meaning the Abode of Clouds, is one of the seven sister states of the relatively unexplored Northeast India. Witness its dreamy landscapes change from mountains, hills, highland plateaus, rolling grasslands & valleys and get up close with all elements of nature you can imagine ranging from the blanket of floating clouds, mesmerizing sky, magical rains, mystical rainforests, stunning waterfalls, crystal clear rivulets, natural pools, bewildering caves and more all while riding on the winding roads and new trails.\n\nSurrounded by eastern sub-Himalayan hills- Khasi, Garo, and Jaintia, Meghalaya is not only home to an unreal ambiance and picture-perfect views but also cultural beauty, rare matrilineal tradition, and tribal communities. \n\nExperience the pace of Meghalaya as you ride and hike through its beautiful villages and interact with the ever-smiling, warm and friendly locals. Prepare yourself for a fascinating and moderately challenging cycling tour on undulating trails that are rewarded by the pleasant climate and thrilling occasional hikes through one of the most beautiful states of India!\n', 'CCNM-02', 'Guwahati - Shillong - Sohra - Nongriat - Dawki-Shnongpodeng - Amlarem - Shillong - Guwahati ', '10 Nights / 11 Days', '#staritinerary##title#Day 01: Arrival in Guwahati – Transfer to Shillong #endtitle#\n#desc# Arrive in Guwahati, the gateway to North-East India and the capital of one of the neighbouring states of Meghalaya, Assam. You would be greeted by your tour leader post, which we would be moving towards Shillong, the starting point of your cycling adventure.\nEnroute, we would be stopping for lunch and visiting the first of many attractions to witness throughout your cycling tour - the unmissable Umiam Lake. Take in the beautiful panoramic surroundings around one of the most popular attractions and one of the biggest artificial lakes of Meghalaya, after which we proceed to our hotel in Shillong. You will be introduced to the Bike Tribe team and your bikes in the evening.\n* <strong>Cycling Distance:</strong> None\n* Overnight stay and dinner at Shillong.\n#enddesc#\n##staritinerary##title#Day 02: Cycling in Shillong city #endtitle#\n#desc# Gear up for your first cycling day of the trip as we depart early morning for a city tour of Shillong! The capital city, Shillong, exemplifies why Meghalaya is known as the abode of clouds. As you would witness while riding through the alpine terrain of this beautiful city, wispy cold fluff grey clouds approach to greet you. We would be riding for approx. 30km on slightly uphill plain roads in and around the city, passing by cathedrals, cottages and experiencing the busy part of the city through the thriving markets of Shillong, namely Bada Bazaar and Police Bazaar. After lunch, we would unwind with a peaceful trail ride, including off-roading through a hidden gem called Malki Forest. There is also an option of a short 2 hours hike through Malki Forest. \nReach the hotel by evening.\n* <strong>Cycling Distance:</strong> 30 km \n* Overnight stay and dinner at Shillong.\n#enddesc#\n##staritinerary##title#Day 03: Shillong to Sohra via Sacred Forest #endtitle#\n#desc#1. Today we will depart early morning from Shillong towards a relatively/ an even more uncut jewel, a town called Sohra (Cherapunji). The two wettest places on Earth are in Meghalaya, and Sohra is one of them! Get ready to explore this slice of heaven that is full to the brim with lush greenery, cascading waterfalls, mysterious caves, unspoiled views, endless hiking trails with no path, making it ideal for an adrenaline junkie and nature lover. Enroute, around 2 hours into the drive, we would reach Mawphlang Sacred Forest, home to the most celebrated of all the ancient sacred groves of Meghalaya. Discover the pride of the Khasi people, get up close with their customs and traditions that have been woven into the forest, and get transported to a primeval age on a guided walk. Find yourself amidst an impenetrable mass of greens with a dark canopy above, without a trace of the outside world. Walk on numerous trails, especially the David Scott Trail, that will lead to the most panoramic view of the verdant forest and clear streams. We would have worked up an appetite by this time and stopped at Mylliem Village for a delectable local lunch. We would then proceed to Mawkdok Village, the starting point of today’s ride! Enjoy a 30 km long fun cycling adventure on undulating, winding, smooth, and primarily straight tarmac roads leading back to Sohra. Reach the hotel by evening.\n* <strong>Cycling Distance:</strong> 30 km\n* Overnight stay and dinner at Sohra.\n#enddesc#\n##staritinerary##title#Day 04: Exploring Sohra (Cherapunji)\n#endtitle#\n#desc#1. Rise early, get on your bikes and make way for a full day of cycling in and around Sohra!  We have an adrenaline-pumping day ahead of us, starting from chasing innumerable waterfalls, exploring a lesser-known thrilling activity called caving, and witnessing the ancient civilization of Sohra. We would be visiting the eye-catching Mawsawa, Dainthlen, Wei Sawdong waterfalls and burrowing through Arwah Cave known for its ‘limestone masterpieces’ formed along its walls and ceilings. We will also go back in time to a little-known village rich in Khasi history, called Rangjyrteh, known for its mastery of iron smelting since ancient times, but now it is left abandoned in ruins only referred to in old Khasi folklore.\nAfter an exciting day, unwind and rest at the hotel.\n* <strong>Cycling Distance:</strong> 40 km \n* Overnight stay and dinner at Sohra.\n#enddesc#\n##staritinerary##title#Day 5: Cycle and Hike to Nongriat\n#endtitle#\n#desc#1. Today we escape Sohra momentarily for an overnight stay in a local village and 1.5 days of hike and bike lying ahead of us. So, leave your luggage, carry a light day pack, and get going! We start with a pleasant 16 km ride mostly downhill on undulating terrains to Tyrna Village, the starting point of our mildly arduous but refreshingly green trek that involves a descent through a verdant forest on well-constructed concrete steps to the famous natural wonder unique to the state of Meghalaya: Umshiang Double Decker Living Roots Bridge. A specimen of the bioengineering and architectural skills of the indigenous people of the region, living root bridges have been handcrafted and grown by many generations of the Khasi tribes using the powerful roots of rubber trees to provide a permanent solution to temporary bridges that have to be built using bamboo or wood. With so many streams, rivers, and lakes to cross, they have simply been growing these bridges that can survive up to 500 years since the era of their forefathers instead of building them.\nUnwind with a relaxing overnight stay and dinner at a local village called Nongriat, the home of the Umshiang Bridge (Double Decker root bridge).\n* <strong>Cycling Distance:</strong> 16 km (downhill)\n* Overnight stay at Nongriat.\n#enddesc#\n##staritinerary##title#Day 06: Exploring Nongriat and back to Sohra #endtitle#\n#desc#1. Rise and shine for the next part of our adventure! Today we would take a challenging half-day trek from Nongriat to Rainbow Falls. The hike begins with a series of ascents and descents on raw and earthy stairs followed by a hilly trail where echoes of the falls secluded deep within the forest guide you. Following the mighty roaring of the waterfall, you will finally see a hint of turquoise blue through the thick green foliage and the hills. Welcome to the powerful and breathtakingly beautiful- Rainbow Falls!  Treat yourself to a much-needed dip in the cool, deep blue yet transparent-like waters, and reach out to the colours of the rainbow that are reflected on both sides of the gigantic rock under the waterfall. After a rejuvenating swim session, we will head towards the endpoint of our trek and come out through the tallest plunge waterfall in India called Nohkalikai. \n\nWe would then move back to Sohra. On the drive back, we look back at the experiences of this beautiful getaway.\n\nReach the hotel by evening. After dinner, enjoy a deep sleep out of happy exhaustion!\n* <strong>Cycling Distance:</strong> None\n* Overnight stay in Sohra.\n#enddesc#\n##staritinerary##title#Day 07: Sohra to Dawki-Shnongpodeng\n #endtitle#\n#desc#1. Post breakfast, we bid adieu to the wonderful Sohra and move towards Dawki-Shnongpodeng. After reaching Laitkynsew Village, we hop on our bikes for a 35km ride to a small town situated on the India- Bangladesh border, widely known as the place where the crystal clear Dawki river is present. The terrain would be primarily undulating tarmac roads, and enroute, we will be crossing the cleanest village in India called Mawlynnong. We would be halting here and witnessing panoramic vistas of Bangladesh plains and the whole of Mawlynnong from the Bamboo viewpoints. We would then continue our ride to one of the cleanest rivers in India. The first picture that pops up when one researches Meghalaya is the stunning Umngot River/ Dawki River. The water of Umngot is so clear that the boats floating on it seem to be suspended on a crystal glass surface, and you can also see a variety of gorgeous rocks, pebbles on the riverbed, and even spot fish in the emerald green waters.\n\nWe would be staying overnight at the Shnongpodeng campsite on the banks of the Umngot River to experience the sight and place one cannot get enough of, even more!\n\n* <strong>Cycling Distance:</strong> 35 km\n* Overnight stay in Shnongpodeng.\n#enddesc#\n##staritinerary##title#Day 08: Dawki-Shnongpodeng\n #endtitle#\n#desc#1. Wake up to morning views that are unmatched and unreal! Today we would have a relaxing boat ride in Shnongpodeng, taking in the beautiful vibes of the place one last time.\n\nWe then have a short ride to Amlarem via Krangsuri Falls; a sight cut off from the tourist trail.\n* <strong>Cycling Distance:</strong> None\n* Overnight stay and dinner at Amlarem.\n#enddesc#\n##staritinerary##title#Day 09: Amlarem to Shillong via Jowai\n #endtitle#\n#desc#1. Today is the last day of cycling so let’s make the most of it!\nGet ready for a slightly busier route with local traffic on winding, undulating tarmac roads to Jowai, a destination that is hardly known and prides itself in its melange of heritage and vibrant culture reflected in the lifestyle of the locals as well as its incredible scenic vistas. After this trip\'s last stretch of cycling, we would move back to Shillong. \n* <strong>Cycling Distance:</strong> 35 km\n* Overnight stay and dinner in Shillong.\n#enddesc#\n##staritinerary##title#Day 10: Shillong to Guwahati  #endtitle#\n#desc#1. Wake up at your leisure and enjoy your free day in Shillong. Explore bazaars, lakes, museums, cathedrals, parks, or go for a stroll in the city. \n\nAround 1 pm, there would be a transfer to the starting point of our trip, Guwahati. \n\nOn your last night, we\'ll share our experiences, relive a beautiful journey that was once a dream, trade stories and congratulate ourselves on completing a fantastic cycling trip through Meghalaya!\n* <strong>Cycling Distance:</strong> 35 km\n* Overnight stay and dinner in Guwahati.\n#enddesc#\n##staritinerary##title#Day 11: Departure Day  #endtitle#\n#desc#1. After breakfast, we check out of the hotel. For today, we recommend Guwahati sightseeing tours, especially the cycling tour of North Guwahati. Team Bike Tribe will be happy to make the arrangements for you. You\'re free to explore Guwahati or head to the airport for onward travel, making memories worth a lifetime!\n* <strong>Cycling Distance:</strong> None\n#enddesc#\n\n\n\n\n\n\n\n\n\n\n\n\n', '* Meals - 9 Breakfast, 5 Lunch, 4 Dinner \n* Accommodation – Hotel/ Resort, Campsite/ Houseboats and Experiential Homestays\n* Team Leader/ Tour Guide \n* Cycle Technician \n* Sweep/ Support Vehicles \n* Refreshments during the ride \n* Basic First Aid \n', '* Any Beverages \n* Emergency evacuations \n* Break down \n* Any Private Expenses \n* Room Service Fees  ', '* <strong>Group Size: </strong> 4 to 16 Participants\n* <strong>Min. Age:</strong> 14 Years\n* <strong>Difficulty level:</strong> Moderate\n\nThis Tour is mainly on tarmac and dirt trails through villages. A support vehicle will accompany the group to support carry luggage and any participant in case of exhaustion, fatigue or injury. Roads are well made at the majority of the locations and are primarily plain and undulating roads all the way. The routes we take passes through serene forests, villages, rivers etc.\n\n<strong>Terrain/ Riding Conditions</strong>\n* 60% Tarmac and 40% Gravel (best suited for MTB) \n* Full vehicle support on cycling days\n* Riding distances are approximate\n* 4 – 6 hours cycling in a day depending on riding conditions and riding capability\n\n<strong>Physical Fitness</strong>\nEven though this is not an exhaustive trip, it is necessary to be physically fit and active to appreciate this Tour’s experience. The ride is open to all amateur and seasoned cycling enthusiasts who are physically fit to endure and enjoy riding in the valley. There shall be mostly straight roads along the entire route with small undulating roads. Hence, we only recommend riders who are physically fit and have essential cycle riding capability.\n	\n<strong>Climate</strong>\nWeather is unpredictable in Meghalaya. Though we are always observant about the changing climate, no one can guarantee rain or the sun. Do understand that your safety is of utmost importance to us. We will not proceed further from the destination if the weather is not favourable, especially while cruising through the river.\n\n<strong>Accommodation</strong>\nAccommodation is included in all destinations as per the itinerary; if arriving early or staying extra at the end of the Tour, let us know if you need suggestions. Most of the hotels we use are Family-run/ experiential stays with quality service while adhering to Covid-19 guidelines. \nTrip cost is on ‘double-sharing’ and \'twin-sharing\'. \nSingle supplement is available at extra cost. (Please do inform us in advance).\n\n<strong>Food</strong>\nWe make sure all the food we offer/ recommend is freshly cooked, and you get to experience a hint of the local delicacy.\n\nPacked Lunch/Lunch in a Local restaurant, Fruits and Water will be provided when riding. \n\nPlease let us know any special dietary requirements at the time of booking.\n\n<strong>Drink</strong>\nAs our initiative towards Responsible and Sustainable Travel, we will provide filtered/ purified water during the ride days and while cruising to reduce plastic usage. Water shall be provided to all participants when riding to prevent excessive use of plastic. Soft drinks and other beverages during meals are not included. Beer and alcohol are available only at specific destinations but are NOT included in the price. \n\n<strong>Transportation</strong>\nWe use an experienced airconditioned chauffeur for this tour for your comfort and safety; airport pick-up and drop isn’t included in the tour cost. Check with us before your arrival or departure if you want us to have transport services which will be charged separately. Email us at thebiketribe@gmail.com or info@thebiketribe.in or call/ WhatsApp us on +91 9315028184. \n\n<strong>NOTE: We shall be using a SUPPORT VEHICLE for the entire Tour. If the PARTICIPANT does not wish to continue by Cycle, the participant may sit inside the VEHICLE. The plan, activities, ride, route, and other aspects of the TOUR is subject to change, and the LEADER holds authority to do so.</strong>\n\n<strong>Safety</strong>\nNO HELMET NO RIDE - Wearing a helmet is required on all our Biking Adventures and is non-negotiable. If you do not wear a helmet, you will not be allowed to cycle. Your Team Leader is trained in First Aid and Emergency Rescue, but you must be responsible for your safety to a large degree while riding. \nWe have safety jackets available while cruising and in use of the ferry.\n\n<strong>Bikes</strong>\nWe use premium hybrid or MTB bikes in our tours. \nYou may bring your cycle, and you shall receive a discount (Check with us before the tour for the value). Our team will look after your bike, but we do not take any responsibility for any issue you might face during/ after the tour. Example: Your bike will be with us throughout the term, and many times, we will load it and unload it for your ride, and during this time, there can be the possibility of minor scratches/wounds. Our team will not be responsible for any such issues related to your bike.\n\n<strong>NOTE:</strong> Participants may bring their pedals, padded - saddle covers, or other fittings/ accessories that can be attached to the bike. \n\n<strong>Bike Repairs </strong>\nAny Spares, Replacements, Overhauls on the personal bike is not included in the cost. Carrying a basic tool kit, a spare tube is recommended. (Extra Spares expense as per actual for BYOB)\n\nEssential spares and tools are carried by the Cycle Technician, though we cannot guarantee to have spares for every conceivable problem. \n\n<strong>What to Bring </strong>\n* Relaxed shoes for walking/ Riding\n* Personal toiletries as required. \n* Refill Water Bottles \n* Personal medication \n* Riding Apparel and Clothes (according to Weather) \n* Riding Apparel includes Water/wind resistant jacket, padded Shorts/ trousers, Inner base layer, riding Jersey and riding Jacket/ Fleece etc. \n\n<strong>Others</strong>\n* Cap \n* Sunglasses \n* Essential Bike Tools and Spares \n* Individual Bike-riding equipment – Gloves and Helmet \n* Mosquito Repellent \n\n<strong>Team Leader</strong>\nYou will be led by a local Cycle tour guide, otherwise known as your Team Leader, and in cases of larger groups, we will add another Leader to the Tour. All our Team Leaders are well informed in the regions you will be passing, along with prior experience in leading Cycle Tours. \n<hr/>\n<strong>COVID-19</strong>\nAs per regulations, all our Accommodation and Equipment shall be sanitised and checked in advance to ensure a safe environment. Wherever meals were available, they would be prepared with care and hygiene. However, it is advisable to be responsible for your Health and Safety and carry a sanitiser. \n\n<strong>Cancellation policy</strong>\nThe Bike Tribe reserves the right to make modifications/ changes in the retreat program and accommodations as is deemed necessary. We also reserve the right to cancel any Tour. In the unlikely event of a cancellation, you may opt to transfer to Tour or receive a refund of the money you have paid. \n\nThe Bike Tribe is not responsible for any consequential expenses or damages incurred because of any cancellation, not limited to costs spent in preparation.\n\nCancellation must be made through the corresponding email – thebiketribe@gmail.com or info@thebiketribe.in ONLY; otherwise, no cancellation will be entertained. \n\nCancellations will not be accepted over the phone. Only written cancellation notices (email) will be received for authentication purposes. \n\nIn case of any increase in the cost of Hotel, Transport, govt. Tax, fuel etc., we are bound to augment the same. Any Booking will be tentative unless you pay in advance and book on a guaranteed basis. \n\nThe Bike Tribe will not be responsible for any (additional) charges incurred after cancellations/ amendments without confirmation from our side. \n\nThe refund will be made via bank transfer or depending on the original purchase method. Additionally, although The Bike Tribe will instruct the bank to handle the crediting process immediately upon notification of cancellation, it could take 2-3 weeks for the actual crediting to occur, which may differ as per your Bank’s practice. \n\n<strong>Cancellations before 20 days from the start of the Tour</strong>\n<i>Refund Options</i>\n* Get 80% refund\n* 90% cash voucher for any trip till one year\n<strong>Cancellations before 15 days from the start of the Tour</strong>\n<i>Refund Options</i>\n* Get 60% refund\n* 75% cash voucher for any trip till one year\n<strong>Cancellations before ten days from the start of the Tour</strong>\n<i>Refund Options</i>\n* Get 20% refund\n* 40% cash voucher for any trip till one year\n<strong>Cancellations before seven days from the start of the Tour</strong>\n<i>Refund Options</i>\n* Get 10% refund\n* 20% cash voucher for any trip till one year\n<strong>Cancellations before six days from the start of the Tour</strong>\n<i>Refund Options</i>\n* Get 0% refund\n* 0% cash voucher for any trip till one year\n<i>In case of transferring a trip to a friend, they should satisfy all the mandatory requirements put forward by The Bike Tribe. TBT holds the right to change/ cancel the policies without prior notice.</i>\n<strong>Gratitude</strong>\nWhile gratuities for essential services that you will receive as part of your Tour package, from local specialist guides to drivers, bike technician and the crew who will take care of you onboard, are included as part of your Tour cost, the voyage fare does not include the customary, gratuity for your Cycle/ Team Leaders. While it may not be customary for you, it is of great significance to the people who will care for you during your travels. It inspires excellent service and is an entrenched feature of the tourism industry across many destinations.', 30000.00, 1, 1, NULL, NULL, '2023-12-05 21:10:25', '2023-12-05 22:11:49');
INSERT INTO `tours` (`id`, `tour_category_id`, `title`, `slug`, `meta_title`, `meta_tag_keywords`, `meta_tag_descriptions`, `short_description`, `featured_image`, `description`, `tour_code`, `destinations`, `tour_duration`, `itineraries`, `included`, `excluded`, `extra_features`, `start_price`, `tour_type`, `status`, `published_at`, `deleted_at`, `created_at`, `updated_at`) VALUES
(7, 2, 'Enchanting Darjeeling and Sikkim', 'enchanting-darjeeling-and-sikkim', 'Enchanting Darjeeling and Sikkim Trip', 'Enchanting Darjeeling and Sikkim, Cycling and Hiking, Darjeeling Cycling Tour, Sikkim Cycling Tour', 'Enchanting Darjeeling and Sikkim Trip', NULL, 'ymeDQ4RYFqDUL3zYD89Cf5PfFOuHIM-metaZGFyamxuZ3Npa3RvdXIxLmpwZw==-.jpg', 'Get enchanted by the beauty of Darjeeling and Sikkim! Both destinations are on the bucket list of many, one of them is noted for its scenic beauty, forests, quaint houses, friendly people and the surrounding mountains. The other is notable for its biodiversity, cleanliness, greenery, and is a host to Kanchenjunga – the highest peak in India and the third-highest in the world! \n\nIf you are a fan of Buddhist and Victorian heritage, this tour is certainly for you. With its pristine nature and beautiful wildlife, this Cycling Tour is bound to make you sit back in wonder and fall in love with the outdoors. Along the way, we make time to visit hidden waterfalls that are beyond words to describe. Hop onto the saddle, and experience – enchanting Darjeeeling and Sikkim!\n', 'EDST-03', 'Siliguri - Bagdogra - Kurseong - Darjeeling - Okhrey - Barsey Rhododendron Sanctuary - Dentam - Pelling - Tashiding - Ravangla - Gangtok ', '13 Nights / 14 Days', '#staritinerary##title#Day 1: Siliguri - Bagdogra Arrival#endtitle##desc#Arrive at Siliguri and meet the tour leader to discuss the next few days over a meeting at 6 pm in Siliguri Hotel (lookout for a note in the reception or speak to the front office about it). You will be introduced to The Bike Tribe team today along with your bikes.\n* Cycling distance: None\n* Overnight stay in Siliguri\n#enddesc##staritinerary##title#Day 2: Siliguri to Kurseong\n#endtitle#\n#desc#Breakfast at 7 am and we shall start our ride at 8 am. Today is our first day of the ride, we will leave Siliguri early to ride towards Kurseong via Sukna forest. We take the Toy train route for easy pedalling and stunning views. In the evening we can go to the famous Tourist Lodge’s restaurant to try some delicious momos and enjoy the sunset. \n* Cycling distance: <strong>45 km </strong>\n* Maximum Altitude/ Elevation: <strong>1466 m</strong>\n* Elevation Gain: <strong>1400 m</strong>\n* Overnight stay in Kurseong\n* ~ Uphill all Day ~\n#enddesc##staritinerary##title#Day 3: Kurseong to Darjeeling\n#endtitle#\n#desc#We will start our day with a quick visit to Eagle Crag viewpoint at Sunrise for those who are interested to take beautiful pictures. After a sumptuous breakfast at 7 am, we shall begin the day’s ride at 8 am. We will take a short drive to reach Old Cart/ Military Road to start our day\'s ride towards Darjeeling. We will be taking the Chatakpur forest trail before crossing a picturesque village that got its name from a 100-year-old chimney, which was built by the British at the time of WWI. The chimney is 24 ft. in height and a point of attraction amongst travellers. We will also do an off-road ride through the thick forests of Senchal Wildlife Sanctuary and finally, we shall reach Darjeeling late afternoon. A small orientation walks and a free evening to wander around and enjoy Darjeeling.  \n* Cycling distance: <strong>32 km </strong>\n* Maximum Altitude/ Elevation: <strong>2285 m</strong>\n* Elevation Gain: <strong>868 m</strong>\n* Overnight stay in Darjeeling\n* ~ Slight Uphill but mostly Undulating through Tarmac & Gravel roads ~ \n#enddesc##staritinerary##title#Day 4: Darjeeling and around\n#endtitle#\n#desc#Early morning visit to Tiger Hills for the majestic views of the Himalayas (depending upon weather conditions). After returning to Darjeeling, we shall visit HMI and its Historic Mountaineering Museum. The rest of the day is free to explore at your own pace. Our leader has wonderful optional activities in store for you, do check with him/her for options.\n* Optional Activities: <strong>Visit Tathagata Farms and get a session on Teas of Darjeeling including lunch. </strong>\n* Cycling distance: <strong>None</strong>\n* Overnight stay in Darjeeling\n#enddesc##staritinerary##title#Day 5: Darjeeling to Okhrey via Sombrey#endtitle#\n#desc#Today after an early breakfast we will drive out of Darjeeling to reach Jorethang, we’ll have to present our IDs at the entry gates of Sikkim, after a - snack lunch we’ll begin our ride to Sombrey next to River Rangeet, through villages and scenic landscapes. After reaching Sombrey, we will be hopping on to our coach to reach our destination - Okhrey, a beautiful small village at the height of 2400 meters above sea level, that offers intense serenity, beautiful flora, and thrilling views of the Himalayan mountains. It is also the gateway to the Barsey Rhododendron Sanctuary and a paradise for bird watchers. \n* Cycling distance: <strong>32 km</strong>\n* Maximum Altitude/ Elevation: <strong>2480 m</strong>\n* Elevation Gain: <strong>1800 m</strong>\n* Overnight stay in Okhrey\n* ~ Uphill all Day ~\n#enddesc#\n#staritinerary##title#Day 6: Barsey Rhododendron Sanctuary ride#endtitle#\n#desc#Post breakfast, we’ll be visiting Barsey Rhododendron sanctuary which will include walking and riding. The Barsey Rhododendron Sanctuary lies in the southwest corner of the West Sikkim district. Spreading over 104 sq. km, across the razor-sharp Singalila Range, which forms the natural international border with Nepal. This is a place, you must visit during the Rhododendron flowering season. Post lunch, the day is to relax in Okhrey and we can go for a walk around to experience this wonderful village or a quick visit to a local monastery (if interested). \n* Cycling distance: <strong>22 km </strong>\n* Maximum Altitude/ Elevation: <strong>3048 m</strong>\n* Elevation Gain: <strong>568 m</strong>\n* Overnight stay in Okhrey\n* ~ Undulating throughout ~\n#enddesc#\n#staritinerary##title#Day 7: Okhrey to Dentam#endtitle#\n#desc#Today is a long ride day, we will try to reach Dentam by late afternoon. The ride is undulating past villages and many waterfalls. Enjoy the life of people in the countryside.\n* Cycling distance: <strong>70 km</strong>\n* Maximum Altitude/ Elevation: <strong>2446 m</strong>\n* Elevation Gain: <strong>996 m</strong>\n* Overnight stay in Dentam\n* ~ Uphill all Day~\n#enddesc#\n#staritinerary##title#Day 8: Dentam to Pelling#endtitle#\n#desc#Post breakfast we will ride to Pelling to get the closest view of Mt. Kanchenjunga, the ride is mostly uphill, and we will cross many waterfalls and small villages. Post lunch, we will visit Pemayangtse Monastery (founded in 1705 A.D) - one of the oldest monasteries in Sikkim.\n* Cycling distance: <strong>28 km</strong>\n* Maximum Altitude/ Elevation: <strong>1964 m</strong>\n* Elevation Gain: <strong>973 m</strong>\n* Overnight stay in Pelling\n* ~ Undulating throughout ~\n#enddesc#\n#staritinerary##title#Day 9: Pelling and around #endtitle#\n#desc#Today we start late and ride around Pelling town, make a visit to Rabdentse ruins aka Sidkeong Tulku Bird Park, where the remains of the second capital of the kingdom of Sikkim are found. Amidst the dense forests that carpet the hills near Pelling, up and down a winding path with chestnut trees and past an enchanting lake. Comes the old stone Chorten, which marks the beginning of the walkway up to the main grounds of the ruins. Upon crossing the gateway to the capital, what lies before you is the centre of authority and residence of rulers of the past. Remains of well laid out stone structures with steps for elevation in different areas, serve as evidence of the erstwhile palace. The antique nature of the ruins can be judged from their architectural style and quite simply from their moss-covered stones. The main structure is said to be the royal quarters and it has two large living spaces and an open stone courtyard that leads to the Three Chortens, where the royal family is said to have offered prayers. Standing on an elevated area of the living quarters, there is a clear view of the Pemayangtse Monastery. On the opposite hill, if you look a bit further, you can also see the Sangak Choeling Monastery.\n\nMoreover, the palace grounds also give you a spectacular view of the snow-capped Himalayan ranges and the famed Mt. Kanchenjunga. Visit a local bakery and take the afternoon to wander around Pelling and prepare for tomorrow’s ride.\n\n* Cycling distance: <strong>15 km </strong>\n* Maximum Altitude/ Elevation: <strong>2045 m</strong>\n* Elevation Gain: <strong>180 m</strong>\n* Overnight stay in Pelling\n* ~ Undulating all throughout ~\n#enddesc#\n#staritinerary##title#Day 10: Pelling to Tashiding #endtitle#\n#desc#Today we will have an early start, we will visit Khecheopalri Lake en route, revered by Hindus and Buddhists, the lake is said to have wish-fulfilling powers. We will ride till Yuksom, a place of historical importance where the first King of Sikkim was crowned in the 17th century. After having lunch in Yuksom we will be driving to Tashiding.\n* Cycling distance: <strong>40 km</strong> \n* Maximum Altitude/ Elevation: <strong>1950 m</strong>\n* Elevation Gain: <strong>1082 m</strong>\n* Overnight stay in Tashiding\n* ~ Mostly Downhill and Undulating ~\n#enddesc#\n#staritinerary##title#Day 11: Tashiding to Ravangla #endtitle#\n#desc#After breakfast, we drive for around 10 km to our starting point, and then it’s another - undulating ride day. We should be reaching Ravangla in time for lunch, followed by a visit to the - Buddha Park and the rest of the day is free to explore or relax. \n* Cycling distance: <strong>40 km</strong>\n* Maximum Altitude/ Elevation: <strong>3048 m</strong>\n* Elevation Gain: <strong>950 m</strong>\n* Overnight stay in Ravangla\n* ~ Undulating all throughout ~\n#enddesc#\n#staritinerary##title#Day 12: Ravangla to Gangtok via Temi tea garden #endtitle#\n#desc#Today is the last day of riding, after an early start we will be riding (mostly downhill) through some scenic views to Temi tea garden, which is one of the most beautiful tea estates in the country. We will continue to ride till Singtam and from there we will drive a couple of hours to Gangtok. Post check-in, you have some free time to enjoy a stroll at the Mall road. \n* Cycling distance: <strong>30 km</strong>\n* Maximum Altitude/ Elevation: <strong>1650 m</strong>\n* Elevation Gain: <strong>None</strong>\n* Overnight stay in Gangtok\n* ~ Mostly Downhill ~\n#enddesc#\n#staritinerary##title#Day 13: Gangtok sightseeing #endtitle#\n#desc#Wake up at ease and post breakfast, we’ll drive around Gangtok for some local sightseeing. After sightseeing, you are free for the day till we meet for our last dinner (meal) – together as a group. Reminisce about the Cycle Tour and appreciate the past few days of Adventure.\n* Cycling distance: <strong>None</strong>\n* Overnight stay in Gangtok\n#enddesc#\n#staritinerary##title#Day 14: Departure Day #endtitle#\n#desc#All good things must end, bid adieu to the Team, the fellow Group members, and you may check out by 11: 00 am.\n#enddesc#', '* Meals - 13 Breakfast, 10 Lunch \n* Accommodation – Hotel/ Resort, and Experiential Homestays\n* Team Leader/ Tour Guide \n* Cycle Technician \n* Sweep/ Support Vehicles \n* Refreshments during the ride \n* Basic First Aid', '* Any Beverages \n* Emergency evacuations \n* Break down \n* Any Private Expenses \n* Room Service Fees \n', '* <strong>Group Size:</strong> 4 to 16 Participants \n* <strong>Min. Age:</strong> 12 Years \n* <strong>Difficulty Level:</strong> Moderate \nThis Tour is mainly on tarmac and gravel roads. A support vehicle will accompany the group to support carry luggage and any participant in case of exhaustion, fatigue, or injury. Roads are well made at most of the locations and are primarily plain and undulating roads all the way. The routes we take pass through serene forests, villages, rivers, etc.\n* We can provide transportation to Siliguri at extra cost.\n<strong>Terrain/ Riding Conditions</strong>\n* 75% Tarmac and 25% Gravel (best suited for MTB) \n* Full vehicle support on cycling days\n* Riding distances are approximate\n* 4 – 6 hours cycling in a day depending on riding conditions and riding capability.\n\n<strong>Physical Fitness</strong>\nEven though this is not an exhaustive trip, it is necessary to be physically fit and active to appreciate this Tour’s experience. The ride is open to all amateur and seasoned cycling enthusiasts who are physically fit to endure and enjoy riding in the valley. There shall be mostly straight roads along the entire route with small undulating roads. Hence, we only recommend riders who are physically fit and have essential cycle riding capability.\n	\n<strong>Climate</strong>\nWeather is unpredictable in Meghalaya. Though we are always observant about the changing climate, no one can guarantee rain or the sun. Do understand that your safety is of utmost importance to us. We will not proceed further from the destination if the weather is not favourable, especially while cruising through the river.\n\n<strong>Accommodation</strong>\nAccommodation is included in all destinations as per the itinerary; if arriving early or staying extra at the end of the Tour, let us know if you need suggestions. Most of the hotels we use are Family-run/ experiential stays with quality service while adhering to Covid-19 guidelines. \n\nTrip cost is on ‘double-sharing’ and \'twin-sharing\'. \nSingle supplement is available at extra cost. (Please do inform us in advance).\n\n<strong>Food</strong>\nWe make sure all the food we offer/ recommend is freshly cooked, and you get to experience a hint of the local delicacy.\n\nPacked Lunch/Lunch in a Local restaurant, Fruits and Water will be provided when riding. \n\nPlease let us know any special dietary requirements at the time of booking.\n\n<strong>Drink</strong>\nAs our initiative towards Responsible and Sustainable Travel, we will provide filtered/ purified water during the ride days and while cruising to reduce plastic usage. Water shall be provided to all participants when riding to prevent excessive use of plastic. Soft drinks and other beverages during meals are not included. Beer and alcohol are available only at specific destinations but are NOT included in the price. \n\n<strong>Transportation</strong>\nWe use an experienced airconditioned chauffeur for this tour for your comfort and safety; airport pick-up and drop isn’t included in the tour cost. Check with us before your arrival or departure if you want us to have transport services which will be charged separately. Email us at thebiketribe@gmail.com or info@thebiketribe.in or call/ WhatsApp us on +91 9315028184. \n\n<strong>NOTE: We shall be using a SUPPORT VEHICLE for the entire Tour. If the PARTICIPANT does not wish to continue by Cycle, the participant may sit inside the VEHICLE. The plan, activities, ride, route, and other aspects of the TOUR is subject to change, and the LEADER holds authority to do so.</strong>\n\n<strong>Safety</strong>\nNO HELMET NO RIDE - Wearing a helmet is required on all our Biking Adventures and is non-negotiable. If you do not wear a helmet, you will not be allowed to cycle. Your Team Leader is trained in First Aid and Emergency Rescue, but you must be responsible for your safety to a large degree while riding. \nWe have safety jackets available while cruising and in use of the ferry.\n\n<strong>Bikes</strong>\nWe use premium hybrid or MTB bikes in our tours. \nYou may bring your cycle, and you shall receive a discount (Check with us before the tour for the value). Our team will look after your bike, but we do not take any responsibility for any issue you might face during/ after the tour. Example: Your bike will be with us throughout the term, and many times, we will load it and unload it for your ride, and during this time, there can be the possibility of minor scratches/wounds. Our team will not be responsible for any such issues related to your bike.\n\n<strong>NOTE: Participants may bring their pedals, padded - saddle covers, or other fittings/ accessories that can be attached to the bike.</strong>\n\n<strong>Bike Repairs </strong>\nAny Spares, Replacements, Overhauls on the personal bike is not included in the cost. Carrying a basic tool kit, a spare tube is recommended. (Extra Spares expense as per actual for BYOB)\n\nEssential spares and tools are carried by the Cycle Technician, though we cannot guarantee to have spares for every conceivable problem. \n\n<strong>What to Bring </strong>\n* Relaxed shoes for walking/ Riding\n* Personal toiletries as required. \n* Refill Water Bottles \n* Personal medication \n* Riding Apparel and Clothes (according to Weather) \n* Riding Apparel includes Water/wind resistant jacket, padded Shorts/ trousers, Inner base layer, riding Jersey and riding Jacket/ Fleece etc. \n\n<strong>Others</strong>\n* Cap \n* Sunglasses \n* Essential Bike Tools and Spares \n* Individual Bike-riding equipment – Gloves and Helmet \n* Mosquito Repellent \n\n<strong>Team Leader</strong>\nYou will be led by a local Cycle tour guide, otherwise known as your Team Leader, and in cases of larger groups, we will add another Leader to the Tour. All our Team Leaders are well informed in the regions you will be passing, along with prior experience in leading Cycle Tours. \n<hr/>\n<strong>COVID-19</strong>\nAs per regulations, all our Accommodation and Equipment shall be sanitised and checked in advance to ensure a safe environment. Wherever meals were available, they would be prepared with care and hygiene. However, it is advisable to be responsible for your Health and Safety and carry a sanitiser. \n\n<strong>Cancellation policy</strong>\nThe Bike Tribe reserves the right to make modifications/ changes in the retreat program and accommodations as is deemed necessary. We also reserve the right to cancel any Tour. In the unlikely event of a cancellation, you may opt to transfer to Tour or receive a refund of the money you have paid. \n\nThe Bike Tribe is not responsible for any consequential expenses or damages incurred because of any cancellation, not limited to costs spent in preparation.\n\nCancellation must be made through the corresponding email – thebiketribe@gmail.com or info@thebiketribe.in ONLY; otherwise, no cancellation will be entertained. \n\nCancellations will not be accepted over the phone. Only written cancellation notices (email) will be received for authentication purposes. \n\nIn case of any increase in the cost of Hotel, Transport, govt. Tax, fuel etc., we are bound to augment the same. Any Booking will be tentative unless you pay in advance and book on a guaranteed basis. \n\nThe Bike Tribe will not be responsible for any (additional) charges incurred after cancellations/ amendments without confirmation from our side. \n\nThe refund will be made via bank transfer or depending on the original purchase method. Additionally, although The Bike Tribe will instruct the bank to handle the crediting process immediately upon notification of cancellation, it could take 2-3 weeks for the actual crediting to occur, which may differ as per your Bank’s practice. \n\n<strong>Cancellations before 20 days from the start of the Tour</strong>\n<i>Refund Options</i>\n* Get 80% refund\n* 90% cash voucher for any trip till one year\n<strong>Cancellations before 15 days from the start of the Tour</strong>\n<i>Refund Options</i>\n* Get 60% refund\n* 75% cash voucher for any trip till one year\n<strong>Cancellations before ten days from the start of the Tour</strong>\n<i>Refund Options</i>\n* Get 20% refund\n* 40% cash voucher for any trip till one year\n<strong>Cancellations before seven days from the start of the Tour</strong>\n<i>Refund Options</i>\n* Get 10% refund\n* 20% cash voucher for any trip till one year\n<strong>Cancellations before six days from the start of the Tour</strong>\n<i>Refund Options</i>\n* Get 0% refund\n* 0% cash voucher for any trip till one year\n<i>In case of transferring a trip to a friend, they should satisfy all the mandatory requirements put forward by The Bike Tribe. TBT holds the right to change/ cancel the policies without prior notice.</i>\n<strong>Gratitude</strong>\nWhile gratuities for essential services that you will receive as part of your Tour package, from local specialist guides to drivers, bike technician and the crew who will take care of you onboard, are included as part of your Tour cost, the voyage fare does not include the customary, gratuity for your Cycle/ Team Leaders. While it may not be customary for you, it is of great significance to the people who will care for you during your travels. It inspires excellent service and is an entrenched feature of the tourism industry across many destinations.', 30000.00, 1, 1, NULL, NULL, '2023-12-14 21:57:49', '2023-12-15 21:52:45'),
(8, 2, 'Golden Triangle By Cycle', 'golden-triangle-by-cycle', 'Golden Triangle By Cycle', 'Golden Triangle By Cycle, Delhi Agra Jaipur tour by Cycle, Bicycle Tour, India Cycling Tour', 'India\'s Golden Triangle Tour is a cyclist\'s dream come true! Experience the beauty of the Taj Mahal, spot tigers in their natural habitat, explore Jaipur and Delhi - all on two wheels.', NULL, '6JeZrXbOlgeCViGWykdPwgCEBDvhhU-metaOGRndHRyaXAuanBn-.jpg', 'If you\'ve been planning a trip to India, there is no better way to start than the Golden Triangle. These are three well connected significant destinations of India on a single visit, namely Delhi, Jaipur, and Agra. Distinct and unique in their way, no two attractions are the same. \n* On an all-time favourite route to get a head start into Incredible India, The Bike Tribe takes you on a multifaceted journey to experience and get close to this beautiful country in a heartbeat. With its hidden and offbeat gems, we ensure that you experience India to the core by the end of the tour and not just do the clichéd touristy activities. We welcome you to join us in the adventure of a lifetime; we welcome you to experience INCREDIBLE INDIA.', 'GTTCYCLE_01', 'Delhi - Jaipur - BHaratpur - Agra - Delhi', '7 Nights / 8 Days', '#staritinerary##title#Day 1: Arrival in New Delhi#endtitle##desc#Welcome to India’s capital! Explore Delhi during your free time in the day in your way or choose to do one of our day tours. Meet and greet The Bike Tribe team and the rest of the group in the evening. We will meet at 6 pm for a meeting in the lobby or the conference hall, speak to the hotel’s front office for more details.\n* Cycling distance: <strong>None</strong>\n* Overnight stay in Delhi\n#enddesc##staritinerary##title#Day 2: New Delhi to Jaipur#endtitle#\n#desc#Let the cycling begin! Today we spend our day riding slow for around 26 km in and around the first point of the Golden Triangle - New Delhi. We would be going around this administrative centre and the capital of India crossing important buildings such as India Gate, Presidents House, Parliament, various embassies, cultural centres etc. En route, we will stop for some fresh coconut water to quench our thirst and later for the essential beverage, which is an emotion for every local that is Chai (Masala Tea)! After returning to the hotel around late afternoon, we check out to depart for the next point of our journey- Jaipur in a double-decker train. You will check out from the hotel when we start in the morning, leaving all our bags in day rooms; on your return, we will have one or two-day rooms depending on the group size for approximately an hour to fresh up before we board the train to Jaipur.\n* Cycling distance: <strong>30 km </strong>\n* Overnight stay in Jaipur\n#enddesc##staritinerary##title#Day 3: Exploring Jaipur#endtitle#\n#desc#Today, the Pink City welcomes you for a full day of sightseeing on the bus! We explore the capital of Royal Rajasthan with a dive back into the time of maharajas and palaces through its various monuments and heritage buildings such as the majestic hilltop fort & palace Amber Fort with a local guide an 18th CE astronomical observatory called Jantar Mantar. We would end our day with a delicious feast in a spectacular heritage restaurant. \nNote: Jaipur is famous for its handmade art, craft, handmade jewellery, especially stones (and tailor-made clothing); our team will suggest a few sustainable businesses where you can make your purchases, and you will also have free time to explore the markets on your own. \n* Cycling distance: <strong>None </strong>\n* Overnight stay in Jaipur\n<strong>Optional Activities:</strong>\n* A Bollywood movie in Raj Mandir, an old-time theatre and an iconic symbol of Jaipur which has stood the test of time\n* Visit the current residence of the Royal Family of Jaipur called The City Palace.\n* Hot air ballooning \n* Bollywood Dance Class or Yoga\n#enddesc##staritinerary##title#Day 4: Exploring Jaipur#endtitle#\n#desc#Today we explore Jaipur by cycle! We start our morning ride by visiting the most prominent symbol of Jaipur called the Hawa Mahal and ride around the pink city; we pass by one of the oldest museums of the state that has a collection of artefacts and ancient artworks along with various artist’s masterpieces called Albert hall museum and more. The evening is free for activities and optional. \n* Cycling distance: <strong>30 km</strong>\n* Overnight stay in Jaipur\n#enddesc##staritinerary##title#Day 5: Jaipur to Bharatpur Bird Sanctuary#endtitle#\n#desc#We begin our day with a drive to a surprise spot en route to Agra called Bharatpur, another town in Rajasthan. Before starting today’s short ride through numerous villages before ending the tour in Bharatpur, we will halt at a stepwell at Abhaneri, one of India’s ancient architectural marvels used as water reservoirs. \n* Cycling distance: <strong>50 km</strong>\n* Overnight stay in Bharatpur\n#enddesc#\n#staritinerary##title#Day 6: Bharatpur to Agra#endtitle#\n#desc#Famed for its bird sanctuary, get ready to explore Bharatpur by cycle and spot a variety of birds! After that, we would return to our hotel for breakfast and move to the last point of the triangle, i.e. Agra. We would conclude the day on a beautiful note by visiting the mesmerising Taj during the golden hour!\n* Cycling distance: <strong>30 km </strong>\n* Overnight stay in Agra\n#enddesc#\n#staritinerary##title#Day 7: Agra to New Delhi#endtitle#\n#desc#Rise and shine! Today we ride around Agra and head straight to the Mehtab Bagh Park instead of the Taj Mahal Complex for the best morning view of the Taj to avoid crowds and see the glorious Taj from a different angle.  Later, we bid goodbye to the cycles. After returning to the hotel, we quickly freshen up and then leave for an often overlooked beautiful monument called the Agra Fort, the primary residence of the Mughal Empire before their capital shifted to Delhi. After an insightful and exciting visit to the fort, we move towards Delhi. \n* Cycling distance: <strong>30 km </strong>\n* Overnight stay in Delhi\n#enddesc#\n#staritinerary##title#Day 8: Departure Day#endtitle#\n#desc#After a good morning in Delhi, we checkout by afternoon. You have a free day for activities in the evening. We say goodbye to each other and rejoice in the beautiful time together!\n* Overnight stay in Delhi\n* Cycling distance: <strong>None</strong>\n<strong>Optional activities:</strong>\n* Old Delhi cycling adventure\n* Hidden Jewels of Delhi visiting Qutub Minar, Mehrauli Archaeology Park and Sanjay Van\n* Heritage Delhi tour visiting Humayun’s Tomb, Lodhi Art District, Lodhi Gardens, Safdarjung Tomb\nOld Delhi food walk \n* Customised adventures your leader can suggest according to your choice. \n#enddesc#\n', '* Meals - 7 Breakfast, 1 Lunch, 1 Dinner \n* Accommodation – Hotel/ Resort/ Heritage Hotels, Experiential Homestays\n* Team Leader/ Tour Guide \n* Cycle Technician \n* Sweep/ Support Vehicles \n* Refreshments during the ride \n* Basic First Aid', '* Any Beverages \n* Emergency evacuations \n* Break down \n* Any Private Expenses \n* Room Service Fees\n', '* <strong>Group Size:</strong> 4 to 16 Participants \n* <strong>Min. Age:</strong> 12 Years \n* <strong>Difficulty Level:</strong> Moderate \nThis Tour is mainly on tarmac and gravel roads. A support vehicle will accompany the group to support carry luggage and any participant in case of exhaustion, fatigue, or injury. Roads are well made at most of the locations and are primarily plain and undulating roads all the way. The routes we take pass through serene forests, villages, rivers, etc.\n* We can provide transportation to Siliguri at extra cost.\n<strong>Terrain/ Riding Conditions</strong>\n* 70% Tarmac and 30% Gravel (best suited for MTB) \n* Full vehicle support on cycling days\n* Riding distances are approximate\n* 2 – 5 hours cycling in a day depending on riding conditions and riding capability.\n\n<strong>Physical Fitness</strong>\nEven though this is not an exhaustive trip, it is necessary to be physically fit and active to appreciate this Tour’s experience. The ride is open to all amateur and seasoned cycling enthusiasts. There shall be mostly straight roads along the entire route with small undulating roads. Hence, we only recommend riders who are physically fit and have essential cycle riding capability.\n	\n<strong>Climate</strong>\nThe weather is hot mainly during the day, with temperatures varying from 8 degrees Celsius to 31 degrees Celsius in winters and 35 degrees Celsius to 45 degrees Celsius in Summers. Though we are always observant about the changing weather, no one can guarantee rain or the sun. Do understand that your safety is of utmost importance to us. We will not proceed any further from the destination if the weather is not favourable, especially when it\'s too hot to bear and there can be chances of heatstroke.\n\n<strong>Accommodation</strong>\nAccommodation is included in all destinations as per the itinerary; if arriving early or staying extra at the end of the Tour, let us know if you need suggestions. Most of the hotels we use are Family-run/ experiential stays with quality service while adhering to Covid-19 guidelines. \n\nTrip cost is on <strong>‘double-sharing’</strong> and <strong>\'twin-sharing\'</strong>. \nSingle supplement is available at extra cost. (Please do inform us in advance).\n\n<strong>Food</strong>\nWe make sure all the food we offer/ recommend is freshly cooked, and you get to experience a hint of the local delicacy.\n\nPacked Lunch/Lunch in a Local restaurant, Fruits and Water will be provided when riding. \n\nPlease let us know any special dietary requirements at the time of booking.\n\n<strong>Drink</strong>\nAs our initiative toward Responsible and Sustainable Travel, we will be providing filtered/ purified water during the ride days. Water shall be provided to all participants when riding to prevent excessive use of plastic. Soft drinks and other beverages during meals are not included. Beer and alcohol are available only at specific destinations but are NOT included in the price.\n\n<strong>Transportation</strong>\nWe use an experienced airconditioned chauffeur for this tour for your comfort and safety; airport pick-up and drop isn’t included in the tour cost. Check with us before your arrival or departure if you want us to have transport services which will be charged separately. Email us at thebiketribe@gmail.com or info@thebiketribe.in or call/ WhatsApp us on +91 9315028184. \n\n<strong>NOTE: We shall be using a SUPPORT VEHICLE for the entire Tour. If the PARTICIPANT does not wish to continue by Cycle, he/she may sit inside the VEHICLE. The plan, activities, ride, route, and other aspects of the TOUR is subject to change, and the LEADER holds authority to do so.</strong>\n\n<strong>Safety</strong>\nNO HELMET NO RIDE - Wearing a helmet is required on all our Biking Adventures and is non-negotiable. If you do not wear a helmet, you will not be allowed to cycle. Your Team Leader is trained in First Aid and Emergency Rescue, but you must be responsible for your safety to a large degree while riding. \n\n<strong>Bikes</strong>\nWe use premium hybrid or Mountain bikes in our tours. \nYou may bring your own cycle, and we will give you a discount (Check with us before the tour for the value). Our team will look after your bike, but we do not take any responsibility for any issue you might face during/ after the tour. Example: Your bike will be with us throughout the term, and many times, we will load it and unload it for your ride. During this time, there can be a possibility of minor scratches/wounds. Our team will not be responsible for any such issues related to your bike.\n\n<strong>NOTE: Participant may bring their pedals, padded - saddle covers, or other fittings/ accessories that can be attached to the bike. </strong>\n\n<strong>Bike Repairs </strong>\nAny Spares, Replacements, Overhauls on the personal bike is not included in the cost. Carrying a basic tool kit, a spare tube is recommended. (Extra Spares expense as per actual for BYOB)\n\nEssential spares and tools are carried by the Cycle Technician, though we cannot guarantee to have spares for every conceivable problem. \n\n<strong>What to Bring </strong>\n* Relaxed shoes for walking/ Riding\n* Personal toiletries as required. \n* Refill Water Bottles \n* Personal medication \n* Riding Apparel and Clothes (according to Weather) \n* You may bring winter or summer clothing according to the season.\n* Best to carry a rain cover.\n\n\n<strong>Others</strong>\n* Cap \n* Sunglasses \n* Essential Bike Tools and Spares \n* Individual Bike-riding equipment – Gloves and Helmet \n* Mosquito Repellent.\n\n\n<strong>Team Leader</strong>\nYou will be led by a local Cycle tour guide, otherwise known as your Team Leader, and in cases of larger groups, we will add another Leader to the Tour. All our Team Leaders are well informed in the regions you will be passing, along with prior experience in leading Cycle Tours. \n<hr/>\n<strong>COVID-19</strong>\nAs per regulations, all our Accommodation and Equipment shall be sanitised and checked in advance to ensure a safe environment. Wherever meals are available, they would be prepared with care. However, it is advisable to be Responsible for your Health and Safety and carry a sanitiser. \n\n<strong>Cancellation policy</strong>\nThe Bike Tribe reserves the right to make modifications/ changes in the retreat program and accommodations as is deemed necessary. We also reserve the right to cancel any Tour. In the unlikely event of a cancellation by The Bike Tribe, you may opt to transfer to Tour or receive a refund of the money you have paid.  \n\nThe Bike Tribe is not responsible for any consequential expenses or damages incurred because of any cancellation, not limited to costs spent in preparation. \n\nCancellation must be made through the corresponding email – thebiketribe@gmail.com or info@thebiketribe.in ONLY; otherwise, no cancellation will be entertained. \nCancellations will not be accepted over the phone. Only written cancellation notices (email) will be received for authentication purposes. \n\nIn case of any increase in the cost of Hotel, Transport, govt. Tax, fuel etc., we are bound to augment the same. Any Booking will be tentative unless you pay in advance and book on a guaranteed basis. \n\nThe Bike Tribe will not be responsible for any (additional) charges incurred after cancellations/ amendments without confirmation from our side. \n\nThe refund will be made via bank transfer or depending on the original purchase method. Additionally, although The Bike Tribe will instruct the bank to handle the crediting process immediately upon notification of cancellation, it could take 2-3 weeks for the actual crediting to occur, which may differ as per your Bank’s practice.\n\n<strong>Cancellations before 20 days from the start of the Tour</strong>\n<i>Refund Options</i>\n* Get 80% refund\n* 90% cash voucher for any trip till one year\n<strong>Cancellations before 15 days from the start of the Tour</strong>\n<i>Refund Options</i>\n* Get 60% refund\n* 75% cash voucher for any trip till one year\n<strong>Cancellations before ten days from the start of the Tour</strong>\n<i>Refund Options</i>\n* Get 20% refund\n* 40% cash voucher for any trip till one year\n<strong>Cancellations before seven days from the start of the Tour</strong>\n<i>Refund Options</i>\n* Get 10% refund\n* 20% cash voucher for any trip till one year\n<strong>Cancellations before six days from the start of the Tour</strong>\n<i>Refund Options</i>\n* Get 0% refund\n* 0% cash voucher for any trip till one year\n<i>In case of transferring a trip to a friend, they should satisfy all the mandatory requirements put forward by The Bike Tribe. TBT holds the right to change/ cancel the policies without prior notice.</i>\n<strong>Gratitude</strong>\nWhile gratuities for essential services that you will receive as part of your Tour package, from local specialist guides to drivers, bike technician and the crew who will take care of you onboard, are included as part of your Tour cost, the voyage fare does not include the customary, gratuity for your Cycle/ Team Leaders. While it may not be customary for you, it is of great significance to the people who will care for you during your travels. It inspires excellent service and is an entrenched feature of the tourism industry across many destinations in India.', 20000.00, 1, 1, NULL, NULL, '2023-12-15 22:10:22', '2023-12-16 16:25:21'),
(9, 7, 'Tour India', 'tour-india', 'Tour India', 'India Tour', 'India Tour', NULL, NULL, 'Cycle Tour of India', 'IDT2036', 'Delhi - Jaipur - BHaratpur - Agra - Delhi', '21 Nights / 22 Days', 'Cycle Tour of India', 'null', 'null', NULL, 15000.00, 1, 1, NULL, NULL, '2023-12-20 21:26:03', '2024-01-17 03:08:04');

-- --------------------------------------------------------

--
-- Table structure for table `tour_categories`
--

CREATE TABLE `tour_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_tag_keywords` varchar(255) DEFAULT NULL,
  `meta_tag_descriptions` varchar(255) DEFAULT NULL,
  `short_description` varchar(255) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1 COMMENT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tour_categories`
--

INSERT INTO `tour_categories` (`id`, `title`, `slug`, `meta_title`, `meta_tag_keywords`, `meta_tag_descriptions`, `short_description`, `description`, `status`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'Golden Triange Tours', 'golden-triange', 'Golden Triange', 'Golden Triange Tours', 'Golden Triange Tours', NULL, 'The Golden Triangle[1] is the name given to one of Asia\'s two principal areas of illicit opium production (with the other being the Golden Crescent). Its geographical limits are the area in which the borders of Myanmar, Thailand, and Laos meet at the confluence of the Ruak and the Mekong Rivers.[2][3] The name \"Golden Triangle\" was coined by the CIA[4] and is commonly used more broadly to refer to an area of approximately 950,000 square kilometres (367,000 sq mi) that overlaps the mountains of the four adjacent countries.', 0, NULL, '2023-10-16 08:45:16', '2023-10-16 08:54:13'),
(2, 'Rajasthan Tours', 'rajasthan-tours', 'Rajasthan Tours', 'Rajasthan Tours', 'Rajasthan Tours', NULL, 'Rajasthan (Hindi:  lit. \'Land of Kings\') is a state in northern India. It covers 342,239 square kilometres (132,139 sq mi) or 10.4 per cent of India\'s total geographical area. It is the largest Indian state by area and the seventh largest by population. It is on India\'s northwestern side, where it comprises most of the wide and inhospitable Thar Desert (also known as the Great Indian Desert) and shares a border with the Pakistani provinces of Punjab to the northwest and Sindh to the west, along the Sutlej-Indus River valley. It is bordered by five other Indian states: Punjab to the north; Haryana and Uttar Pradesh to the northeast; Madhya Pradesh to the southeast; and Gujarat to the southwest. Its geographical location is 23°.3\' to 30°.12\' North latitude and 69°.30\' to 78°.17\' East longitude, with the Tropic of Cancer passing through its southernmost tip.', 1, NULL, '2023-10-16 08:52:29', '2023-10-16 08:52:29'),
(3, 'South India Tours', 'south-india-tours', 'South India Tours', 'South India Tours', 'South India Tours', NULL, 'Welcome to the mighty Himalayas! Leh/ Ladakh is considered as the Mecca of Cyclists and Motorcyclists in India. This route has gained immense popularity amongst Outsiders and Foreigners, as the road to Leh/ Ladakh is outwardly and challenging. This side of the Himalayas is home to spectacular Passes and the terrain changes from place to place. It is home to the highest (civilian) motorable passes in the World – Khardungla (5602 m) and Tanglang La Pass (5181 m) and has the finest backroads an Adventure Cyclist would wish for. This Cycle Expedition traverses through – untraded parts of the most nomadic travel circuit in the Lahaul region, climbing through spectacular Passes, riding past pristine Rivers, with magical views of the snow-capped Mountains, and finishes at the town of Leh. Going through rustic Villages in the higher Himalayas and passing by peaceful Monasteries, this Tour is a complete package for any Adventure Cyclist/ Enthusiast.', 1, NULL, '2023-10-19 10:37:39', '2023-10-19 10:37:39'),
(4, 'North India Tours', 'north-india-tours', 'North India Tours', 'North India Tours', 'North India Tours', NULL, 'North India Tours Desc', 1, NULL, '2023-10-24 17:32:38', '2023-10-24 17:32:38'),
(5, 'Day Trips', 'day-trips', 'Day Trips', 'Day Trips, Delhi Tours', 'Day Trips', '', 'Day Trips from Delhi', 1, NULL, '2023-10-24 17:35:47', '2024-01-16 01:37:25'),
(6, 'jaipur subhash', NULL, 'jaipur subhash', 'jaipur', 'jaipur subhash', 'this is test for jaiur category ', 'this is test for jaiur category&nbsp;', 1, NULL, '2024-01-16 01:04:37', '2024-01-16 01:05:05'),
(7, 'test', NULL, 'tewstimage', 'tst', 'test', 'shout image ', 'image&nbsp;&nbsp;', 1, NULL, '2024-01-16 01:39:16', '2024-01-16 01:39:16');

-- --------------------------------------------------------

--
-- Table structure for table `tour_itineraries`
--

CREATE TABLE `tour_itineraries` (
  `id` int(11) NOT NULL,
  `tour_id` bigint(20) UNSIGNED DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `description` mediumtext DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tour_itineraries`
--

INSERT INTO `tour_itineraries` (`id`, `tour_id`, `title`, `description`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 9, NULL, '{\"1\":{\"desc\":\"here we will coome to jaipur and go to hawa mahal \",\"title\":\"day:1 we will come to jaipur \"}}', NULL, '2024-01-17 07:17:22', '2024-01-17 07:17:22');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `deleted_at` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'Bike Tribe Admin', 'admin@thebiketribe.in', '2023-09-14 04:38:49', '$2y$10$Q8ELO9Yq5FyACGrvp3z.0eO1Z94hbDDx8n2KXLXK4RMgX/7hLqqky', 'jXX4gc2FckGFk88hw4E4w8UE2wmsdtGTMm0oNrKTdgv1k1ZJUgJ155kZlbBe', NULL, '2023-09-14 04:38:49', '2023-09-14 04:38:49'),
(2, 'subhash Admin', 'adminsubhash@gmail.in', '2023-09-14 04:38:49', '$2y$10$Q8ELO9Yq5FyACGrvp3z.0eO1Z94hbDDx8n2KXLXK4RMgX/7hLqqky', 'WoehHzNcOvaSalei8RwDfdaBdQPxl55NEpMC7yC0IxeSE7fYL6HfXuyBX84o', NULL, '2023-09-14 04:38:49', '2023-09-14 04:38:49');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `banners`
--
ALTER TABLE `banners`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `destinations`
--
ALTER TABLE `destinations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `destination_categories`
--
ALTER TABLE `destination_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `image_banks`
--
ALTER TABLE `image_banks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `image_infos`
--
ALTER TABLE `image_infos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shop_customers`
--
ALTER TABLE `shop_customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `shop_customers_email_unique` (`email`);

--
-- Indexes for table `subscribers`
--
ALTER TABLE `subscribers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `subscribers_email_unique` (`email`);

--
-- Indexes for table `testimonials`
--
ALTER TABLE `testimonials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tours`
--
ALTER TABLE `tours`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tour_categories`
--
ALTER TABLE `tour_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tour_itineraries`
--
ALTER TABLE `tour_itineraries`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `banners`
--
ALTER TABLE `banners`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `destinations`
--
ALTER TABLE `destinations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `destination_categories`
--
ALTER TABLE `destination_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `image_banks`
--
ALTER TABLE `image_banks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `image_infos`
--
ALTER TABLE `image_infos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `shop_customers`
--
ALTER TABLE `shop_customers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1001;

--
-- AUTO_INCREMENT for table `subscribers`
--
ALTER TABLE `subscribers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `testimonials`
--
ALTER TABLE `testimonials`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tours`
--
ALTER TABLE `tours`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tour_categories`
--
ALTER TABLE `tour_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tour_itineraries`
--
ALTER TABLE `tour_itineraries`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
